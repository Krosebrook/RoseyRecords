
import { GoogleGenAI, Type, Modality } from "@google/genai";

// Use a function to always get the freshest API key from process.env.API_KEY
const getAI = () => new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateSongConcept = async (prompt: string) => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `You are an expert music producer at OctaveStudio. Create a detailed song concept based on: "${prompt}". 
      Provide a JSON with: 
      - title: Catchy name.
      - lyrics: Full song lyrics with [Verse 1], [Chorus], [Verse 2], [Bridge], [Outro].
      - genre: Specific musical style.
      - mood: Emotional atmosphere.
      - bpm: Tempo as a number (60-180).
      - key: Musical key (e.g., C Major).
      - energy: Description of intensity.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            lyrics: { type: Type.STRING },
            genre: { type: Type.STRING },
            mood: { type: Type.STRING },
            bpm: { type: Type.NUMBER },
            key: { type: Type.STRING },
            energy: { type: Type.STRING }
          },
          required: ["title", "lyrics", "genre", "mood", "bpm", "key", "energy"]
        }
      }
    });
    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Concept generation failed:", error);
    throw error;
  }
};

export const generateProductionInsight = async (metadata: any) => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze this song concept and provide one professional, concise production tip (max 20 words).
      Genre: ${metadata.genre}, Mood: ${metadata.mood}, Energy: ${metadata.energy}.
      Lyrics: ${metadata.lyrics.substring(0, 200)}...`,
      config: {
        systemInstruction: "You are a seasoned studio engineer. Provide one punchy, helpful tip about mixing, vocals, or arrangement."
      }
    });
    return response.text;
  } catch (error) {
    return "The emotional energy of this track suggests a wider vocal stack. Harmonic support layer activated.";
  }
};

export const enhanceMix = async (metadata: any, currentMixer: any) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `As a world-class mastering engineer, optimize this OctaveStudio mix. 
    Genre: ${metadata.genre}, Mood: ${metadata.mood}, Energy: ${metadata.energy}.
    Current levels: ${JSON.stringify(currentMixer)}.
    Return a JSON with "mixer" (vox, drums, bass, lead levels) and "mastering" (eqHigh, eqMid, eqLow, compression) that would make this track sound professional.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          mixer: {
            type: Type.OBJECT,
            properties: {
              vox: { type: Type.NUMBER },
              drums: { type: Type.NUMBER },
              bass: { type: Type.NUMBER },
              lead: { type: Type.NUMBER }
            }
          },
          mastering: {
            type: Type.OBJECT,
            properties: {
              eqHigh: { type: Type.NUMBER },
              eqMid: { type: Type.NUMBER },
              eqLow: { type: Type.NUMBER },
              compression: { type: Type.NUMBER }
            }
          }
        }
      }
    }
  });
  return JSON.parse(response.text || '{}');
};

export const generateImage = async (prompt: string, aspectRatio: string = "1:1", size: string = "1K") => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-image-preview',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: {
          aspectRatio: aspectRatio as any,
          imageSize: size as any
        }
      }
    });

    const parts = response.candidates?.[0]?.content?.parts || [];
    for (const part of parts) {
      if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
    }
    throw new Error("No image part found in response");
  } catch (error) {
    console.error("Image generation failed:", error);
    throw error;
  }
};

export const generateImageVariations = async (prompt: string, count: number = 4) => {
  const promises = Array(count).fill(null).map(() => generateImage(prompt));
  return Promise.all(promises);
};

export const generateSpeech = async (text: string, voice: string = 'Kore') => {
  const ai = getAI();
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  } catch (error) {
    console.error("Speech generation failed:", error);
    return null;
  }
};

export const generateVideo = async (prompt: string, aspectRatio: '16:9' | '9:16' = '16:9', image?: string) => {
  const ai = getAI();
  const videoConfig: any = {
    numberOfVideos: 1,
    resolution: '720p',
    aspectRatio: aspectRatio
  };

  let operation = await ai.models.generateVideos({
    model: 'veo-3.1-fast-generate-preview',
    prompt,
    image: image ? {
      imageBytes: image.split(',')[1] || image,
      mimeType: 'image/png'
    } : undefined,
    config: videoConfig
  });

  while (!operation.done) {
    await new Promise(resolve => setTimeout(resolve, 10000));
    operation = await ai.operations.getVideosOperation({ operation: operation });
  }

  const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
  if (!downloadLink) throw new Error("Video generation failed to return a URI");
  
  return `${downloadLink}&key=${process.env.API_KEY}`;
};

export const editImage = async (base64Image: string, prompt: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            data: base64Image.split(',')[1] || base64Image,
            mimeType: 'image/png'
          }
        },
        { text: prompt }
      ]
    }
  });

  const parts = response.candidates?.[0]?.content?.parts || [];
  for (const part of parts) {
    if (part.inlineData) return `data:image/png;base64,${part.inlineData.data}`;
  }
  return null;
};

export const analyzeMedia = async (dataUrl: string, mimeType: string, prompt: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: dataUrl.split(',')[1] || dataUrl, mimeType } },
        { text: prompt }
      ]
    }
  });
  return response.text;
};

export const smartAssistant = async (query: string, tools: { search: boolean; maps: boolean; thinking: boolean }) => {
  const ai = getAI();
  const apiTools: any[] = [];
  if (tools.search) apiTools.push({ googleSearch: {} });
  if (tools.maps) apiTools.push({ googleMaps: {} });

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: query,
    config: {
      tools: apiTools.length > 0 ? apiTools : undefined,
      thinkingConfig: tools.thinking ? { thinkingBudget: 32768 } : undefined
    }
  });

  return {
    text: response.text,
    sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
  };
};

export const transcribeAudio = async (base64Audio: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: {
      parts: [
        { inlineData: { data: base64Audio, mimeType: 'audio/wav' } },
        { text: "Transcribe the following audio exactly." }
      ]
    }
  });
  return response.text;
};

export const getFastResponse = async (query: string) => {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: query
  });
  return response.text;
};
