
import { SongMetadata } from '../types';

const LIBRARY_KEY = 'octave_project_library';

/**
 * Retrieves all saved projects from local storage.
 * Sorts by last modified (newest first) if available.
 */
export const getLibrary = (): SongMetadata[] => {
  try {
    const stored = localStorage.getItem(LIBRARY_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (e) {
    console.error("Failed to parse library", e);
    return [];
  }
};

/**
 * Saves a project to the library.
 * If ID exists, updates the record. If new, pushes to array.
 */
export const saveProjectToLibrary = (project: SongMetadata): void => {
  const library = getLibrary();
  const index = library.findIndex(p => p.id === project.id);
  
  // Add a timestamp for sorting (injecting into the object dynamically)
  const entry = { ...project, lastModified: Date.now() };

  if (index >= 0) {
    library[index] = entry;
  } else {
    library.unshift(entry);
  }
  
  localStorage.setItem(LIBRARY_KEY, JSON.stringify(library));
};

/**
 * Deletes a project by ID.
 */
export const deleteProjectFromLibrary = (id: string): void => {
  const library = getLibrary().filter(p => p.id !== id);
  localStorage.setItem(LIBRARY_KEY, JSON.stringify(library));
};

/**
 * Exports project as JSON file
 */
export const exportProject = (project: SongMetadata) => {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(project));
  const downloadAnchorNode = document.createElement('a');
  downloadAnchorNode.setAttribute("href", dataStr);
  downloadAnchorNode.setAttribute("download", `${project.title.replace(/\s+/g, '_')}_octave.json`);
  document.body.appendChild(downloadAnchorNode);
  downloadAnchorNode.click();
  downloadAnchorNode.remove();
};
