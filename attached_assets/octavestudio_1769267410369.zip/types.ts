
export enum AppView {
  STUDIO = 'studio',
  LIVE = 'live',
  ASSISTANT = 'assistant',
  GALLERY = 'gallery'
}

export type SectionType = 'Intro' | 'Verse' | 'Chorus' | 'Bridge' | 'Outro';

export interface SongSection {
  id: string;
  type: SectionType;
  name: string;
  bars: number;
}

export interface DrumPatterns {
  kick: boolean[];
  snare: boolean[];
  hihat: boolean[];
  perc: boolean[];
}

export interface MixerState {
  vox: number;
  drums: number;
  bass: number;
  lead: number;
}

export interface SongMetadata {
  id: string;
  title: string;
  lyrics: string;
  genre: string;
  mood: string;
  bpm: number;
  key: string;
  energy: string;
  coverArts: string[];
  structure?: SongSection[];
  patterns?: DrumPatterns;
  mixer?: MixerState;
  videoUrl?: string; // Added to persist generated video
}

export interface MediaItem {
  id: string;
  type: 'image' | 'video';
  url: string;
  prompt: string;
  timestamp: number;
}
