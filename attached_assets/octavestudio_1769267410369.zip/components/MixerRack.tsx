
import React from 'react';

interface MixerRackProps {
  mixer: { vox: number; drums: number; bass: number; lead: number };
  onMixerChange: (key: string, val: number) => void;
  fx: { 
    reverbWet: number; 
    reverbDecay: number; 
    reverbGain: number;
    delayWet: number; 
    delayTime: number; 
    delayFeedback: number;
    delayGain: number;
    leadAftertouch: number;
    leadAftertouchEnabled: boolean;
    leadAftertouchDetuneSens: number;
    leadAftertouchVolSens: number;
    harmonyLevel?: number;
  };
  onFxChange: (key: string, val: number) => void;
  mastering: { eqHigh: number; eqMid: number; eqLow: number; compression: number };
  onMasteringChange: (key: string, val: number) => void;
  levels?: any;
}

const REVERB_PRESETS = [
  { name: 'Studio Ambience', decay: 0.5, wet: 0.1 },
  { name: 'Small Room', decay: 1.0, wet: 0.15 },
  { name: 'Large Room', decay: 1.5, wet: 0.2 },
  { name: 'Vintage Plate', decay: 1.8, wet: 0.25 },
  { name: 'Concert Hall', decay: 2.5, wet: 0.3 },
  { name: 'Cathedral', decay: 4.0, wet: 0.4 },
  { name: 'Spring Tank', decay: 1.2, wet: 0.3 },
  { name: 'Stadium Arena', decay: 6.0, wet: 0.5 },
  { name: 'Ethereal Cloud', decay: 10.0, wet: 0.6 },
  { name: 'Infinite Void', decay: 20.0, wet: 0.8 },
];

const MixerRack: React.FC<MixerRackProps> = ({ 
  mixer, 
  onMixerChange, 
  fx, 
  onFxChange, 
  mastering, 
  onMasteringChange, 
  levels
}) => {
  const currentPreset = REVERB_PRESETS.find(p => 
    Math.abs(p.decay - fx.reverbDecay) < 0.1 && 
    Math.abs(p.wet - fx.reverbWet) < 0.05
  );

  return (
    <div className="grid grid-cols-1 xl:grid-cols-3 gap-10">
      {/* Precision Mixing Console */}
      <div className="bg-black/20 p-8 rounded-[3rem] border border-white/5">
        <div className="flex justify-between items-center mb-10">
          <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest">Mixing Desk</span>
          <div className="flex gap-2">
            <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_10px_rgba(16,185,129,0.5)]"></div>
          </div>
        </div>
        <div className="grid grid-cols-4 gap-4">
          {Object.entries(mixer).map(([k, v]) => {
            const val = v as number;
            return (
              <div key={k} className="flex flex-col items-center gap-6 group">
                <div className="h-48 w-5 bg-black rounded-full relative overflow-hidden flex flex-col justify-end p-1 border border-white/5">
                  <input 
                    type="range" min="-48" max="6" step="1" value={val} 
                    onChange={(e) => onMixerChange(k, parseInt(e.target.value))}
                    className="absolute inset-0 h-full w-full opacity-0 cursor-pointer z-20" 
                    style={{ writingMode: 'vertical-lr', transform: 'rotate(180deg)' }}
                  />
                  <div 
                    className="w-full bg-indigo-600/20 rounded-full transition-all duration-300 pointer-events-none absolute bottom-0" 
                    style={{ height: `${((val + 48) / 54) * 100}%` }} 
                  />
                  <div 
                    className="w-full bg-indigo-500 rounded-full transition-all duration-75 pointer-events-none z-10 shadow-[0_0_15px_rgba(99,102,241,0.5)]"
                    style={{ height: `${(levels?.[k] || 0) * 100}%` }}
                  />
                </div>
                <span className="text-[9px] font-black uppercase text-gray-600 group-hover:text-indigo-400 transition-colors tracking-widest">{k}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Mastering Intelligence */}
      <div className="bg-black/20 p-8 rounded-[3rem] border border-white/5">
        <span className="text-[10px] font-black text-emerald-500 uppercase tracking-widest mb-10 block">AI Master Chain</span>
        <div className="space-y-8">
          <div className="grid grid-cols-3 gap-4">
            {['eqLow', 'eqMid', 'eqHigh'].map((key) => {
              const currentVal = mastering[key as keyof typeof mastering] as number;
              return (
                <div key={key} className="flex flex-col items-center gap-4">
                  <div className="relative w-16 h-16 flex items-center justify-center group">
                    <svg className="w-full h-full -rotate-90">
                      <circle cx="32" cy="32" r="28" fill="transparent" stroke="#000" strokeWidth="6" />
                      <circle cx="32" cy="32" r="28" fill="transparent" stroke="#10b981" strokeWidth="6" strokeDasharray="175.9" 
                        strokeDashoffset={175.9 - (175.9 * ((currentVal + 24) / 48))} 
                        className="transition-all duration-500"
                      />
                    </svg>
                    <input 
                      type="range" min="-24" max="24" step="1" value={currentVal}
                      onChange={(e) => onMasteringChange(key, parseInt(e.target.value))}
                      className="absolute inset-0 opacity-0 cursor-pointer z-10"
                    />
                    <span className="absolute text-[10px] font-black text-emerald-400 group-hover:scale-125 transition-transform">{currentVal}</span>
                  </div>
                  <span className="text-[8px] font-black uppercase text-gray-600">{key.replace('eq', '')}</span>
                </div>
              );
            })}
          </div>
          <div className="pt-6 border-t border-white/5 space-y-4">
             <div className="flex justify-between text-[9px] font-black uppercase text-gray-500 tracking-widest">
               <span>Multiband Pressure</span>
               <span className="text-emerald-400">{(mastering.compression * 100).toFixed(0)}%</span>
             </div>
             <input 
               type="range" min="0" max="1" step="0.01" value={mastering.compression} 
               onChange={(e) => onMasteringChange('compression', parseFloat(e.target.value))}
               className="w-full accent-emerald-500 h-1 bg-gray-900 rounded-full appearance-none cursor-pointer"
             />
          </div>
        </div>
      </div>

      {/* FX & Expression Processor */}
      <div className="bg-black/20 p-8 rounded-[3rem] border border-white/5 flex flex-col h-full">
        <div className="flex justify-between items-center mb-8">
          <span className="text-[10px] font-black text-pink-500 uppercase tracking-widest">FX & Expression</span>
          <button 
            onClick={() => onFxChange('leadAftertouchEnabled', !fx.leadAftertouchEnabled)}
            className={`px-3 py-1 rounded-full text-[8px] font-black uppercase transition-all ${fx.leadAftertouchEnabled ? 'bg-pink-600 text-white shadow-[0_0_10px_rgba(236,72,153,0.5)]' : 'bg-gray-800 text-gray-500'}`}
          >
            {fx.leadAftertouchEnabled ? 'Link ON' : 'Link OFF'}
          </button>
        </div>
        
        <div className="flex-1 overflow-y-auto space-y-10 pr-2 scrollbar-hide">
          
          {/* Spatial Audio Section */}
          <div className="space-y-4">
            <div className="flex justify-between text-[9px] font-black uppercase text-gray-500 tracking-widest">
              <span>Spatial Reverb</span>
              <span className="text-pink-400">{currentPreset ? currentPreset.name : 'Custom'}</span>
            </div>
            <select
              className="w-full bg-gray-900 border border-gray-800 rounded-xl p-3 text-xs font-bold text-gray-300 outline-none focus:border-pink-500 transition-colors"
              value={currentPreset ? currentPreset.name : ''}
              onChange={(e) => {
                const p = REVERB_PRESETS.find(pre => pre.name === e.target.value);
                if (p) {
                  onFxChange('reverbDecay', p.decay);
                  onFxChange('reverbWet', p.wet);
                }
              }}
            >
              <option value="" disabled>Select Environment...</option>
              {REVERB_PRESETS.map(p => (
                <option key={p.name} value={p.name}>{p.name}</option>
              ))}
            </select>
          </div>

          {/* Support Harmony Section */}
          <div className="space-y-4 border-t border-white/5 pt-6">
            <div className="flex justify-between text-[9px] font-black uppercase text-gray-500 tracking-widest">
              <span>Harmony Blend</span>
              <span className="text-pink-400">{(fx.harmonyLevel! * 100).toFixed(0)}%</span>
            </div>
            <div className="relative h-1.5 bg-gray-900 rounded-full overflow-hidden border border-white/5">
              <div 
                className="absolute inset-y-0 left-0 bg-gradient-to-r from-pink-900 to-pink-500 transition-all duration-300" 
                style={{ width: `${fx.harmonyLevel! * 100}%` }}
              ></div>
              <input 
                type="range" min="0" max="1" step="0.01" value={fx.harmonyLevel} 
                onChange={(e) => onFxChange('harmonyLevel', parseFloat(e.target.value))} 
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" 
              />
            </div>
          </div>

          {/* Polyphonic Aftertouch Sensitivities */}
          <div className={`space-y-6 pt-6 border-t border-white/5 transition-opacity duration-500 ${fx.leadAftertouchEnabled ? 'opacity-100' : 'opacity-20 pointer-events-none'}`}>
             <div className="space-y-4">
               <div className="flex justify-between text-[9px] font-black uppercase text-gray-600 tracking-widest">
                 <span>Lead Aftertouch Pressure</span>
                 <span className="text-pink-500 font-mono">{(fx.leadAftertouch * 100).toFixed(0)}%</span>
               </div>
               <div className="relative h-4 bg-black rounded-full overflow-hidden border border-white/5">
                 <div 
                   className="absolute inset-y-0 left-0 bg-gradient-to-r from-pink-900 to-pink-400 transition-all duration-300 shadow-[0_0_20px_rgba(236,72,153,0.4)]" 
                   style={{ width: `${fx.leadAftertouch * 100}%` }}
                 ></div>
                 <input type="range" min="0" max="1" step="0.01" value={fx.leadAftertouch} onChange={(e) => onFxChange('leadAftertouch', parseFloat(e.target.value))} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10" />
               </div>
             </div>

             <div className="grid grid-cols-2 gap-6">
                <div className="space-y-3">
                   <label className="text-[8px] font-black uppercase text-gray-600 tracking-widest flex justify-between">
                     <span>Detune Sens</span>
                     <span className="text-pink-400">{fx.leadAftertouchDetuneSens}c</span>
                   </label>
                   <input 
                     type="range" min="0" max="200" step="1" value={fx.leadAftertouchDetuneSens} 
                     onChange={(e) => onFxChange('leadAftertouchDetuneSens', parseInt(e.target.value))}
                     className="w-full accent-pink-500 h-1 bg-gray-900 rounded-full appearance-none cursor-pointer"
                   />
                </div>
                <div className="space-y-3">
                   <label className="text-[8px] font-black uppercase text-gray-600 tracking-widest flex justify-between">
                     <span>Volume Sens</span>
                     <span className="text-pink-400">{fx.leadAftertouchVolSens}dB</span>
                   </label>
                   <input 
                     type="range" min="0" max="12" step="0.1" value={fx.leadAftertouchVolSens} 
                     onChange={(e) => onFxChange('leadAftertouchVolSens', parseFloat(e.target.value))}
                     className="w-full accent-pink-500 h-1 bg-gray-900 rounded-full appearance-none cursor-pointer"
                   />
                </div>
             </div>
             <p className="text-[7px] text-gray-700 uppercase tracking-widest italic text-center">Modulates active voices with velocity bias</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MixerRack;
