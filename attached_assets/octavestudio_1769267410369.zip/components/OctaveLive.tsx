
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality } from '@google/genai';
import { decode, decodeAudioData, createBlob } from '../utils/audioUtils';

const OctaveLive: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [transcript, setTranscript] = useState<string[]>([]);
  const [isThinking, setIsThinking] = useState(false);
  
  const sessionRef = useRef<any>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const inputContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const toggleSession = async () => {
    if (isActive) {
      sessionRef.current?.close?.();
      setIsActive(false);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      // Create a new GoogleGenAI instance right before making an API call
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      inputContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });

      // Connect session and handle input/output
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            const source = inputContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = inputContextRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              // CRITICAL: Solely rely on sessionPromise resolves and then call `session.sendRealtimeInput`
              sessionPromise.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputContextRef.current!.destination);
          },
          onmessage: async (message: any) => {
            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData && audioContextRef.current) {
              const buffer = await decodeAudioData(decode(audioData), audioContextRef.current, 24000, 1);
              const source = audioContextRef.current.createBufferSource();
              source.buffer = buffer;
              source.connect(audioContextRef.current.destination);
              
              const startTime = Math.max(nextStartTimeRef.current, audioContextRef.current.currentTime);
              source.start(startTime);
              nextStartTimeRef.current = startTime + buffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }

            if (message.serverContent?.outputTranscription) {
              setTranscript(prev => {
                const last = prev[prev.length - 1];
                const text = message.serverContent.outputTranscription.text;
                if (last && last.startsWith("Octave:")) {
                   const updated = [...prev];
                   updated[updated.length - 1] += text;
                   return updated;
                }
                return [...prev, `Octave: ${text}`];
              });
            }
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: "You are Octave, a brilliant music production AI. You are witty, punchy, and helpful. You speak like a seasoned producer from a legendary studio. Keep responses conversational and naturally short.",
          outputAudioTranscription: {}
        }
      });

      sessionRef.current = await sessionPromise;
      setIsActive(true);
    } catch (err) {
      console.error(err);
      alert("Mic access required for Live Studio.");
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-12 flex flex-col items-center space-y-12 min-h-[85vh] justify-center animate-in fade-in duration-1000">
      <div className={`w-80 h-80 rounded-full flex items-center justify-center relative transition-all duration-[2000ms] ${isActive ? 'scale-110 shadow-[0_0_100px_rgba(79,70,229,0.4)]' : 'grayscale opacity-50'}`}>
        <div className={`absolute inset-0 rounded-full bg-gradient-to-tr from-blue-500 via-indigo-600 to-purple-600 opacity-20 blur-3xl transition-transform duration-1000 ${isActive ? 'animate-pulse scale-150' : 'scale-0'}`}></div>
        <div className="relative z-10 w-64 h-64 rounded-full bg-gray-950 border-4 border-gray-900 flex items-center justify-center shadow-3xl">
          <div className={`text-9xl transition-all duration-500 ${isActive ? 'scale-110' : 'scale-90'}`}>
            {isActive ? '🎧' : '🎙️'}
          </div>
        </div>
      </div>

      <div className="text-center space-y-6 max-w-lg">
        <h2 className="text-5xl font-outfit font-black tracking-tighter text-white">Live Consultation</h2>
        <p className="text-gray-500 text-lg leading-relaxed">
          The low-latency audio engine is ready. Speak directly to Octave about your tracks, theory, or inspiration.
        </p>
      </div>

      <button
        onClick={toggleSession}
        className={`px-16 py-6 rounded-full font-black text-xl uppercase tracking-widest transition-all shadow-2xl ${
          isActive 
            ? 'bg-red-500 hover:bg-red-400 text-white shadow-red-900/40' 
            : 'bg-white text-black hover:bg-gray-200'
        }`}
      >
        {isActive ? 'End Session' : 'Establish Link'}
      </button>

      <div className="w-full bg-[#0a0f1d] rounded-[3rem] p-12 border border-gray-800 h-64 overflow-y-auto space-y-4 scrollbar-hide shadow-inner">
        {transcript.length === 0 && <p className="text-gray-700 text-center italic text-xl font-light">Session log is empty...</p>}
        {transcript.map((line, idx) => (
          <div key={idx} className="animate-in slide-in-from-bottom-2 duration-300">
            <span className="text-indigo-500 font-black mr-3 text-xs uppercase tracking-widest">Octave</span>
            <span className="text-gray-400 text-lg leading-relaxed font-sans">{line.replace("Octave:", "")}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default OctaveLive;
