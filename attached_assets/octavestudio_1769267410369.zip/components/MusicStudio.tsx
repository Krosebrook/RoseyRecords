
import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import * as Tone from 'tone';
import { generateSongConcept, generateImageVariations, generateSpeech, enhanceMix, generateProductionInsight, generateVideo } from '../services/geminiService';
import { saveProjectToLibrary } from '../services/storageService';
import { decode, decodeAudioData, formatSeconds } from '../utils/audioUtils';
import { generateMidiBlob } from '../utils/midiUtils';
import { SongMetadata, SongSection, SectionType, DrumPatterns } from '../types';
import MixerRack from './MixerRack';
import TimelineArranger from './TimelineArranger';
import DrumSequencer from './DrumSequencer';

interface MusicStudioProps {
  activeProject: SongMetadata | null;
  onProjectUpdate: (project: SongMetadata | null) => void;
}

const MusicStudio: React.FC<MusicStudioProps> = ({ activeProject, onProjectUpdate }) => {
  const [prompt, setPrompt] = useState('');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [isVideoGenerating, setIsVideoGenerating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isAudioLoading, setIsAudioLoading] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [currentStep, setCurrentStep] = useState(0);
  const [productionInsight, setProductionInsight] = useState('Syncing with studio intelligence...');
  
  const [mixer, setMixer] = useState(activeProject?.mixer || { vox: 0, drums: -6, bass: -12, lead: -12 });
  const [fx, setFx] = useState({ 
    reverbWet: 0.3, reverbDecay: 2.5, reverbGain: 0,
    delayWet: 0.1, delayFeedback: 0.4, delayTime: 0.5 as any, delayGain: 0,
    leadAftertouch: 0.5,
    leadAftertouchEnabled: true,
    leadAftertouchDetuneSens: 40, // cents
    leadAftertouchVolSens: 6, // dB
    harmonyLevel: 0.3 
  });
  const [mastering, setMastering] = useState({ eqHigh: 0, eqMid: 0, eqLow: 0, compression: 0.2 });
  const [levels, setLevels] = useState({ vox: 0, drums: 0, bass: 0, lead: 0, harmony: 0 });

  const [structure, setStructure] = useState<SongSection[]>(activeProject?.structure || [
    { id: '1', type: 'Intro', name: 'Intro', bars: 4 },
    { id: '2', type: 'Verse', name: 'Verse 1', bars: 16 },
    { id: '3', type: 'Chorus', name: 'Chorus 1', bars: 8 },
    { id: '4', type: 'Verse', name: 'Verse 2', bars: 16 },
    { id: '5', type: 'Chorus', name: 'Chorus 2', bars: 8 },
    { id: '6', type: 'Bridge', name: 'Bridge', bars: 8 },
    { id: '7', type: 'Chorus', name: 'Chorus 3', bars: 8 },
    { id: '8', type: 'Outro', name: 'Outro', bars: 8 },
  ]);

  // Default House/Techno Pattern
  const [patterns, setPatterns] = useState<DrumPatterns>(activeProject?.patterns || {
    kick: [true, false, false, false, true, false, false, false, true, false, false, false, true, false, false, false],
    snare: [false, false, false, false, true, false, false, false, false, false, false, false, true, false, false, false],
    hihat: [true, true, true, true, true, true, true, true, true, true, true, true, true, true, true, true],
    perc: [false, false, true, false, false, false, true, false, false, false, true, false, false, false, true, false]
  });

  const playerRef = useRef<Tone.Player | null>(null);
  const harmonyPlayerRef = useRef<Tone.Player | null>(null);
  const audioBufferRef = useRef<AudioBuffer | null>(null);
  const harmonyBufferRef = useRef<AudioBuffer | null>(null);
  
  // Synth Refs
  const synthsRef = useRef<{ 
    lead: Tone.PolySynth<Tone.Synth>;
    drums: {
      kick: Tone.MembraneSynth;
      snare: Tone.NoiseSynth;
      hihat: Tone.MetalSynth;
      perc: Tone.MembraneSynth;
    } 
  } | null>(null);

  const nodesRef = useRef<{
    voxGain: Tone.Gain;
    harmonyGain: Tone.Gain;
    drumsGain: Tone.Gain;
    bassGain: Tone.Gain;
    leadGain: Tone.Gain;
    leadFilter: Tone.Filter;
    meters: { vox: Tone.Meter; drums: Tone.Meter; bass: Tone.Meter; lead: Tone.Meter; harmony: Tone.Meter };
  } | null>(null);

  const effectsRef = useRef<any>(null);

  // Re-initialize state when activeProject changes externally (e.g. loading from library)
  useEffect(() => {
    if (activeProject) {
      if (activeProject.mixer) setMixer(activeProject.mixer);
      if (activeProject.structure) setStructure(activeProject.structure);
      if (activeProject.patterns) setPatterns(activeProject.patterns);
    } else {
      // Reset defaults if cleared
      setPrompt('');
      setStructure([
        { id: '1', type: 'Intro', name: 'Intro', bars: 4 },
        { id: '2', type: 'Verse', name: 'Verse 1', bars: 16 },
        { id: '3', type: 'Chorus', name: 'Chorus 1', bars: 8 },
        { id: '4', type: 'Verse', name: 'Verse 2', bars: 16 },
        { id: '5', type: 'Chorus', name: 'Chorus 2', bars: 8 },
        { id: '6', type: 'Bridge', name: 'Bridge', bars: 8 },
        { id: '7', type: 'Chorus', name: 'Chorus 3', bars: 8 },
        { id: '8', type: 'Outro', name: 'Outro', bars: 8 },
      ]);
    }
  }, [activeProject?.id]); 

  // Initialize Audio Engine
  useEffect(() => {
    const context = new Tone.Context({ latencyHint: "interactive" });
    Tone.setContext(context);

    // Busses
    const voxGain = new Tone.Gain(Tone.dbToGain(mixer.vox));
    const harmonyGain = new Tone.Gain(Tone.dbToGain(mixer.vox - 6));
    const drumsGain = new Tone.Gain(Tone.dbToGain(mixer.drums));
    const bassGain = new Tone.Gain(Tone.dbToGain(mixer.bass));
    const leadGain = new Tone.Gain(Tone.dbToGain(mixer.lead));
    const leadFilter = new Tone.Filter(2000, "lowpass", -24);
    
    // Meters
    const meters = { 
      vox: new Tone.Meter({ smoothing: 0.8 }), 
      drums: new Tone.Meter({ smoothing: 0.8 }), 
      bass: new Tone.Meter({ smoothing: 0.8 }), 
      lead: new Tone.Meter({ smoothing: 0.8 }),
      harmony: new Tone.Meter({ smoothing: 0.8 })
    };

    voxGain.connect(meters.vox);
    harmonyGain.connect(meters.harmony);
    drumsGain.connect(meters.drums);
    bassGain.connect(meters.bass);
    leadGain.connect(meters.lead);

    // Master Chain
    const masterLimiter = new Tone.Limiter(-1).toDestination();
    const masterComp = new Tone.Compressor({ threshold: -20, ratio: 4 }).connect(masterLimiter);
    const masterEq = new Tone.EQ3(0, 0, 0).connect(masterComp);

    // FX Sends
    const reverbOut = new Tone.Gain(0).connect(masterEq);
    const reverb = new Tone.Reverb({ decay: 2.5, wet: 0.3 }).connect(reverbOut);
    const delayOut = new Tone.Gain(0).connect(reverb);
    const delay = new Tone.FeedbackDelay({ delayTime: 0.5, feedback: 0.4, wet: 0.1 }).connect(delayOut);

    // Routing
    voxGain.connect(delay);
    harmonyGain.connect(reverb);
    drumsGain.connect(masterEq); 
    bassGain.connect(masterEq);
    leadFilter.connect(leadGain);
    leadGain.connect(delay);

    // Synthesizers initialization
    synthsRef.current = {
      lead: new Tone.PolySynth(Tone.Synth, { 
        oscillator: { type: "fatsawtooth", count: 3, spread: 30 },
        envelope: { attack: 0.05, decay: 0.2, sustain: 0.5, release: 1.5 }
      }).connect(leadFilter),
      drums: {
        kick: new Tone.MembraneSynth({ pitchDecay: 0.05, octaves: 4, oscillator: { type: 'sine' } }).connect(drumsGain),
        snare: new Tone.NoiseSynth({ noise: { type: 'white' }, envelope: { attack: 0.005, decay: 0.1, sustain: 0 } }).connect(drumsGain),
        hihat: new Tone.MetalSynth({ frequency: 200, envelope: { attack: 0.001, decay: 0.05, release: 0.01 }, harmonicity: 5.1, modulationIndex: 32, resonance: 4000, octaves: 1.5 }).connect(drumsGain),
        perc: new Tone.MembraneSynth({ pitchDecay: 0.02, octaves: 2, oscillator: { type: 'triangle' } }).connect(drumsGain)
      }
    };

    nodesRef.current = { voxGain, harmonyGain, drumsGain, bassGain, leadGain, leadFilter, meters };
    effectsRef.current = { reverb, reverbOut, delay, delayOut, eq: masterEq, comp: masterComp, analyser: new Tone.Analyser("fft", 256) };
    masterLimiter.connect(effectsRef.current.analyser);
    
    // Level Meter Loop
    const meterInterval = setInterval(() => {
      if (nodesRef.current) {
        setLevels({
          vox: Math.max(0, (nodesRef.current.meters.vox.getValue() as number + 60) / 60),
          drums: Math.max(0, (nodesRef.current.meters.drums.getValue() as number + 60) / 60),
          bass: Math.max(0, (nodesRef.current.meters.bass.getValue() as number + 60) / 60),
          lead: Math.max(0, (nodesRef.current.meters.lead.getValue() as number + 60) / 60),
          harmony: Math.max(0, (nodesRef.current.meters.harmony.getValue() as number + 60) / 60)
        });
      }
    }, 100);

    return () => { 
      clearInterval(meterInterval);
      stopAudio(); 
    };
  }, []);

  // Update mixer gains in real-time
  useEffect(() => {
    if (nodesRef.current) {
      nodesRef.current.voxGain.gain.rampTo(Tone.dbToGain(mixer.vox), 0.1);
      nodesRef.current.drumsGain.gain.rampTo(Tone.dbToGain(mixer.drums), 0.1);
      nodesRef.current.bassGain.gain.rampTo(Tone.dbToGain(mixer.bass), 0.1);
      
      if (!fx.leadAftertouchEnabled) {
        nodesRef.current.leadGain.gain.rampTo(Tone.dbToGain(mixer.lead), 0.1);
      }
    }
  }, [mixer, fx.leadAftertouchEnabled]);

  // Sync state to parent
  useEffect(() => {
    if (activeProject) {
      onProjectUpdate({
        ...activeProject,
        structure,
        patterns,
        mixer
      });
    }
  }, [structure, patterns, mixer]); 

  // Responsive Audio Engine for Polyphonic Aftertouch
  useEffect(() => {
    if (nodesRef.current && synthsRef.current) {
      if (fx.leadAftertouchEnabled) {
        const pressure = fx.leadAftertouch;
        const detuneAmount = (pressure * fx.leadAftertouchDetuneSens) - (fx.leadAftertouchDetuneSens / 2);
        synthsRef.current.lead.set({ detune: detuneAmount });
        const volBoost = pressure * fx.leadAftertouchVolSens;
        const targetDb = mixer.lead + volBoost;
        nodesRef.current.leadGain.gain.rampTo(Tone.dbToGain(targetDb), 0.05);
        const cutoff = 200 + (pressure * 12000);
        nodesRef.current.leadFilter.frequency.rampTo(cutoff, 0.05);
      } else {
        synthsRef.current.lead.set({ detune: 0 });
        nodesRef.current.leadGain.gain.rampTo(Tone.dbToGain(mixer.lead), 0.1);
        nodesRef.current.leadFilter.frequency.rampTo(2000, 0.1);
      }
    }
  }, [fx.leadAftertouch, fx.leadAftertouchEnabled, fx.leadAftertouchDetuneSens, fx.leadAftertouchVolSens, mixer.lead]);

  useEffect(() => {
    if (nodesRef.current && fx.harmonyLevel !== undefined) {
      const voxLevel = mixer.vox;
      const harmonyDb = voxLevel - (1.0 - fx.harmonyLevel) * 24; 
      nodesRef.current.harmonyGain.gain.rampTo(Tone.dbToGain(harmonyDb), 0.1);
    }
  }, [fx.harmonyLevel, mixer.vox]);

  const handleIntelligentEnhance = async () => {
    if (!activeProject || isEnhancing) return;
    setIsEnhancing(true);
    try {
      const blueprint = await enhanceMix(activeProject, mixer);
      setMixer(blueprint.mixer);
      setMastering(blueprint.mastering);
    } catch (e) { console.error("Mastering failed"); }
    finally { setIsEnhancing(false); }
  };

  const handleGenerate = async () => {
    if (!prompt || isGenerating) return;
    setIsGenerating(true);
    stopAudio();
    audioBufferRef.current = null;
    harmonyBufferRef.current = null;
    try {
      const concept = await generateSongConcept(prompt);
      const insight = await generateProductionInsight(concept);
      setProductionInsight(insight);
      
      const newProject: SongMetadata = {
        ...concept,
        id: Math.random().toString(36).substr(2, 9),
        coverArts: [],
        structure: structure,
        mixer: mixer,
        patterns: patterns
      };
      
      onProjectUpdate(newProject);
      const arts = await generateImageVariations(`Abstract kinetic visualization of ${newProject.genre}, high fidelity, neon pulse`, 4);
      onProjectUpdate({ ...newProject, coverArts: arts });
    } catch (err) { alert("Synthesizer failed."); }
    finally { setIsGenerating(false); }
  };

  const handleGenerateVideo = async () => {
    if (!activeProject || isVideoGenerating) return;
    setIsVideoGenerating(true);
    try {
      const videoPrompt = `Cinematic music video for ${activeProject.genre} song. Mood: ${activeProject.mood}. Energy: ${activeProject.energy}. High quality, 4k.`;
      // Use the first cover art as the seed image if available
      const seedImage = activeProject.coverArts?.[0] || undefined;
      const videoUrl = await generateVideo(videoPrompt, '16:9', seedImage);
      
      onProjectUpdate({
        ...activeProject,
        videoUrl: videoUrl
      });
    } catch (err) {
      console.error(err);
      alert("Video generation failed. Ensure you have a paid API key selected.");
    } finally {
      setIsVideoGenerating(false);
    }
  };

  const handleSaveToLibrary = () => {
    if (activeProject) {
      setIsSaving(true);
      const toSave = { ...activeProject, structure, patterns, mixer };
      saveProjectToLibrary(toSave);
      setTimeout(() => setIsSaving(false), 1000);
    }
  };

  const handleClearProject = () => {
    if (confirm("Start new project? Unsaved changes will be lost.")) {
      stopAudio();
      onProjectUpdate(null);
    }
  };

  const handleToggleStep = (lane: keyof DrumPatterns, step: number) => {
    setPatterns(prev => {
      const newLane = [...prev[lane]];
      newLane[step] = !newLane[step];
      return { ...prev, [lane]: newLane };
    });
  };

  const handleTogglePlay = async () => {
    if (isPlaying) { stopAudio(); return; }
    
    if (Tone.getContext().state !== 'running') {
      await Tone.getContext().resume();
    }

    if (!audioBufferRef.current && activeProject) {
      setIsAudioLoading(true);
      try {
        const [leadData, harmonyData] = await Promise.all([
          generateSpeech(activeProject.lyrics, 'Kore'),
          generateSpeech(activeProject.lyrics, 'Puck')
        ]);
        if (leadData) {
          audioBufferRef.current = await decodeAudioData(decode(leadData), Tone.getContext().rawContext as AudioContext, 24000, 1);
          setDuration(audioBufferRef.current.duration);
        }
        if (harmonyData) {
          harmonyBufferRef.current = await decodeAudioData(decode(harmonyData), Tone.getContext().rawContext as AudioContext, 24000, 1);
        }
      } catch (err) { alert("Sync failed."); }
      finally { setIsAudioLoading(false); }
    }
    
    await Tone.start();
    Tone.Transport.seconds = currentTime;

    Tone.Transport.cancel();
    let stepIndex = 0;
    
    Tone.Transport.scheduleRepeat((time) => {
      if (synthsRef.current) {
        const s = stepIndex % 16;
        Tone.Draw.schedule(() => {
          setCurrentStep(s);
          setCurrentTime(Tone.Transport.seconds);
        }, time);

        if (patterns.kick[s]) synthsRef.current.drums.kick.triggerAttackRelease("C1", "8n", time);
        if (patterns.snare[s]) synthsRef.current.drums.snare.triggerAttackRelease("16n", time);
        if (patterns.hihat[s]) synthsRef.current.drums.hihat.triggerAttackRelease("32n", time, 0.3);
        if (patterns.perc[s]) synthsRef.current.drums.perc.triggerAttackRelease("E4", "16n", time);

        if ([0, 3, 7, 10, 12].includes(s) && Math.random() > 0.4) {
          const notes = ["C4", "Eb4", "F4", "G4", "Bb4"];
          const note = notes[Math.floor(Math.random() * notes.length)];
          synthsRef.current.lead.triggerAttackRelease(note, "8n", time, 0.4 + Math.random() * 0.3);
        }
      }
      stepIndex++;
    }, "16n");
    
    if (audioBufferRef.current) {
      playerRef.current = new Tone.Player(audioBufferRef.current).connect(nodesRef.current?.voxGain!);
      playerRef.current.sync().start(0, currentTime);
    }
    
    if (harmonyBufferRef.current) {
      harmonyPlayerRef.current = new Tone.Player(harmonyBufferRef.current).connect(nodesRef.current?.harmonyGain!);
      harmonyPlayerRef.current.sync().start(0, currentTime);
    }

    Tone.Transport.start();
    setIsPlaying(true);
  };

  const stopAudio = () => {
    Tone.Transport.stop();
    playerRef.current?.dispose();
    harmonyPlayerRef.current?.dispose();
    setIsPlaying(false);
    setCurrentStep(0);
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-16 animate-in fade-in duration-1000 pb-32">
      <header className="text-center space-y-10 pt-16">
        <h1 className="text-[10rem] font-outfit font-extrabold tracking-tighter text-white leading-none">
          Octave<span className="text-indigo-500">Studio</span>
        </h1>
        <div className="max-w-5xl mx-auto bg-black/40 backdrop-blur-3xl p-4 rounded-[4rem] border border-white/5 shadow-4xl flex items-center gap-4">
          <input
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your sonic vision..."
            className="flex-1 bg-transparent px-10 py-6 text-2xl font-light outline-none text-white"
            onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
          />
          <button 
            onClick={handleGenerate}
            disabled={isGenerating || !prompt}
            className="bg-white text-black px-12 py-6 rounded-[2.5rem] font-black uppercase tracking-widest hover:bg-gray-200 transition-all disabled:opacity-50"
          >
            {isGenerating ? "Synthesizing..." : "Synthesize"}
          </button>
        </div>
      </header>

      {activeProject && (
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-8 space-y-10">
            <div className="bg-[#0a0f1d]/60 backdrop-blur-3xl border border-white/5 rounded-[4rem] p-16 shadow-4xl relative overflow-hidden">
               {/* Controls Header */}
               <div className="flex justify-between items-start mb-12 border-b border-white/5 pb-8">
                 <div className="space-y-4">
                   <h2 className="text-7xl font-outfit font-black text-white tracking-tighter">{activeProject.title}</h2>
                   <div className="flex gap-4">
                     <span className="px-4 py-1.5 bg-indigo-600/20 text-indigo-400 rounded-full text-[10px] font-black uppercase tracking-widest">{activeProject.genre}</span>
                     <span className="px-4 py-1.5 bg-emerald-600/20 text-emerald-400 rounded-full text-[10px] font-black uppercase tracking-widest">Mastering AI Enabled</span>
                   </div>
                 </div>
                 <div className="flex gap-4 items-center">
                   <div className="flex flex-col gap-2">
                     <button onClick={handleSaveToLibrary} className={`px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${isSaving ? 'bg-emerald-500 text-white' : 'bg-gray-800 hover:bg-white hover:text-black text-gray-400'}`}>
                       {isSaving ? 'Saved ✓' : 'Save to Vault'}
                     </button>
                     <button onClick={handleClearProject} className="px-6 py-3 rounded-full text-[10px] font-black uppercase tracking-widest bg-gray-900 text-gray-500 hover:text-red-400 transition-all">
                       New Project
                     </button>
                   </div>
                   <button onClick={handleTogglePlay} disabled={isAudioLoading} className="w-24 h-24 rounded-full bg-indigo-600 hover:scale-110 transition-all flex items-center justify-center text-3xl shadow-3xl shadow-indigo-500/40">
                     {isAudioLoading ? "..." : (isPlaying ? "⏸" : "▶")}
                   </button>
                 </div>
               </div>
               
               {/* Main Studio Views */}
               <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-6">
                    <h4 className="text-[10px] font-black text-gray-500 uppercase tracking-[0.4em]">Lyric Matrix</h4>
                    <p className="text-3xl font-serif italic text-gray-500 leading-relaxed max-h-64 overflow-y-auto pr-4 scrollbar-hide">{activeProject.lyrics}</p>
                  </div>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.4em]">Engine Insights</h4>
                      <button onClick={handleIntelligentEnhance} disabled={isEnhancing} className={`text-[9px] font-black uppercase tracking-widest px-4 py-2 rounded-full border ${isEnhancing ? 'border-indigo-500/50 text-indigo-500 animate-pulse' : 'border-white/10 text-gray-400 hover:text-white'}`}>
                        {isEnhancing ? 'Mastering...' : 'Intelligent Enhance'}
                      </button>
                    </div>
                    <div className="p-8 bg-black/40 border border-white/5 rounded-[2.5rem] space-y-4">
                       <p className="text-xs text-indigo-300 leading-relaxed font-medium italic">"{productionInsight}"</p>
                    </div>
                  </div>
               </div>

               <div className="mt-16 pt-16 border-t border-white/5 space-y-16">
                 {/* Arranger */}
                 <TimelineArranger 
                   structure={structure} setStructure={setStructure} 
                   loopSectionId={null} isLooping={false} onToggleLoop={() => {}} 
                 />
                 
                 {/* Drum Machine */}
                 <DrumSequencer 
                   patterns={patterns} 
                   onToggleStep={handleToggleStep} 
                   currentStep={currentStep} 
                   isPlaying={isPlaying} 
                 />

                 {/* Mixer */}
                 <MixerRack 
                   mixer={mixer} onMixerChange={(k, v) => setMixer({...mixer, [k]: v})}
                   fx={fx} onFxChange={(k, v) => setFx({...fx, [k]: v})}
                   mastering={mastering} onMasteringChange={(k, v) => setMastering({...mastering, [k]: v})}
                   levels={levels}
                 />
               </div>
            </div>
          </div>
          
          <aside className="lg:col-span-4 space-y-10">
            <div className="bg-[#0a0f1d]/60 backdrop-blur-3xl border border-white/5 rounded-[4rem] p-10 shadow-4xl space-y-8">
               <h3 className="text-3xl font-outfit font-black text-white tracking-tighter">Sonic DNA</h3>
               
               {/* Visual & Video Engine Integration */}
               <div className="relative aspect-square bg-gray-950 rounded-[3rem] overflow-hidden border border-white/5 shadow-inner group">
                  {activeProject.videoUrl ? (
                    <video 
                      src={activeProject.videoUrl} 
                      className="w-full h-full object-cover" 
                      autoPlay loop muted playsInline 
                    />
                  ) : activeProject.coverArts?.[0] ? (
                    <img src={activeProject.coverArts[0]} className="w-full h-full object-cover" alt="Art" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center opacity-5 text-9xl">💿</div>
                  )}

                  {/* Veo Reality Engine Overlay */}
                  <div className="absolute inset-0 bg-black/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center p-6 text-center space-y-4">
                    <span className="text-xl font-outfit font-black text-indigo-400 uppercase tracking-tighter">Veo Reality Engine</span>
                    <p className="text-xs text-gray-400">Generate a cinematic 4K music video based on your track's mood and album art.</p>
                    <button 
                      onClick={handleGenerateVideo}
                      disabled={isVideoGenerating}
                      className="px-6 py-3 bg-white text-black rounded-full text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-transform disabled:opacity-50"
                    >
                      {isVideoGenerating ? 'Rendering Video...' : activeProject.videoUrl ? 'Regenerate Video' : 'Animate DNA'}
                    </button>
                  </div>
               </div>

               <div className="pt-6 border-t border-white/5 space-y-4">
                  <div className="flex justify-between text-[10px] font-black text-gray-600 uppercase tracking-widest">
                    <span>Master Peak</span>
                    <span className="text-emerald-500">-0.3dB</span>
                  </div>
                  <div className="h-1.5 w-full bg-gray-900 rounded-full overflow-hidden">
                    <div className="h-full bg-gradient-to-r from-indigo-600 to-emerald-400" style={{ width: '92%' }}></div>
                  </div>
               </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
};

export default MusicStudio;
