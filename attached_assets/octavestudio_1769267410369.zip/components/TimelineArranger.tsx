
import React from 'react';
import { SongSection, SectionType } from '../types';

interface TimelineArrangerProps {
  structure: SongSection[];
  setStructure: (s: SongSection[]) => void;
  onToggleLoop: (id: string) => void;
  loopSectionId: string | null;
  isLooping: boolean;
}

const THEMES: Record<SectionType, { border: string; text: string; bg: string; active: string }> = {
  Intro: { border: 'border-blue-500/30', text: 'text-blue-400', bg: 'bg-blue-500/5', active: 'border-blue-400 bg-blue-500/20 ring-4 ring-blue-500/30 shadow-2xl scale-105' },
  Verse: { border: 'border-emerald-500/30', text: 'text-emerald-400', bg: 'bg-emerald-500/5', active: 'border-emerald-400 bg-emerald-500/20 ring-4 ring-emerald-500/30 shadow-2xl scale-105' },
  Chorus: { border: 'border-pink-500/30', text: 'text-pink-400', bg: 'bg-pink-500/5', active: 'border-pink-400 bg-pink-500/20 ring-4 ring-pink-500/30 shadow-2xl scale-105' },
  Bridge: { border: 'border-amber-500/30', text: 'text-amber-400', bg: 'bg-amber-500/5', active: 'border-amber-400 bg-amber-500/20 ring-4 ring-amber-500/30 shadow-2xl scale-105' },
  Outro: { border: 'border-purple-500/30', text: 'text-purple-400', bg: 'bg-purple-500/5', active: 'border-purple-400 bg-purple-500/20 ring-4 ring-purple-500/30 shadow-2xl scale-105' },
};

const TimelineArranger: React.FC<TimelineArrangerProps> = ({ structure, setStructure, onToggleLoop, loopSectionId, isLooping }) => {
  const [draggedId, setDraggedId] = React.useState<string | null>(null);

  const handleDragStart = (id: string) => setDraggedId(id);
  const handleDragOver = (e: React.DragEvent, id: string) => {
    e.preventDefault();
    if (draggedId === id) return;
    
    const draggedIdx = structure.findIndex(s => s.id === draggedId);
    const targetIdx = structure.findIndex(s => s.id === id);
    
    const newStructure = [...structure];
    const [removed] = newStructure.splice(draggedIdx, 1);
    newStructure.splice(targetIdx, 0, removed);
    setStructure(newStructure);
  };

  const addSection = (type: SectionType) => {
    const newSection: SongSection = {
      id: Math.random().toString(36).substr(2, 9),
      type,
      name: `${type} ${structure.filter(s => s.type === type).length + 1}`,
      bars: type === 'Verse' ? 16 : 8
    };
    setStructure([...structure, newSection]);
  };

  const removeSection = (id: string) => setStructure(structure.filter(s => s.id !== id));

  return (
    <div className="space-y-10 animate-in slide-in-from-top-12 duration-700">
      <div className="flex flex-wrap gap-3 justify-center">
        {(['Intro', 'Verse', 'Chorus', 'Bridge', 'Outro'] as SectionType[]).map(t => (
          <button 
            key={t} onClick={() => addSection(t)} 
            className="px-5 py-2.5 bg-gray-900 border border-gray-800 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-gray-800 hover:border-indigo-500/50 transition-all"
          >
            + {t}
          </button>
        ))}
      </div>

      <div className="flex flex-wrap gap-6 justify-center">
        {structure.map((s, idx) => {
          const isActive = loopSectionId === s.id && isLooping;
          const theme = THEMES[s.type];
          return (
            <div 
              key={s.id} 
              draggable 
              onDragStart={() => handleDragStart(s.id)}
              onDragOver={(e) => handleDragOver(e, s.id)}
              className="relative group cursor-grab active:cursor-grabbing"
            >
              <div 
                onClick={() => onToggleLoop(s.id)}
                className={`w-40 p-6 rounded-[2.5rem] border-2 transition-all duration-500 flex flex-col items-center gap-1 ${isActive ? theme.active : `${theme.border} ${theme.bg} hover:border-gray-500`}`}
              >
                <div className="text-[9px] font-black opacity-30 uppercase tracking-[0.2em]">P.{idx+1}</div>
                <div className="text-lg font-outfit font-extrabold text-white truncate max-w-full">{s.name}</div>
                <div className="text-[9px] font-bold opacity-50 uppercase">{s.bars} Bars</div>
                {isActive && <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-indigo-500 text-[8px] font-black px-3 py-1 rounded-full uppercase tracking-widest shadow-lg">Looping</div>}
              </div>
              <button 
                onClick={(e) => { e.stopPropagation(); removeSection(s.id); }}
                className="absolute -top-2 -right-2 bg-red-600/90 hover:bg-red-500 w-8 h-8 rounded-full text-xs font-bold opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center shadow-xl transform group-hover:scale-110"
              >
                ×
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default TimelineArranger;
