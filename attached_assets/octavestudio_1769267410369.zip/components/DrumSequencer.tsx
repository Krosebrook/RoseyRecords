
import React from 'react';
import { DrumPatterns } from '../types';

interface DrumSequencerProps {
  patterns: DrumPatterns;
  onToggleStep: (lane: keyof DrumPatterns, step: number) => void;
  currentStep: number;
  isPlaying: boolean;
}

const DrumSequencer: React.FC<DrumSequencerProps> = ({ patterns, onToggleStep, currentStep, isPlaying }) => {
  const lanes: { id: keyof DrumPatterns; label: string; color: string }[] = [
    { id: 'hihat', label: 'Hi-Hat', color: 'bg-amber-400' },
    { id: 'snare', label: 'Snare', color: 'bg-pink-500' },
    { id: 'kick', label: 'Kick', color: 'bg-indigo-500' },
    { id: 'perc', label: 'Perc', color: 'bg-emerald-400' },
  ];

  return (
    <div className="bg-black/60 p-8 rounded-[3rem] border border-gray-800 shadow-3xl overflow-hidden backdrop-blur-md">
      <div className="flex justify-between items-center mb-8">
        <div className="flex flex-col">
          <span className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.3em]">Pattern Matrix</span>
          <span className="text-[8px] text-gray-600 uppercase">16-Step Synced Logic</span>
        </div>
        <div className="flex gap-1">
          {Array.from({ length: 16 }).map((_, i) => (
            <div 
              key={i} 
              className={`w-1 h-1 rounded-full transition-all duration-100 ${isPlaying && currentStep === i ? 'bg-indigo-400 scale-150 shadow-[0_0_8px_rgba(129,140,248,0.8)]' : 'bg-gray-800'}`} 
            />
          ))}
        </div>
      </div>

      <div className="space-y-4">
        {lanes.map((lane) => (
          <div key={lane.id} className="flex items-center gap-6">
            <div className="w-16">
              <span className="text-[10px] font-bold text-gray-500 uppercase tracking-tighter">{lane.label}</span>
            </div>
            {/* Using arbitrary value for grid-cols-16 as standard tailwind only goes to 12 */}
            <div className="flex-1 grid grid-cols-[repeat(16,minmax(0,1fr))] gap-2">
              {patterns[lane.id].map((active, step) => (
                <button
                  key={step}
                  onClick={() => onToggleStep(lane.id, step)}
                  className={`aspect-square rounded-md border transition-all duration-100 relative overflow-hidden group ${
                    active 
                      ? `${lane.color} border-transparent shadow-[0_0_10px_rgba(0,0,0,0.3)]` 
                      : 'bg-gray-900 border-gray-800 hover:border-gray-600'
                  } ${isPlaying && currentStep === step ? 'ring-2 ring-white/80 z-10 scale-110' : ''}`}
                >
                  {/* Subtle shine effect on active steps */}
                  {active && <div className="absolute inset-0 bg-white/20 opacity-0 group-hover:opacity-100 transition-opacity" />}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default DrumSequencer;
