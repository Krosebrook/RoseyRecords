
import React, { useEffect, useState } from 'react';
import { SongMetadata } from '../types';
import { getLibrary, deleteProjectFromLibrary, exportProject } from '../services/storageService';

interface LibraryProps {
  onLoadProject: (project: SongMetadata) => void;
}

const Library: React.FC<LibraryProps> = ({ onLoadProject }) => {
  const [projects, setProjects] = useState<SongMetadata[]>([]);
  const [filter, setFilter] = useState('');

  const loadProjects = () => {
    setProjects(getLibrary());
  };

  useEffect(() => {
    loadProjects();
  }, []);

  const handleDelete = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    if (window.confirm("Are you sure you want to delete this track? This cannot be undone.")) {
      deleteProjectFromLibrary(id);
      loadProjects();
    }
  };

  const filteredProjects = projects.filter(p => 
    p.title.toLowerCase().includes(filter.toLowerCase()) || 
    p.genre.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="max-w-7xl mx-auto p-8 space-y-8 pb-32 animate-in fade-in duration-700">
      <div className="flex flex-col md:flex-row justify-between items-end gap-6 border-b border-gray-800 pb-8">
        <div className="space-y-4">
          <h2 className="text-5xl font-outfit font-black text-white tracking-tighter">
            Project <span className="text-indigo-500">Vault</span>
          </h2>
          <p className="text-gray-400 max-w-lg">
            Archived sessions, sonic concepts, and generated assets.
          </p>
        </div>
        
        <div className="w-full md:w-auto">
          <input 
            type="text" 
            placeholder="Search archives..." 
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="w-full md:w-64 bg-gray-900 border border-gray-800 rounded-2xl px-6 py-3 text-sm outline-none focus:border-indigo-500 transition-colors"
          />
        </div>
      </div>

      {projects.length === 0 ? (
        <div className="flex flex-col items-center justify-center h-96 text-gray-700 space-y-4 border-2 border-dashed border-gray-800 rounded-[3rem]">
          <div className="text-6xl grayscale opacity-20">📦</div>
          <p className="font-outfit font-bold uppercase tracking-widest text-sm">Library Empty</p>
          <p className="text-xs text-gray-600">Save your first project in the Studio</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <div 
              key={project.id}
              onClick={() => onLoadProject(project)}
              className="group bg-[#0a0f1d] border border-gray-800 rounded-[2rem] p-4 hover:border-indigo-500/50 hover:shadow-2xl hover:-translate-y-1 transition-all duration-300 cursor-pointer relative overflow-hidden"
            >
              {/* Card Background Gradient */}
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/80 z-10 pointer-events-none" />
              
              <div className="relative aspect-video rounded-[1.5rem] overflow-hidden bg-gray-900 mb-4 border border-white/5">
                {project.coverArts && project.coverArts[0] ? (
                  <img src={project.coverArts[0]} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" alt={project.title} />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-4xl opacity-10">🎵</div>
                )}
                
                <div className="absolute top-3 left-3 z-20">
                  <span className="bg-black/60 backdrop-blur-md border border-white/10 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-white">
                    {project.genre}
                  </span>
                </div>
              </div>

              <div className="relative z-20 px-2 pb-2 space-y-1">
                <h3 className="text-2xl font-outfit font-extrabold text-white truncate">{project.title}</h3>
                <div className="flex justify-between items-center text-xs text-gray-500 font-medium">
                  <span>{project.bpm} BPM • {project.key}</span>
                  <span className="capitalize">{project.mood}</span>
                </div>
              </div>

              {/* Actions Overlay */}
              <div className="absolute top-4 right-4 z-30 flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity translate-x-4 group-hover:translate-x-0 duration-300">
                <button 
                  onClick={(e) => { e.stopPropagation(); exportProject(project); }}
                  className="w-8 h-8 bg-gray-800/80 backdrop-blur hover:bg-white hover:text-black rounded-full flex items-center justify-center transition-colors"
                  title="Download JSON"
                >
                  ↓
                </button>
                <button 
                  onClick={(e) => handleDelete(e, project.id)}
                  className="w-8 h-8 bg-red-500/20 backdrop-blur hover:bg-red-500 text-red-500 hover:text-white border border-red-500/30 rounded-full flex items-center justify-center transition-all"
                  title="Delete"
                >
                  ×
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Library;
