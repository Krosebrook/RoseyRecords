
import React from 'react';
import { AppView } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  activeView: AppView;
  setActiveView: (view: AppView) => void;
}

const Layout: React.FC<LayoutProps> = ({ children, activeView, setActiveView }) => {
  const navItems = [
    { id: AppView.STUDIO, icon: '🎵', label: 'Music Studio' },
    { id: AppView.LIVE, icon: '🎙️', label: 'Octave Live' },
    { id: AppView.ASSISTANT, icon: '🤖', label: 'AI Assistant' },
    { id: AppView.GALLERY, icon: '📦', label: 'My Library' },
  ];

  return (
    <div className="flex h-screen bg-[#030712] text-gray-100 overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 bg-[#0a0f1d] border-r border-gray-800 flex flex-col hidden md:flex">
        <div className="p-6">
          <h1 className="text-2xl font-outfit font-extrabold bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
            OCTAVE STUDIO
          </h1>
        </div>
        <nav className="flex-1 px-4 space-y-2 mt-4">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all ${
                activeView === item.id 
                  ? 'bg-blue-600/20 text-blue-400 border border-blue-600/30' 
                  : 'text-gray-400 hover:bg-gray-800 hover:text-white'
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              <span className="font-medium">{item.label}</span>
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-gray-800 text-xs text-gray-500">
          Powered by Gemini 3.0 & Veo
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden bg-[#0a0f1d] border-bottom border-gray-800 p-4 flex justify-between items-center">
          <h1 className="text-xl font-outfit font-extrabold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
            OCTAVE
          </h1>
          <div className="flex space-x-4">
             {navItems.map((item) => (
                <button key={item.id} onClick={() => setActiveView(item.id)} className="text-lg">
                  {item.icon}
                </button>
             ))}
          </div>
        </header>

        <div className="flex-1 overflow-y-auto">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;
