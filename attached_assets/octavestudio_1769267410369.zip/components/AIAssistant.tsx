
import React, { useState, useRef } from 'react';
import { smartAssistant, transcribeAudio, getFastResponse } from '../services/geminiService';

const AIAssistant: React.FC = () => {
  const [query, setQuery] = useState('');
  const [response, setResponse] = useState<{ text?: string, sources: any[] } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isRecording, setIsRecording] = useState(false);
  const [tools, setTools] = useState({ search: true, maps: false, thinking: false });
  const [useFastModel, setUseFastModel] = useState(false);
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const handleAsk = async () => {
    if (!query || isLoading) return;
    setIsLoading(true);
    setResponse(null);
    try {
      if (useFastModel) {
        const text = await getFastResponse(query);
        setResponse({ text, sources: [] });
      } else {
        const res = await smartAssistant(query, tools);
        setResponse(res);
      }
    } catch (err) { alert("Error communicating with Gemini."); }
    finally { setIsLoading(false); }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      audioChunksRef.current = [];
      recorder.ondataavailable = (e) => audioChunksRef.current.push(e.data);
      recorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        const reader = new FileReader();
        reader.onload = async (e) => {
          const base64 = (e.target?.result as string).split(',')[1];
          setIsLoading(true);
          try {
            const text = await transcribeAudio(base64);
            setQuery(text || '');
          } catch (err) { console.error("Transcription failed"); }
          finally { setIsLoading(false); }
        };
        reader.readAsDataURL(audioBlob);
      };
      recorder.start();
      mediaRecorderRef.current = recorder;
      setIsRecording(true);
    } catch (e) { alert("Mic access denied"); }
  };

  const stopRecording = () => {
    mediaRecorderRef.current?.stop();
    setIsRecording(false);
  };

  return (
    <div className="max-w-5xl mx-auto p-12 space-y-12 animate-in fade-in duration-1000 pb-32">
      <div className="bg-[#0a0f1d] border border-gray-800 rounded-[3.5rem] p-12 space-y-12 shadow-2xl">
        <div className="flex justify-between items-center">
          <h2 className="text-5xl font-black font-outfit text-white tracking-tighter">Sonic <span className="text-indigo-500">Intelligence</span></h2>
          <div className="flex gap-2">
            <button 
              onClick={() => setUseFastModel(!useFastModel)}
              className={`px-4 py-2 rounded-full text-[10px] font-black uppercase transition-all ${useFastModel ? 'bg-orange-600 text-white' : 'bg-gray-800 text-gray-500'}`}
            >
              Lite Engine: {useFastModel ? 'ON' : 'OFF'}
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
           <button 
             onClick={() => setTools(t => ({...t, thinking: !t.thinking}))}
             className={`p-6 rounded-[2rem] border-2 transition-all ${tools.thinking ? 'bg-purple-600/20 border-purple-500 text-white shadow-xl' : 'bg-gray-900 border-gray-800 text-gray-600'}`}
           >
             <div className="text-3xl mb-2">🧠</div>
             <div className="text-[10px] font-black uppercase">Thinking Mode</div>
           </button>
           <button 
             onClick={() => setTools(t => ({...t, search: !t.search}))}
             className={`p-6 rounded-[2rem] border-2 transition-all ${tools.search ? 'bg-blue-600/20 border-blue-500 text-white shadow-xl' : 'bg-gray-900 border-gray-800 text-gray-600'}`}
           >
             <div className="text-3xl mb-2">🌐</div>
             <div className="text-[10px] font-black uppercase">Web Grounding</div>
           </button>
           <button 
             onClick={() => setTools(t => ({...t, maps: !t.maps}))}
             className={`p-6 rounded-[2rem] border-2 transition-all ${tools.maps ? 'bg-emerald-600/20 border-emerald-500 text-white shadow-xl' : 'bg-gray-900 border-gray-800 text-gray-600'}`}
           >
             <div className="text-3xl mb-2">📍</div>
             <div className="text-[10px] font-black uppercase">Local Grounding</div>
           </button>
        </div>

        <div className="relative">
          <textarea
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Ask Octave anything about your production..."
            className="w-full bg-gray-950 border border-gray-900 rounded-[2.5rem] p-10 min-h-[200px] outline-none text-xl font-light text-gray-300 shadow-inner resize-none"
          />
          <div className="absolute bottom-8 right-8 flex gap-4">
            <button
              onMouseDown={startRecording}
              onMouseUp={stopRecording}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${isRecording ? 'bg-red-500 scale-110 shadow-lg' : 'bg-gray-800 hover:bg-gray-700'}`}
            >
              🎙️
            </button>
            <button
              onClick={handleAsk}
              disabled={isLoading || !query}
              className="bg-indigo-600 hover:bg-indigo-500 px-12 py-5 rounded-3xl font-black uppercase tracking-widest text-xs transition-all disabled:opacity-50"
            >
              {isLoading ? '...' : 'Execute'}
            </button>
          </div>
        </div>
      </div>

      {response && (
        <div className="space-y-8 animate-in slide-in-from-bottom-8 duration-700">
          <div className="bg-[#0a0f1d] p-12 rounded-[3.5rem] border border-gray-800 shadow-2xl">
            <div className="prose prose-invert max-w-none text-gray-300 text-xl font-sans whitespace-pre-wrap leading-relaxed">
              {response.text}
            </div>
          </div>

          {response.sources.length > 0 && (
            <div className="bg-indigo-950/10 p-10 rounded-[3rem] border border-indigo-900/20">
              <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-6">Grounding Sources</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {response.sources.map((chunk: any, i: number) => {
                  const data = chunk.web || chunk.maps;
                  if (!data) return null;
                  return (
                    <a 
                      key={i} href={data.uri} target="_blank" rel="noopener noreferrer"
                      className="flex items-center justify-between bg-gray-900/40 hover:bg-gray-800 p-6 rounded-2xl border border-gray-800 hover:border-indigo-500 transition-all"
                    >
                      <span className="text-sm font-bold text-gray-500 truncate mr-6">{data.title || data.uri}</span>
                      <span className="text-indigo-500">↗</span>
                    </a>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AIAssistant;
