
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { generateImage, generateVideo, editImage, analyzeMedia } from '../services/geminiService';
import { SongMetadata } from '../types';

interface VisualStudioProps {
  activeProject: SongMetadata | null;
}

const STYLE_PRESETS = [
  { id: 'none', name: 'None', prompt: '' },
  { id: 'cyber', name: 'Cyberpunk', prompt: 'neon glowing lights, futuristic city, cinematic cyberpunk aesthetic' },
  { id: 'lofi', name: 'Lo-fi', prompt: 'pastel colors, anime style, chill atmosphere' },
  { id: 'noir', name: 'Noir', prompt: 'black and white, high contrast, shadows' },
  { id: 'vapor', name: 'Vaporwave', prompt: 'pink and teal aesthetic, glitch art, surreal landscape' },
];

const VisualStudio: React.FC<VisualStudioProps> = ({ activeProject }) => {
  const [prompt, setPrompt] = useState('');
  const [editPrompt, setEditPrompt] = useState('');
  const [preset, setPreset] = useState('none');
  const [aspectRatio, setAspectRatio] = useState('1:1');
  const [size, setSize] = useState('1K');
  const [image, setImage] = useState<string | null>(null);
  const [video, setVideo] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [influenceByMusic, setInfluenceByMusic] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const getSyncPrompt = useCallback(() => {
    if (!activeProject) return '';
    const p = STYLE_PRESETS.find(s => s.id === preset)?.prompt || '';
    return `Visual interpretation of ${activeProject.genre} song "${activeProject.title}". Mood: ${activeProject.mood}. Energy: ${activeProject.energy}. ${p}. Ultra-high fidelity.`;
  }, [activeProject, preset]);

  useEffect(() => {
    if (activeProject && influenceByMusic) {
      setPrompt(getSyncPrompt());
    }
  }, [activeProject, influenceByMusic, getSyncPrompt]);

  const handleGenerateImage = async () => {
    setIsLoading(true);
    setVideo(null);
    setAnalysis(null);
    try {
      const res = await generateImage(prompt, aspectRatio, size);
      setImage(res);
    } catch (err) { alert("Generation failed. Check if API key is set."); }
    finally { setIsLoading(false); }
  };

  const handleEditImage = async () => {
    if (!image || !editPrompt) return;
    setIsLoading(true);
    try {
      const res = await editImage(image, editPrompt);
      if (res) setImage(res);
    } catch (err) { alert("Edit failed."); }
    finally { setIsLoading(false); }
  };

  const handleAnimate = async () => {
    setIsLoading(true);
    setAnalysis(null);
    try {
      const res = await generateVideo(prompt || "Cinematic sequence", aspectRatio === '9:16' ? '9:16' : '16:9', image || undefined);
      setVideo(res);
    } catch (err) { alert("Video generation failed. Paid API key usually required for Veo."); }
    finally { setIsLoading(false); }
  };

  const handleAnalyze = async (file?: File) => {
    setIsLoading(true);
    try {
      let dataUrl = image;
      let mimeType = 'image/png';
      if (file) {
        dataUrl = await new Promise((res) => {
          const reader = new FileReader();
          reader.onload = (e) => res(e.target?.result as string);
          reader.readAsDataURL(file);
        });
        mimeType = file.type;
      }
      if (!dataUrl) throw new Error("No media to analyze");
      const res = await analyzeMedia(dataUrl, mimeType, "Analyze this media and explain its visual style and mood.");
      setAnalysis(res);
    } catch (err) { alert("Analysis failed."); }
    finally { setIsLoading(false); }
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8 pb-32 animate-in fade-in duration-1000">
      <div className="flex flex-col lg:flex-row gap-10">
        <aside className="w-full lg:w-96 space-y-6">
          <div className="bg-[#0a0f1d] border border-gray-800 rounded-[2.5rem] p-8 space-y-6 shadow-2xl">
            <h3 className="text-2xl font-outfit font-bold text-white flex items-center gap-2">
              <span className="text-indigo-500">Visual</span> Engine
            </h3>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Prompt</label>
                <button 
                  onClick={() => setInfluenceByMusic(!influenceByMusic)}
                  className={`text-[8px] px-2 py-1 rounded-full font-bold uppercase transition-all ${influenceByMusic ? 'bg-indigo-600/20 text-indigo-400' : 'bg-gray-800 text-gray-500'}`}
                >
                  Sync Music: {influenceByMusic ? 'ON' : 'OFF'}
                </button>
              </div>
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                rows={3}
                className="w-full bg-gray-950 border border-gray-900 rounded-2xl p-4 text-sm text-gray-300 outline-none focus:ring-1 focus:ring-indigo-500"
                placeholder="A digital dreamscape..."
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Ratio</label>
                <select value={aspectRatio} onChange={(e) => setAspectRatio(e.target.value)} className="w-full bg-gray-950 border border-gray-900 rounded-xl p-3 text-sm outline-none">
                  {['1:1', '2:3', '3:2', '3:4', '4:3', '9:16', '16:9', '21:9'].map(r => <option key={r}>{r}</option>)}
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Res</label>
                <select value={size} onChange={(e) => setSize(e.target.value)} className="w-full bg-gray-950 border border-gray-900 rounded-xl p-3 text-sm outline-none">
                  {['1K', '2K', '4K'].map(s => <option key={s}>{s}</option>)}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <button 
                onClick={handleGenerateImage} disabled={isLoading}
                className="col-span-2 bg-indigo-600 hover:bg-indigo-500 py-4 rounded-2xl font-bold transition-all shadow-lg"
              >
                Render Image
              </button>
              <button 
                onClick={handleAnimate} disabled={isLoading}
                className="bg-purple-600/20 text-purple-400 border border-purple-600/30 py-3 rounded-xl font-bold text-xs uppercase"
              >
                Veo Video
              </button>
              <button 
                onClick={() => handleAnalyze()} disabled={isLoading || !image}
                className="bg-gray-800 text-gray-400 py-3 rounded-xl font-bold text-xs uppercase hover:bg-gray-700"
              >
                Analyze
              </button>
            </div>

            {image && (
              <div className="space-y-3 pt-4 border-t border-gray-800">
                <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">AI Image Editor</label>
                <input 
                  value={editPrompt} onChange={(e) => setEditPrompt(e.target.value)}
                  placeholder="e.g. 'Add retro filter'"
                  className="w-full bg-gray-950 border border-gray-900 rounded-xl p-3 text-sm outline-none"
                />
                <button onClick={handleEditImage} className="w-full bg-emerald-600/20 text-emerald-400 border border-emerald-600/30 py-2 rounded-xl text-xs font-bold uppercase">Apply Edit</button>
              </div>
            )}
            
            <button 
              onClick={() => fileInputRef.current?.click()}
              className="w-full bg-gray-900 border border-gray-800 text-gray-500 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest hover:text-white transition-all"
            >
              Upload Photo/Video
            </button>
            <input type="file" hidden ref={fileInputRef} onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) {
                if (f.type.startsWith('image/')) {
                  const reader = new FileReader();
                  reader.onload = (ev) => setImage(ev.target?.result as string);
                  reader.readAsDataURL(f);
                } else {
                  handleAnalyze(f);
                }
              }
            }} />
          </div>
        </aside>

        <main className="flex-1 flex flex-col min-h-[600px] bg-[#0a0f1d] border border-gray-800 rounded-[3rem] overflow-hidden relative shadow-2xl">
          {isLoading && (
            <div className="absolute inset-0 z-20 bg-black/80 backdrop-blur-xl flex flex-col items-center justify-center space-y-4">
              <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
              <p className="text-indigo-400 font-outfit font-bold uppercase tracking-[0.4em] animate-pulse">Neural Synthesizing...</p>
            </div>
          )}

          <div className="flex-1 flex flex-col items-center justify-center p-10 overflow-y-auto">
            {video ? (
              <video src={video} controls autoPlay loop className="max-w-full max-h-[80vh] rounded-2xl shadow-2xl" />
            ) : image ? (
              <img src={image} className="max-w-full max-h-[80vh] rounded-2xl shadow-2xl object-contain" alt="Current" />
            ) : (
              <div className="text-center opacity-10 space-y-6">
                <div className="text-9xl">🌄</div>
                <p className="text-2xl font-black uppercase tracking-widest">Media Canvas Empty</p>
              </div>
            )}
            
            {analysis && (
              <div className="mt-8 bg-black/40 p-8 rounded-[2rem] border border-gray-800 w-full max-w-2xl animate-in fade-in">
                <h4 className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-4">AI Vision Analysis</h4>
                <p className="text-gray-400 italic font-serif leading-relaxed">{analysis}</p>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
};

export default VisualStudio;
