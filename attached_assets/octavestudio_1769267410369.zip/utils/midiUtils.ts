
/**
 * Advanced MIDI file generator for Octave Studio.
 * Generates a Standard MIDI File (SMF) Type 0 with tempo, markers, and project metadata.
 */

interface SongMetadata {
  title: string;
  bpm: number;
  genre: string;
  mood: string;
  energy: string;
  key: string;
}

interface SongSection {
  name: string;
  bars: number;
}

function toVLQ(num: number): number[] {
  const bytes = [];
  bytes.push(num & 0x7f);
  while (num >>= 7) {
    bytes.push((num & 0x7f) | 0x80);
  }
  return bytes.reverse();
}

function stringToBytes(str: string): number[] {
  return Array.from(new TextEncoder().encode(str));
}

export function generateMidiBlob(metadata: SongMetadata, structure: SongSection[]): Blob {
  const ticksPerBeat = 128; // Standard PPQ
  const header = [
    0x4d, 0x54, 0x68, 0x64, // MThd
    0x00, 0x00, 0x00, 0x06, // Length 6
    0x00, 0x00,             // Type 0 (Single track)
    0x00, 0x01,             // 1 Track
    0x00, 0x80              // 128 Ticks per beat
  ];

  const trackData: number[] = [];

  // 1. Set Tempo Event (0xFF 0x51 0x03 tt tt tt)
  const microsecondsPerBeat = Math.round(60000000 / metadata.bpm);
  trackData.push(0x00, 0xff, 0x51, 0x03);
  trackData.push((microsecondsPerBeat >> 16) & 0xff);
  trackData.push((microsecondsPerBeat >> 8) & 0xff);
  trackData.push(microsecondsPerBeat & 0xff);

  // 2. Track Name (0xFF 0x03 len text)
  const titleBytes = stringToBytes(`OctaveStudio Session: ${metadata.title}`);
  trackData.push(0x00, 0xff, 0x03, ...toVLQ(titleBytes.length), ...titleBytes);

  // 3. Metadata as Text Events (0xFF 0x01 len text)
  const metaStr = `[OctaveStudio Metadata] Genre: ${metadata.genre} | Mood: ${metadata.mood} | Energy: ${metadata.energy} | Key: ${metadata.key}`;
  const metaBytes = stringToBytes(metaStr);
  trackData.push(0x00, 0xff, 0x01, ...toVLQ(metaBytes.length), ...metaBytes);

  // 4. Markers for Sections (0xFF 0x06 len text)
  // Markers must be placed at the beginning of their respective section.
  let currentDeltaAccumulated = 0;
  
  structure.forEach((section, idx) => {
    const sectionBytes = stringToBytes(section.name);
    
    // Delta-time since last event (for the first marker, it's 0 if at start)
    // For subsequent markers, we place them after the previous section's bars.
    trackData.push(...toVLQ(currentDeltaAccumulated));
    trackData.push(0xff, 0x06, ...toVLQ(sectionBytes.length), ...sectionBytes);
    
    // Reset delta accumulator because the marker itself "consumed" the delta
    // Now we prepare the delta for the NEXT section marker
    // Assuming 4/4 time: 1 bar = 4 beats = 4 * ticksPerBeat
    currentDeltaAccumulated = section.bars * 4 * ticksPerBeat;
    
    // Add a dummy event at the end of the very last section to ensure length is correct
    if (idx === structure.length - 1) {
       trackData.push(...toVLQ(currentDeltaAccumulated));
       trackData.push(0xb0, 0x7b, 0x00); // All Notes Off (CC 123) as a terminator
       currentDeltaAccumulated = 0; // consumed
    }
  });

  // 5. End of Track (0xFF 0x2F 0x00)
  trackData.push(0x00, 0xff, 0x2f, 0x00);

  // Track Chunk Header (MTrk + length)
  const trackHeader = [
    0x4d, 0x54, 0x72, 0x6b, // MTrk
    (trackData.length >> 24) & 0xff,
    (trackData.length >> 16) & 0xff,
    (trackData.length >> 8) & 0xff,
    trackData.length & 0xff
  ];

  const fullMidi = new Uint8Array([...header, ...trackHeader, ...trackData]);
  return new Blob([fullMidi], { type: 'audio/midi' });
}
