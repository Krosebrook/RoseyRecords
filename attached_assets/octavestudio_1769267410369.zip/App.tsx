
import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import MusicStudio from './components/MusicStudio';
import OctaveLive from './components/OctaveLive';
import AIAssistant from './components/AIAssistant';
import Library from './components/Library';
import { AppView, SongMetadata } from './types';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<AppView>(AppView.STUDIO);
  const [currentProject, setCurrentProject] = useState<SongMetadata | null>(null);

  // Load active session from local storage on boot
  useEffect(() => {
    const saved = localStorage.getItem('octave_current_project');
    if (saved) {
      try {
        setCurrentProject(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load saved project");
      }
    }
  }, []);

  // Autosave active session
  useEffect(() => {
    if (currentProject) {
      localStorage.setItem('octave_current_project', JSON.stringify(currentProject));
    }
  }, [currentProject]);

  const handleLoadProject = (project: SongMetadata) => {
    setCurrentProject(project);
    setActiveView(AppView.STUDIO);
  };

  const renderView = () => {
    switch (activeView) {
      case AppView.STUDIO: 
        return <MusicStudio activeProject={currentProject} onProjectUpdate={setCurrentProject} />;
      case AppView.LIVE: 
        return <OctaveLive />;
      case AppView.ASSISTANT: 
        return <AIAssistant />;
      case AppView.GALLERY: 
        return <Library onLoadProject={handleLoadProject} />;
      default: 
        return <MusicStudio activeProject={currentProject} onProjectUpdate={setCurrentProject} />;
    }
  };

  return (
    <Layout activeView={activeView} setActiveView={setActiveView}>
      {renderView()}

      <div className="fixed bottom-6 right-6 z-50">
        <button 
          onClick={() => (window as any).aistudio?.openSelectKey?.()}
          className="bg-gray-900 border border-gray-800 p-4 rounded-full shadow-2xl hover:bg-gray-800 transition-all text-sm flex items-center space-x-2"
          title="Select API Key for High Fidelity Models"
        >
          <span>🔑</span>
          <span className="hidden md:inline font-bold text-gray-300 uppercase tracking-widest text-[10px]">Config Engine</span>
        </button>
      </div>
    </Layout>
  );
};

export default App;
