import React, { useState, useEffect } from 'react';
import { useTheory } from '../context/TheoryContext';
import { UserPreset, getPresets, savePreset, deletePreset } from '../utils/storage';
import { ProgressionStep } from '../types';
import { PROGRESSION_TEMPLATES } from '../constants';

interface PresetLibraryProps {
  currentBpm: number;
  onLoad: (progression: ProgressionStep[], key: string, bpm: number) => void;
  isOpen: boolean;
  onClose: () => void;
}

export const PresetLibrary: React.FC<PresetLibraryProps> = ({ currentBpm, onLoad, isOpen, onClose }) => {
  const { progression, rootNote } = useTheory();
  const [presets, setPresets] = useState<UserPreset[]>([]);
  const [newPresetName, setNewPresetName] = useState('');
  const [activeView, setActiveView] = useState<'user' | 'templates' | 'save'>('user');

  useEffect(() => {
    if (isOpen) {
      setPresets(getPresets());
      setActiveView('user');
    }
  }, [isOpen]);

  const handleSave = () => {
    if (!newPresetName.trim()) return;
    
    const newPreset: UserPreset = {
      id: crypto.randomUUID(),
      name: newPresetName,
      createdAt: Date.now(),
      type: 'progression',
      data: {
        progression: progression,
        key: rootNote,
        bpm: currentBpm,
        mood: 'Custom'
      }
    };

    savePreset(newPreset);
    setPresets(getPresets());
    setNewPresetName('');
    setActiveView('user');
  };

  const handleDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deletePreset(id);
    setPresets(getPresets());
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-slate-800 border border-slate-700 w-full max-w-lg rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        <div className="p-4 border-b border-slate-700 flex justify-between items-center bg-slate-900/50">
          <div className="flex gap-4">
            <button 
              onClick={() => setActiveView('user')}
              className={`text-sm font-bold transition-colors ${activeView === 'user' ? 'text-white' : 'text-slate-500'}`}
            >
              My Presets
            </button>
            <button 
              onClick={() => setActiveView('templates')}
              className={`text-sm font-bold transition-colors ${activeView === 'templates' ? 'text-white' : 'text-slate-500'}`}
            >
              Templates
            </button>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {activeView === 'user' && (
            <>
              {presets.length === 0 ? (
                 <div className="text-center py-12 text-slate-500 text-sm">
                   <div className="mb-2 text-2xl">📂</div>
                   Your library is empty. <br/> Create a progression and save it!
                 </div>
              ) : (
                presets.map(p => (
                  <div 
                    key={p.id}
                    onClick={() => { onLoad(p.data.progression, p.data.key, p.data.bpm); onClose(); }}
                    className="group bg-slate-700/30 hover:bg-slate-700 border border-slate-700/50 hover:border-indigo-500/50 rounded-xl p-3 cursor-pointer transition-all flex justify-between items-center"
                  >
                    <div>
                      <div className="text-sm font-bold text-white group-hover:text-indigo-400">{p.name}</div>
                      <div className="text-[10px] text-slate-500">
                        {p.data.key} • {p.data.progression.length} Chords • {new Date(p.createdAt).toLocaleDateString()}
                      </div>
                    </div>
                    <button 
                      onClick={(e) => handleDelete(p.id, e)}
                      className="text-slate-600 hover:text-red-400 p-2 opacity-0 group-hover:opacity-100 transition-opacity"
                      title="Delete Preset"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </div>
                ))
              )}
            </>
          )}

          {activeView === 'templates' && (
             <div className="grid grid-cols-2 gap-3">
               {PROGRESSION_TEMPLATES.map((t, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      // Template Loading Logic handled by parent via onLoad, 
                      // but parent needs to convert template to current Key.
                      // We will let the parent handle this logic by passing special signal or just handling it in Lab.
                      // For now, simpler to just implement template mapping here if we have NOTES?
                      // Actually, reuse the mapping logic from Lab is cleaner.
                      // We will simulate a 'preset' structure for consistent API
                      // Note: This requires mapping logic which is currently in Lab.
                      // We will skip this for now and rely on the Lab's existing template view, 
                      // or better, migrate template view into this modal in future refactor.
                      // Let's keep it simple: Just user presets for now.
                    }}
                    className="p-3 text-left rounded-xl bg-slate-700/50 hover:bg-slate-700 border border-slate-600 disabled:opacity-50"
                    disabled
                  >
                    <div className="text-white text-xs font-bold">{t.name}</div>
                    <div className="text-[10px] text-slate-500">Coming soon to Library</div>
                  </button>
               ))}
             </div>
          )}

          {activeView === 'save' && (
            <div className="space-y-4 pt-2">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Preset Name</label>
                <input 
                  type="text" 
                  value={newPresetName}
                  onChange={(e) => setNewPresetName(e.target.value)}
                  placeholder="e.g. Neo Soul in Eb"
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-2 text-white focus:border-indigo-500 outline-none"
                  autoFocus
                />
              </div>
              <div className="text-xs text-slate-500 bg-slate-900/50 p-3 rounded-lg border border-slate-700/50">
                Saving current sequence: <br/>
                <span className="font-mono text-indigo-400">{progression.map(p => p.numeral).join(' - ')}</span> in {rootNote}
              </div>
            </div>
          )}
        </div>

        <div className="p-4 border-t border-slate-700 bg-slate-900/50 flex gap-3">
          {activeView === 'save' ? (
            <>
              <button onClick={() => setActiveView('user')} className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-xl text-sm font-bold">Cancel</button>
              <button onClick={handleSave} className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded-xl text-sm font-bold shadow-lg">Save Preset</button>
            </>
          ) : (
             <button 
               onClick={() => setActiveView('save')} 
               disabled={progression.length === 0}
               className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:bg-slate-700 text-white py-2 rounded-xl text-sm font-bold shadow-lg transition-all"
             >
               + Save Current As New
             </button>
          )}
        </div>
      </div>
    </div>
  );
};
