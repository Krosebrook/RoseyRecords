import React, { useState } from 'react';
import { useTheory } from '../context/TheoryContext';
import { generateShareUrl } from '../utils/encoding';

export const ShareControl: React.FC = () => {
  const { activeTab, rootNote, selectedVariety, progression } = useTheory();
  const [copied, setCopied] = useState(false);

  const handleShare = () => {
    // Assuming default BPM of 100 for global share context unless specifically inside progression lab
    const url = generateShareUrl(activeTab, rootNote, selectedVariety, progression, 100);
    navigator.clipboard.writeText(url).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  return (
    <button
      onClick={handleShare}
      className={`
        flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-bold transition-all
        ${copied 
          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/50' 
          : 'bg-slate-800 text-slate-400 border border-slate-700 hover:bg-slate-700 hover:text-white'
        }
      `}
      title="Copy Link to Clipboard"
    >
      {copied ? (
        <>
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
          </svg>
          Copied
        </>
      ) : (
        <>
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
          </svg>
          Share
        </>
      )}
    </button>
  );
};
