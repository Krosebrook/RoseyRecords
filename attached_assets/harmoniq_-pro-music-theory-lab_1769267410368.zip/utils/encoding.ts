import { ProgressionStep } from "../types";

export const encodeState = (data: any): string => {
  try {
    const json = JSON.stringify(data);
    return btoa(json);
  } catch (e) {
    console.error("Failed to encode state", e);
    return "";
  }
};

export const decodeState = <T>(encoded: string): T | null => {
  try {
    const json = atob(encoded);
    return JSON.parse(json) as T;
  } catch (e) {
    console.error("Failed to decode state", e);
    return null;
  }
};

export const generateShareUrl = (
  tab: string,
  root: string,
  variety: string,
  progression: ProgressionStep[],
  bpm: number
): string => {
  const params = new URLSearchParams();
  params.set('t', tab);
  params.set('r', root);
  params.set('m', variety);
  
  if (progression && progression.length > 0) {
    const minifiedProgression = progression.map(p => ({
      r: p.root,
      v: p.variety,
      n: p.numeral
    }));
    params.set('p', encodeState(minifiedProgression));
  }
  
  if (bpm !== 100) {
    params.set('b', bpm.toString());
  }

  return `${window.location.origin}${window.location.pathname}?${params.toString()}`;
};
