import { ProgressionStep } from "../types";

export interface UserPreset {
  id: string;
  name: string;
  createdAt: number;
  type: 'progression';
  data: {
    progression: ProgressionStep[];
    key: string;
    bpm: number;
    mood: string;
  };
}

const STORAGE_KEY = 'harmoniq_user_presets';

export const savePreset = (preset: UserPreset): void => {
  const existing = getPresets();
  const updated = [preset, ...existing];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
};

export const getPresets = (): UserPreset[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
};

export const deletePreset = (id: string): void => {
  const existing = getPresets();
  const updated = existing.filter(p => p.id !== id);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
};
