# System Architecture Specification: OctaveStudio
## Production-Grade Technical Blueprint

**Version:** 1.0  
**Last Updated:** 2024-12-27  
**Architecture Review:** Pending  
**Status:** Ready for Implementation  

---

## Table of Contents
1. [System Architecture Overview](#1-system-architecture-overview)
2. [Technology Stack](#2-technology-stack)
3. [Database Schema](#3-database-schema)
4. [API Contracts](#4-api-contracts)
5. [Infrastructure Setup](#5-infrastructure-setup)
6. [Security Architecture](#6-security-architecture)
7. [Observability & Monitoring](#7-observability--monitoring)
8. [Disaster Recovery](#8-disaster-recovery)
9. [Deployment Pipeline](#9-deployment-pipeline)
10. [Scalability Plan](#10-scalability-plan)

---

## 1. System Architecture Overview

### 1.1 High-Level Architecture (ASCII Diagram)

```
┌────────────────────────────────────────────────────────────────────────────┐
│                        CLIENT TIER (Mobile + Web)                          │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│  ┌──────────────────────┐              ┌──────────────────────┐           │
│  │   iOS App            │              │   Android App        │           │
│  │   ─────────          │              │   ─────────          │           │
│  │   • Expo SDK 51      │              │   • Expo SDK 51      │           │
│  │   • React Native     │              │   • React Native     │           │
│  │   • TypeScript       │              │   • TypeScript       │           │
│  │   • expo-av (audio)  │              │   • expo-av (audio)  │           │
│  │   • AsyncStorage     │              │   • AsyncStorage     │           │
│  └──────────┬───────────┘              └──────────┬───────────┘           │
│             │                                     │                       │
│             └──────────────┬──────────────────────┘                       │
│                            │                                              │
│                   ┌────────▼────────┐                                     │
│                   │   Web App       │                                     │
│                   │   ────────      │                                     │
│                   │   • RN Web      │                                     │
│                   │   • Next.js     │                                     │
│                   │   • Vercel      │                                     │
│                   └────────┬────────┘                                     │
└────────────────────────────┼──────────────────────────────────────────────┘
                             │
                             │ HTTPS/TLS 1.3
                             │
┌────────────────────────────▼──────────────────────────────────────────────┐
│                       API GATEWAY TIER                                     │
├────────────────────────────────────────────────────────────────────────────┤
│                                                                            │
│  ┌───────────────────────────────────────────────────────────────────┐    │
│  │  Firebase Cloud Functions (Node.js 20)                            │    │
│  │  ─────────────────────────────────────────                        │    │
│  │                                                                   │    │
│  │  ┌─────────────────┐  ┌──────────────────┐  ┌────────────────┐  │    │
│  │  │ generateSong()  │  │ generateBeat()   │  │ generateCover()│  │    │
│  │  │ • Rate limiting │  │ • Queue mgmt     │  │ • Audio proc   │  │    │
│  │  │ • Auth check    │  │ • Tag validation │  │ • FFmpeg       │  │    │
│  │  └────────┬────────┘  └────────┬─────────┘  └────────┬───────┘  │    │
│  │           │                     │                     │          │    │
│  │  ┌────────▼─────────────────────▼─────────────────────▼───────┐  │    │
│  │  │              Orchestration Layer                           │  │    │
│  │  │  • Error handling (Cause → Fix → Retry)                   │  │    │
│  │  │  • Circuit breakers (5 failures = 60s cooldown)           │  │    │
│  │  │  • Request validation (Zod schemas)                       │  │    │
│  │  │  • Response normalization                                 │  │    │
│  │  └───────────────────────────────────────────────────────────┘  │    │
│  └───────────────────────────────────────────────────────────────────┘    │
└────────────────────────────┬──────────────────────────────────────────────┘
                             │
                   ┌─────────┴──────────┐
                   │                    │
┌──────────────────▼─────┐   ┌──────────▼──────────────┐
│  FIREBASE SERVICES     │   │  EXTERNAL AI PROVIDERS  │
│  ─────────────────     │   │  ──────────────────     │
│                        │   │                         │
│  ┌──────────────────┐  │   │  ┌──────────────────┐  │
│  │ Firestore        │  │   │  │ Replicate API    │  │
│  │ • Users          │  │   │  │ • MusicGen       │  │
│  │ • Projects       │  │   │  │ • $0.02/gen      │  │
│  │ • RateLimits     │  │   │  └──────────────────┘  │
│  └──────────────────┘  │   │                         │
│                        │   │  ┌──────────────────┐  │
│  ┌──────────────────┐  │   │  │ Mubert API       │  │
│  │ Auth             │  │   │  │ • Instrumentals  │  │
│  │ • Magic link     │  │   │  │ • $499/month     │  │
│  │ • OAuth          │  │   │  └──────────────────┘  │
│  └──────────────────┘  │   │                         │
│                        │   │  ┌──────────────────┐  │
│  ┌──────────────────┐  │   │  │ OpenAI API       │  │
│  │ Storage          │  │   │  │ • GPT-4 (lyrics) │  │
│  │ • Audio files    │  │   │  │ • $0.01/lyric    │  │
│  │ • User uploads   │  │   │  └──────────────────┘  │
│  └──────────────────┘  │   │                         │
│                        │   │  ┌──────────────────┐  │
│  ┌──────────────────┐  │   │  │ ElevenLabs API   │  │
│  │ Analytics        │  │   │  │ • Text-to-speech │  │
│  │ • Events         │  │   │  │ • Voice demos    │  │
│  │ • Funnels        │  │   │  └──────────────────┘  │
│  └──────────────────┘  │   └─────────────────────────┘
└────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                    OBSERVABILITY TIER                           │
├─────────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────────────┐  │
│  │ Sentry       │  │ Firebase     │  │ Cloud Logging       │  │
│  │ • Errors     │  │ • Analytics  │  │ • Function logs     │  │
│  │ • Performance│  │ • Crashlytics│  │ • Audit trails      │  │
│  └──────────────┘  └──────────────┘  └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

### 1.2 Data Flow Example: Song Generation

```
User Taps "Generate Song" Button
         │
         ▼
┌─────────────────────────────────────┐
│ 1. Client-Side Validation           │
│    • Prompt length < 500 chars      │
│    • No profanity (basic regex)     │
│    • User authenticated?            │
└──────────┬──────────────────────────┘
           │
           ▼
┌─────────────────────────────────────┐
│ 2. Firebase Cloud Function Call     │
│    generateSong({ prompt, genre })  │
└──────────┬──────────────────────────┘
           │
           ▼
┌─────────────────────────────────────┐
│ 3. Server-Side Validation           │
│    • Auth token valid?              │
│    • Rate limit check (Firestore)   │
│    • Content moderation (Perspective│
│      API—async, don't block)        │
└──────────┬──────────────────────────┘
           │
           ▼
┌─────────────────────────────────────┐
│ 4. External API Call                │
│    • Try Replicate MusicGen         │
│    • If fails → try Mubert          │
│    • If fails → return error        │
│    • Timeout: 120 seconds           │
└──────────┬──────────────────────────┘
           │
           ▼
┌─────────────────────────────────────┐
│ 5. Store Result                     │
│    • Upload audio → Cloud Storage   │
│    • Get signed URL (1hr expiry)    │
│    • Save metadata → Firestore      │
└──────────┬──────────────────────────┘
           │
           ▼
┌─────────────────────────────────────┐
│ 6. Return to Client                 │
│    { audioUrl, duration, generatedAt│
│      prompt, provider }             │
└──────────┬──────────────────────────┘
           │
           ▼
┌─────────────────────────────────────┐
│ 7. Client Plays Audio               │
│    • Load via expo-av               │
│    • Show waveform                  │
│    • Save to My Sets (Firestore)    │
└─────────────────────────────────────┘
```

---

## 2. Technology Stack

### 2.1 Frontend (Mobile & Web)

| Component | Technology | Justification |
|-----------|-----------|---------------|
| **Framework** | React Native (Expo SDK 51) | Cross-platform (iOS/Android/Web), mature ecosystem, FlashFusion uses it |
| **Language** | TypeScript 5.3+ | Type safety, better DX, catches errors at compile-time |
| **Navigation** | React Navigation 6.x | Standard for RN, supports deep linking, tab/stack navigators |
| **State Management** | React Context + Hooks | Simple, built-in, avoid Redux complexity for MVP |
| **Audio Playback** | expo-av | Native audio APIs, supports streaming, background playback |
| **Local Storage** | AsyncStorage (encrypted) | Offline support for My Sets metadata |
| **HTTP Client** | Firebase SDK + axios | Firebase for backend, axios for external APIs |
| **UI Library** | React Native Paper | Material Design, accessible, themeable (FlashFusion colors) |
| **Animation** | Reanimated 3.x | Smooth 60fps animations, spring physics for micro-interactions |

### 2.2 Backend (API & Services)

| Component | Technology | Justification |
|-----------|-----------|---------------|
| **Serverless Functions** | Firebase Cloud Functions (Node.js 20) | Scales to zero, integrates with Firebase Auth/Firestore, $0 at low volume |
| **Database** | Cloud Firestore | NoSQL, real-time listeners, offline persistence, generous free tier |
| **Authentication** | Firebase Auth | Magic link, Google/Apple OAuth, JWTs auto-managed |
| **File Storage** | Cloud Storage for Firebase | CDN-backed, signed URLs, AES-256 encryption at rest |
| **Secrets** | Cloud Secret Manager | Rotate API keys, audit access, $0.06/secret/month |
| **Content Moderation** | Perspective API (Google) | Detect toxicity, hate speech, spam in prompts |

### 2.3 External APIs

| Service | Purpose | Cost | SLA |
|---------|---------|------|-----|
| **Replicate** | MusicGen inference (full songs) | $0.02/gen | 99% uptime |
| **Mubert** | Instrumental loops/beats | $499/month | 99.5% uptime |
| **OpenAI GPT-4** | Lyric generation (LyricSmith) | $0.01/lyric | 99.9% uptime |
| **ElevenLabs** | Text-to-speech (voice demos) | $99/month | 99% uptime |

### 2.4 Infrastructure & DevOps

| Component | Technology | Justification |
|-----------|-----------|---------------|
| **Mobile CI/CD** | Expo EAS Build | Managed builds for iOS/Android, TestFlight integration |
| **Web Hosting** | Vercel | Auto-deploy from GitHub, edge CDN, free tier generous |
| **Monitoring** | Sentry (errors) + Firebase Analytics (product metrics) | Sentry: best error tracking; Firebase: free, built-in |
| **Logging** | Cloud Logging (Google Cloud) | Centralized logs, 90-day retention, SQL-like queries |
| **Version Control** | GitHub | Standard, integrates with EAS Build, branch protection |

### 2.5 Design & Prototyping

| Tool | Purpose |
|------|---------|
| **Figma** | UI mockups, component library, handoff to devs |
| **Miro** | User flow diagrams, architecture brainstorming |
| **Loom** | Screen recordings for design reviews, bug reports |

---

## 3. Database Schema

### 3.1 Firestore Collections

#### Collection: `users`
**Purpose:** User profiles and settings

```typescript
interface User {
  userId: string;                    // Firebase Auth UID
  email: string | null;              // From Auth provider
  displayName: string | null;        // User's chosen name
  photoURL: string | null;           // Profile picture
  tier: 'free' | 'pro' | 'enterprise'; // Subscription tier
  createdAt: Timestamp;              // Account creation
  lastActiveAt: Timestamp;           // For churn analysis
  preferences: {
    favoriteGenres: string[];        // ['lofi', 'pop', 'edm']
    notificationsEnabled: boolean;
    theme: 'light' | 'dark' | 'auto';
  };
  stats: {
    totalGenerations: number;        // Lifetime count
    totalExports: number;
    favoriteTool: string;            // 'songforge' | 'beatstacks' | ...
  };
}
```

**Security Rules:**
```javascript
match /users/{userId} {
  allow read, write: if request.auth.uid == userId;
}
```

---

#### Collection: `users/{userId}/projects`
**Purpose:** User's created content (songs, beats, lyrics)

```typescript
interface Project {
  projectId: string;                 // Auto-generated Firestore ID
  type: 'song' | 'beat' | 'cover' | 'lyrics'; // Content type
  title: string;                     // User-defined or auto (e.g., "Untitled Song 1")
  prompt?: string;                   // Original prompt (if applicable)
  audioUrl?: string;                 // Cloud Storage signed URL (1hr expiry)
  audioStoragePath?: string;         // Permanent path for re-signing
  duration?: number;                 // In seconds
  metadata: {
    genre?: string;
    mood?: string;
    tags: string[];                  // User-defined tags
    bpm?: number;                    // Beats per minute (for beats)
  };
  provider: 'replicate' | 'mubert' | 'openai' | 'elevenlabs'; // Which API
  createdAt: Timestamp;
  updatedAt: Timestamp;
  status: 'draft' | 'completed' | 'failed'; // Generation status
  parentProjectId?: string;          // For linking (beat → song)
  variations: string[];              // Array of related projectIds
}
```

**Security Rules:**
```javascript
match /users/{userId}/projects/{projectId} {
  allow read, write: if request.auth.uid == userId;
  allow create: if request.auth.uid == userId 
                && request.resource.data.status == 'draft';
}
```

**Indexes (Create in Firebase Console):**
- Composite: `userId ASC, createdAt DESC` (for recent projects query)
- Composite: `userId ASC, type ASC, createdAt DESC` (for filtering by type)
- Single: `parentProjectId` (for finding variations)

---

#### Collection: `rateLimits`
**Purpose:** Track daily generation counts per user

```typescript
interface RateLimit {
  documentId: string;                // Format: "{userId}_{YYYY-MM-DD}"
  userId: string;
  date: string;                      // ISO date (YYYY-MM-DD)
  counts: {
    songGeneration: number;          // Incremented on each generateSong()
    beatGeneration: number;
    coverGeneration: number;
    lyricGeneration: number;
  };
  tier: 'free' | 'pro';              // Cached for quick checks
  limits: {
    songGeneration: number;          // 10 for free, 50 for pro
    beatGeneration: number;
    coverGeneration: number;
    lyricGeneration: number;
  };
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

**Security Rules:**
```javascript
match /rateLimits/{limitId} {
  // Only server (Cloud Functions) can write
  allow read: if request.auth.uid == resource.data.userId;
  allow write: if false; // Client cannot modify (server-only via Admin SDK)
}
```

**TTL (Time to Live):** Delete documents older than 7 days (Cloud Scheduler + Function)

---

#### Collection: `subscriptions`
**Purpose:** Stripe subscription data (synced via webhook)

```typescript
interface Subscription {
  subscriptionId: string;            // Stripe subscription ID
  userId: string;
  stripeCustomerId: string;
  status: 'active' | 'canceled' | 'past_due' | 'trialing';
  tier: 'pro' | 'enterprise';
  currentPeriodStart: Timestamp;
  currentPeriodEnd: Timestamp;
  cancelAtPeriodEnd: boolean;
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

**Security Rules:**
```javascript
match /subscriptions/{subId} {
  allow read: if request.auth.uid == resource.data.userId;
  allow write: if false; // Server-only (Stripe webhook writes)
}
```

---

### 3.2 Cloud Storage Structure

```
gs://octave-studios.appspot.com/
├── users/
│   └── {userId}/
│       ├── songs/
│       │   ├── {projectId}.mp3
│       │   └── {projectId}.wav (Pro tier only)
│       ├── beats/
│       │   └── {projectId}.mp3
│       ├── covers/
│       │   └── {projectId}.mp3
│       └── uploads/ (user-uploaded vocals)
│           └── {uploadId}.wav
├── public/
│   ├── assets/ (splash screens, icons)
│   └── defaults/ (placeholder audio, error sounds)
└── temp/ (deleted after 24 hours)
    └── {tempId}.mp3
```

**Storage Rules:**
```javascript
service firebase.storage {
  match /b/{bucket}/o {
    // Users can read/write their own files
    match /users/{userId}/{allPaths=**} {
      allow read, write: if request.auth.uid == userId;
    }
    
    // Public assets are readable by anyone
    match /public/{allPaths=**} {
      allow read: if true;
      allow write: if false; // Only admins (via Admin SDK)
    }
  }
}
```

---

## 4. API Contracts

### 4.1 Cloud Functions API (Client → Backend)

All functions are HTTPS callable functions (`functions.https.onCall`), which:
- Automatically extract Firebase Auth token
- Return structured errors
- Support request validation

#### Function: `generateSong`

**Request:**
```typescript
interface GenerateSongRequest {
  prompt: string;           // Max 500 chars
  genre: string;            // From predefined list
  mood: string;             // From predefined list
  duration: 30 | 60 | 120;  // Seconds
  vocalStyle?: 'male' | 'female' | 'none'; // Default: 'female'
}
```

**Response:**
```typescript
interface GenerateSongResponse {
  projectId: string;        // Firestore document ID
  audioUrl: string;         // Signed URL (expires in 1 hour)
  duration: number;
  provider: 'replicate' | 'mubert';
  metadata: {
    prompt: string;
    genre: string;
    mood: string;
  };
  generatedAt: string;      // ISO timestamp
  remainingGenerations: number; // For free tier countdown
}
```

**Errors:**
```typescript
// Firebase Functions error codes
throw new functions.https.HttpsError(
  'resource-exhausted',      // Code
  'Daily limit reached. Upgrade to Pro for 50/day.', // Message
  { limit: 10, used: 10 }    // Details (optional)
);

// Other codes:
// - 'unauthenticated': User not logged in
// - 'permission-denied': Tier doesn't allow this operation
// - 'invalid-argument': Bad request data
// - 'internal': Server error (e.g., API timeout)
```

**Rate Limit:** 10/day (free), 50/day (pro), enforced in function

---

#### Function: `generateBeat`

**Request:**
```typescript
interface GenerateBeatRequest {
  tags: string[];           // Max 5 tags
  duration: 30 | 60;
  tempo?: number;           // BPM (80-160), optional
}
```

**Response:** Same structure as `GenerateSongResponse`

---

#### Function: `generateLyrics`

**Request:**
```typescript
interface GenerateLyricsRequest {
  theme: string;            // Max 200 chars
  genre: string;
  structure: 'verse-chorus' | 'verse-chorus-bridge' | 'custom';
  customStructure?: string; // If structure == 'custom'
}
```

**Response:**
```typescript
interface GenerateLyricsResponse {
  projectId: string;
  lyrics: {
    intro?: string[];
    verse1: string[];
    chorus: string[];
    verse2?: string[];
    bridge?: string[];
  };
  metadata: {
    theme: string;
    genre: string;
    rhymeScheme: string;  // 'AABB', 'ABAB', etc.
  };
  generatedAt: string;
}
```

---

#### Function: `processAudioUpload`

**Purpose:** Validate and store user-uploaded audio (for CoverLab)

**Request:**
```typescript
interface ProcessAudioUploadRequest {
  audioData: string;        // Base64-encoded audio (max 20MB)
  filename: string;
  mimeType: 'audio/mp3' | 'audio/wav' | 'audio/m4a';
}
```

**Response:**
```typescript
interface ProcessAudioUploadResponse {
  uploadId: string;
  storagePath: string;
  audioUrl: string;         // Temporary URL for preview
  duration: number;         // Extracted via FFmpeg
  sampleRate: number;
  validated: boolean;       // False if corrupted/invalid
}
```

**Validation Steps (Server-Side):**
1. Check file size < 20MB
2. Verify MIME type matches content (magic number check)
3. Scan for viruses (Cloud Vision API or ClamAV)
4. Extract metadata (FFmpeg): duration, bitrate, codec
5. Reject if duration > 120s (free tier limit)

---

### 4.2 External API Integrations

#### Replicate API (MusicGen)

**Endpoint:** `https://api.replicate.com/v1/predictions`  
**Auth:** Bearer token (stored in Cloud Secret Manager)

**Request:**
```typescript
const response = await axios.post(
  'https://api.replicate.com/v1/predictions',
  {
    version: "7a76a8258b23fae65c5a22debb8841d1d7e816b75c2f24218cd2bd8573787906",
    input: {
      prompt: "lofi hip hop beats",
      duration: 30,
      model_version: "melody"  // or 'large', 'medium'
    }
  },
  {
    headers: {
      'Authorization': `Token ${REPLICATE_API_KEY}`,
      'Content-Type': 'application/json'
    }
  }
);
```

**Response:**
```json
{
  "id": "abc123prediction",
  "status": "starting",
  "urls": {
    "get": "https://api.replicate.com/v1/predictions/abc123",
    "cancel": "https://api.replicate.com/v1/predictions/abc123/cancel"
  }
}
```

**Polling (until complete):**
```typescript
// Poll every 2 seconds, max 60 attempts (120s timeout)
const checkStatus = async (predictionId) => {
  const res = await axios.get(`https://api.replicate.com/v1/predictions/${predictionId}`, {
    headers: { 'Authorization': `Token ${REPLICATE_API_KEY}` }
  });
  
  if (res.data.status === 'succeeded') {
    return res.data.output; // Audio URL
  } else if (res.data.status === 'failed') {
    throw new Error(res.data.error);
  }
  // If 'starting' or 'processing', poll again
};
```

---

#### Mubert API (Beats)

**Endpoint:** `https://api.mubert.com/v2/RecordTrack`  
**Auth:** API key in request body

**Request:**
```typescript
const response = await axios.post('https://api.mubert.com/v2/RecordTrack', {
  method: 'RecordTrack',
  params: {
    license: 'standard',
    mode: 'loop',
    duration: 30,
    tags: 'lofi,chill,beats',
    return_links: true
  }
}, {
  headers: { 'Content-Type': 'application/json' }
});
```

**Response:**
```json
{
  "status": 1,
  "data": {
    "tasks": [
      {
        "download_link": "https://mubert.com/audio/track123.mp3",
        "task_id": "task123"
      }
    ]
  }
}
```

**Error Handling:**
- Status code != 200 → Retry with exponential backoff (1s, 2s, 4s, 8s)
- Status == 429 (rate limit) → Wait 60s, then retry
- Max retries: 3, then fail gracefully (return error to user)

---

## 5. Infrastructure Setup

### 5.1 Firebase Project Configuration

**Project ID:** `octave-studios`  
**Region:** `us-central1` (Iowa—lowest latency for US users)  
**Billing:** Blaze plan (pay-as-you-go)

**Services Enabled:**
- ✅ Authentication (Email/Password, Google, Apple)
- ✅ Firestore (Native mode)
- ✅ Cloud Storage
- ✅ Cloud Functions (Node.js 20 runtime)
- ✅ Analytics
- ✅ Crashlytics (via Firebase SDK)

**Budget Alerts (Cloud Console):**
- Warning at $250/month
- Alert at $500/month (Slack webhook + email)
- Hard cap at $1,000/month (requires manual override)

---

### 5.2 Cloud Functions Deployment Config

**File:** `functions/package.json`
```json
{
  "name": "octave-functions",
  "engines": {
    "node": "20"
  },
  "dependencies": {
    "firebase-admin": "^12.0.0",
    "firebase-functions": "^5.0.0",
    "axios": "^1.6.0",
    "zod": "^3.22.0"
  }
}
```

**File:** `functions/src/index.ts`
```typescript
import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

admin.initializeApp();

// Configure runtime
export const generateSong = functions
  .runWith({
    timeoutSeconds: 120,      // Max 2 minutes
    memory: '512MB',          // Sufficient for API calls
    maxInstances: 50          // Auto-scale limit
  })
  .https.onCall(async (data, context) => {
    // Implementation...
  });
```

**Deployment:**
```bash
firebase deploy --only functions

# Deploy specific function (faster iteration)
firebase deploy --only functions:generateSong
```

---

### 5.3 Expo Configuration

**File:** `app.json`
```json
{
  "expo": {
    "name": "OctaveStudio",
    "slug": "octave-studio",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#0A1224"
    },
    "updates": {
      "fallbackToCacheTimeout": 0,
      "url": "https://u.expo.dev/abc123"
    },
    "assetBundlePatterns": ["**/*"],
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.flashfusion.octavestudio",
      "buildNumber": "1"
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#0A1224"
      },
      "package": "com.flashfusion.octavestudio",
      "versionCode": 1,
      "permissions": [
        "RECORD_AUDIO",
        "READ_EXTERNAL_STORAGE",
        "WRITE_EXTERNAL_STORAGE"
      ]
    },
    "plugins": [
      "@react-native-firebase/app",
      "@react-native-firebase/auth",
      "expo-av"
    ]
  }
}
```

**Build Commands:**
```bash
# iOS
eas build --platform ios --profile production

# Android
eas build --platform android --profile production

# Submit to stores (after successful build)
eas submit --platform ios
eas submit --platform android
```

---

## 6. Security Architecture

### 6.1 Authentication Flow

```
User Opens App
      │
      ▼
┌─────────────────────┐
│ Check Auth State    │
│ (Firebase SDK)      │
└──────┬──────────────┘
       │
       ├─ If logged in → Show Home
       │
       └─ If not logged in → Show Login Screen
                │
                ▼
       ┌────────────────────┐
       │ User Chooses Auth  │
       │ • Magic Link       │
       │ • Google OAuth     │
       │ • Apple OAuth      │
       └────────┬───────────┘
                │
                ▼
       ┌────────────────────┐
       │ Firebase Auth      │
       │ • Sends magic link │
       │ • OAuth redirect   │
       └────────┬───────────┘
                │
                ▼
       ┌────────────────────┐
       │ User Clicks Link   │
       │ or Approves OAuth  │
       └────────┬───────────┘
                │
                ▼
       ┌────────────────────┐
       │ Firebase Returns   │
       │ ID Token (JWT)     │
       └────────┬───────────┘
                │
                ▼
       ┌────────────────────┐
       │ Client Stores      │
       │ Token (SecureStore)│
       └────────┬───────────┘
                │
                ▼
       ┌────────────────────┐
       │ All API Calls      │
       │ Include Token in   │
       │ Authorization      │
       │ Header             │
       └────────────────────┘
```

**Token Expiry:** 1 hour (auto-refreshed by Firebase SDK)  
**Refresh Token:** Stored in SecureStore (encrypted on device)

---

### 6.2 API Security (Cloud Functions)

**Input Validation (Zod Schema):**
```typescript
import { z } from 'zod';

const GenerateSongSchema = z.object({
  prompt: z.string().min(1).max(500),
  genre: z.enum(['pop', 'hiphop', 'rock', 'edm', 'lofi', 'cinematic']),
  mood: z.enum(['uplifting', 'moody', 'chill', 'intense', 'romantic']),
  duration: z.enum([30, 60, 120]),
  vocalStyle: z.enum(['male', 'female', 'none']).optional()
});

export const generateSong = functions.https.onCall(async (data, context) => {
  // 1. Auth check
  if (!context.auth) {
    throw new functions.https.HttpsError('unauthenticated', 'Must be logged in');
  }
  
  // 2. Input validation
  const validated = GenerateSongSchema.safeParse(data);
  if (!validated.success) {
    throw new functions.https.HttpsError(
      'invalid-argument',
      validated.error.errors[0].message
    );
  }
  
  // 3. Rate limit check
  // ... (see RateLimit section)
  
  // 4. Content moderation (async, non-blocking)
  moderatePrompt(validated.data.prompt).catch(err => 
    console.error('Moderation failed:', err)
  );
  
  // 5. Execute generation
  // ...
});
```

---

### 6.3 Content Moderation (Perspective API)

**Function:** `moderatePrompt`
```typescript
import axios from 'axios';

async function moderatePrompt(prompt: string): Promise<boolean> {
  const response = await axios.post(
    'https://commentanalyzer.googleapis.com/v1alpha1/comments:analyze',
    {
      comment: { text: prompt },
      languages: ['en'],
      requestedAttributes: {
        TOXICITY: {},
        SEVERE_TOXICITY: {},
        IDENTITY_ATTACK: {},
        INSULT: {},
        PROFANITY: {},
        THREAT: {}
      }
    },
    {
      params: { key: PERSPECTIVE_API_KEY }
    }
  );
  
  const scores = response.data.attributeScores;
  
  // Block if any score > 0.7 (70% confidence)
  const isToxic = Object.values(scores).some(
    (attr: any) => attr.summaryScore.value > 0.7
  );
  
  if (isToxic) {
    // Log to Firestore for review
    await admin.firestore().collection('flagged_prompts').add({
      prompt,
      scores,
      userId: context.auth.uid,
      timestamp: admin.firestore.FieldValue.serverTimestamp()
    });
    
    throw new functions.https.HttpsError(
      'invalid-argument',
      'Prompt contains inappropriate content'
    );
  }
  
  return true;
}
```

**Cost:** $1 per 1,000 requests (negligible at 10K generations/month)

---

### 6.4 Secrets Management

**Store in Cloud Secret Manager:**
```bash
# Create secrets
echo -n "r8_ABC123..." | gcloud secrets create REPLICATE_API_KEY --data-file=-
echo -n "sk-ABC123..." | gcloud secrets create OPENAI_API_KEY --data-file=-
echo -n "mubert-key" | gcloud secrets create MUBERT_API_KEY --data-file=-

# Grant access to Cloud Functions service account
gcloud secrets add-iam-policy-binding REPLICATE_API_KEY \
  --member="serviceAccount:octave-studios@appspot.gserviceaccount.com" \
  --role="roles/secretmanager.secretAccessor"
```

**Access in Cloud Functions:**
```typescript
import { SecretManagerServiceClient } from '@google-cloud/secret-manager';

const client = new SecretManagerServiceClient();

async function getSecret(secretName: string): Promise<string> {
  const [version] = await client.accessSecretVersion({
    name: `projects/octave-studios/secrets/${secretName}/versions/latest`
  });
  return version.payload.data.toString();
}

// Cache secrets (don't fetch on every request)
let REPLICATE_KEY: string | null = null;

export const generateSong = functions.https.onCall(async (data, context) => {
  if (!REPLICATE_KEY) {
    REPLICATE_KEY = await getSecret('REPLICATE_API_KEY');
  }
  
  // Use REPLICATE_KEY...
});
```

**Rotation Policy:** Rotate all API keys quarterly (calendar reminder)

---

## 7. Observability & Monitoring

### 7.1 Error Tracking (Sentry)

**Setup:**
```typescript
// app/App.tsx
import * as Sentry from '@sentry/react-native';

Sentry.init({
  dsn: 'https://abc123@o1234567.ingest.sentry.io/9876543',
  environment: __DEV__ ? 'development' : 'production',
  tracesSampleRate: 0.2,  // 20% of transactions (reduce costs)
  beforeSend(event) {
    // Scrub PII
    if (event.user) {
      delete event.user.email;
      delete event.user.ip_address;
    }
    return event;
  }
});

// Wrap root component
export default Sentry.wrap(App);
```

**Cloud Functions (Node.js):**
```typescript
import * as Sentry from '@sentry/node';

Sentry.init({ dsn: '...' });

export const generateSong = functions.https.onCall(async (data, context) => {
  try {
    // ...
  } catch (error) {
    Sentry.captureException(error, {
      user: { id: context.auth?.uid },
      extra: { prompt: data.prompt, genre: data.genre }
    });
    throw error;
  }
});
```

**Alerts (Sentry Dashboard):**
- Email on error spike (>10 errors/minute)
- Slack webhook for critical errors (payment failures, API outages)

---

### 7.2 Performance Monitoring

**Firebase Performance:**
```typescript
import perf from '@react-native-firebase/perf';

// Track custom traces
const trace = await perf().startTrace('song_generation');
trace.putAttribute('genre', genre);
trace.putAttribute('provider', 'replicate');

await generateSongAPI(params);

await trace.stop();
```

**Key Metrics to Track:**
- Song generation P50/P95 latency
- App startup time
- Audio playback lag
- Firestore query duration

**Dashboards:** Firebase Console → Performance tab

---

### 7.3 Analytics Events

**File:** `app/services/analyticsService.ts`
```typescript
import analytics from '@react-native-firebase/analytics';

export async function logSongGenerated(params: {
  genre: string;
  mood: string;
  duration: number;
  provider: string;
  success: boolean;
}) {
  await analytics().logEvent('song_generated', params);
}

export async function logUpgradeToPro(trigger: string) {
  await analytics().logEvent('upgrade_to_pro', { trigger });
}

// Funnel tracking
export async function logOnboardingStep(step: number, completed: boolean) {
  await analytics().logEvent('onboarding_step', { step, completed });
}
```

**Key Funnels:**
1. Install → Open → Generate Song → Save
2. Free User → View Paywall → Subscribe → Active Pro
3. Session Start → Select Module → Complete Workflow → Export

---

## 8. Disaster Recovery

### 8.1 Backup Strategy

**Firestore Backups:**
```bash
# Automated daily backups (Cloud Scheduler)
gcloud firestore export gs://octave-studios-backups/$(date +%Y-%m-%d)

# Retention: 30 days (lifecycle policy on bucket)
```

**Cloud Storage Backups:**
- Audio files are immutable (never deleted, only marked inactive in Firestore)
- No backup needed (primary storage is already redundant across 3 zones)

**Secrets Backup:**
- Export secrets quarterly to encrypted USB drive (offline storage)
- Store in physical safe at HQ

---

### 8.2 Incident Response Plan

**Severity Levels:**
| P0 | API down, all requests 503 | Page on-call engineer immediately |
| P1 | 10%+ error rate, latency 10s+ | Alert Slack #eng within 5 min |
| P2 | Feature broken for 5% users | Create Jira ticket, fix next sprint |
| P3 | UI glitch, no functional impact | Log in backlog, fix when time allows |

**Runbook (P0 - API Down):**
1. Acknowledge alert in PagerDuty (< 5 min)
2. Check Firebase Status page: https://status.firebase.google.com
3. Check Replicate Status page: https://status.replicate.com
4. If Firebase down → Tweet @FirebaseStatus, wait for resolution
5. If Replicate down → Switch to Mubert fallback (deploy Cloud Function update)
6. If our bug → Rollback last deployment: `firebase deploy --only functions` (previous commit)
7. Post-incident review within 24 hours (doc in `/docs/incidents/`)

---

## 9. Deployment Pipeline

### 9.1 CI/CD Workflow (GitHub Actions)

**File:** `.github/workflows/deploy.yml`
```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy-functions:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: 20
      - run: npm ci
        working-directory: functions
      - run: npm test
        working-directory: functions
      - uses: w9jds/firebase-action@v11.31.0
        with:
          args: deploy --only functions
        env:
          FIREBASE_TOKEN: ${{ secrets.FIREBASE_TOKEN }}
  
  deploy-web:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm ci
      - run: npm run build
      - uses: amondnet/vercel-action@v25
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
          vercel-args: '--prod'
```

---

### 9.2 Mobile Release Process

**iOS (TestFlight → App Store):**
```bash
# 1. Increment version in app.json
# 2. Build and submit
eas build --platform ios --profile production --auto-submit

# 3. Wait for App Store Connect review (2-3 days)
# 4. Release manually or auto-release after approval
```

**Android (Internal Testing → Production):**
```bash
# 1. Build AAB
eas build --platform android --profile production

# 2. Submit to Play Console
eas submit --platform android

# 3. Promote: Internal → Alpha → Beta → Production (staged rollout)
```

**Rollback:**
- iOS: App Store Connect → Version History → Previous version → Submit
- Android: Play Console → Release → Create release with previous APK/AAB

---

## 10. Scalability Plan

### 10.1 Current Capacity (MVP Phase)

| Resource | Limit | Current Usage | Headroom |
|----------|-------|---------------|----------|
| **Firestore reads** | 50K/day (free tier) | 5K/day (5K MAU × 1 read/day) | 10x |
| **Cloud Functions invocations** | 2M/month (free tier) | 50K/month (10K gens × 5 functions) | 40x |
| **Cloud Storage bandwidth** | 1GB/day (free tier) | 50MB/day (100 exports × 0.5MB) | 20x |

**Bottleneck:** None (all within free tier)

---

### 10.2 Growth Triggers (When to Scale)

**Trigger 1: 10K MAU (Firebase Blaze Tier)**
- Expected: Month 4
- Action: Enable Blaze plan ($25/month base + usage)
- Estimated cost: $100-200/month

**Trigger 2: 50K MAU (Cloud Run for MusicGen)**
- Expected: Month 10
- Action: Self-host MusicGen on Cloud Run to reduce per-generation cost
- Estimated cost: $300-500/month (vs. $1,000+ on Replicate)

**Trigger 3: 100K MAU (Multi-Region)**
- Expected: Year 2
- Action: Deploy Cloud Functions to `us-west1`, `europe-west1`, `asia-southeast1`
- Benefit: <100ms latency worldwide

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 0.1 | 2024-12-20 | Eng Team | Initial draft |
| 0.5 | 2024-12-24 | Eng + DevOps | Added CI/CD, monitoring |
| 1.0 | 2024-12-27 | Tech Lead | Final architecture for dev handoff |

**Approval:**
- [ ] Engineering Lead: _________________
- [ ] DevOps Lead: _________________
- [ ] Security Officer: _________________

---

**Next Steps:**
1. Provision Firebase project (Day 1)
2. Set up GitHub repo with CI/CD (Day 2)
3. Configure Sentry + Firebase Analytics (Day 3)
4. Begin sprint planning with PRD + this spec (Week of Jan 6, 2025)
