# Database Schema: OctaveStudio
## Firestore Collections + SQL Reference Schema

**Version:** 1.0  
**Last Updated:** 2024-12-27  
**Database:** Cloud Firestore (NoSQL) with SQL reference for clarity  

---

## Table of Contents

1. [Firestore Overview](#firestore-overview)
2. [Collection Schemas](#collection-schemas)
3. [SQL Reference (For Developers Familiar with SQL)](#sql-reference)
4. [Firestore Indexes](#firestore-indexes)
5. [Security Rules](#security-rules)
6. [Migration Scripts](#migration-scripts)

---

## Firestore Overview

### Why Firestore?

- **Real-time listeners:** Sync data to mobile app instantly
- **Offline support:** Built-in caching for offline-first UX
- **Scalability:** Auto-scales to millions of documents
- **Security:** Row-level security with Firestore Security Rules
- **Cost:** Free tier covers MVP (50K reads/day, 20K writes/day)

### Firestore vs. SQL Mapping

| Firestore Concept | SQL Equivalent |
|-------------------|----------------|
| **Collection** | Table |
| **Document** | Row |
| **Field** | Column |
| **Subcollection** | One-to-Many relationship (foreign key) |
| **Document ID** | Primary key (auto-generated or custom) |
| **Query** | SELECT with WHERE clause |

---

## Collection Schemas

### 1. Collection: `users`

**Purpose:** User profiles and account settings

**Firestore Path:** `/users/{userId}`

**Schema:**

```typescript
interface User {
  // Identity (from Firebase Auth)
  userId: string;                    // Document ID (Firebase Auth UID)
  email: string | null;              // Email from auth provider
  displayName: string | null;        // User's chosen name
  photoURL: string | null;           // Profile picture URL
  
  // Subscription
  tier: 'free' | 'pro' | 'enterprise'; // Subscription tier
  subscriptionId: string | null;     // Stripe subscription ID (if pro/enterprise)
  
  // Timestamps
  createdAt: Timestamp;              // Account creation date
  lastActiveAt: Timestamp;           // Last login or activity
  
  // Preferences
  preferences: {
    favoriteGenres: string[];        // ['lofi', 'pop', 'edm']
    notificationsEnabled: boolean;
    theme: 'light' | 'dark' | 'auto';
    language: string;                // 'en', 'es', 'ja'
  };
  
  // Usage Stats (denormalized for quick access)
  stats: {
    totalGenerations: number;        // Lifetime song/beat/lyric generations
    totalExports: number;            // Lifetime exports
    favoriteTool: string | null;    // 'songforge' | 'beatstacks' | 'lyricsmith'
    lastGenerated: Timestamp | null; // Last generation timestamp
  };
}
```

**Example Document:**

```json
{
  "userId": "abc123xyz",
  "email": "user@example.com",
  "displayName": "Alex Creator",
  "photoURL": "https://example.com/avatar.jpg",
  "tier": "pro",
  "subscriptionId": "sub_abc123",
  "createdAt": "2025-01-15T12:00:00Z",
  "lastActiveAt": "2025-01-20T18:30:00Z",
  "preferences": {
    "favoriteGenres": ["lofi", "edm"],
    "notificationsEnabled": true,
    "theme": "dark",
    "language": "en"
  },
  "stats": {
    "totalGenerations": 47,
    "totalExports": 12,
    "favoriteTool": "songforge",
    "lastGenerated": "2025-01-20T17:45:00Z"
  }
}
```

**Indexes:** None required (queries by userId only)

---

### 2. Subcollection: `users/{userId}/projects`

**Purpose:** User's generated content (songs, beats, lyrics)

**Firestore Path:** `/users/{userId}/projects/{projectId}`

**Schema:**

```typescript
interface Project {
  // Identity
  projectId: string;                 // Document ID (auto-generated)
  userId: string;                    // Owner (redundant for security rules)
  
  // Type & Content
  type: 'song' | 'beat' | 'cover' | 'lyrics'; // Content type
  title: string;                     // User-defined or auto-generated
  prompt: string | null;             // Original user prompt (if applicable)
  
  // Audio Storage
  audioUrl: string | null;           // Cloud Storage signed URL (expires in 1hr)
  audioStoragePath: string | null;   // Permanent path for re-signing: users/{userId}/songs/{projectId}.mp3
  duration: number | null;           // In seconds
  
  // Metadata
  metadata: {
    genre: string | null;            // 'pop', 'lofi', 'edm', etc.
    mood: string | null;             // 'uplifting', 'melancholic', etc.
    tags: string[];                  // User-defined or AI-suggested
    bpm: number | null;              // Beats per minute (for beats only)
    provider: string | null;         // 'replicate' | 'mubert' | 'openai' | 'elevenlabs'
  };
  
  // Timestamps
  createdAt: Timestamp;              // Generation timestamp
  updatedAt: Timestamp;              // Last modification
  
  // Status
  status: 'draft' | 'generating' | 'completed' | 'failed'; // Lifecycle state
  errorMessage: string | null;       // If status === 'failed'
  
  // Relationships
  parentProjectId: string | null;    // Link to parent (e.g., beat used in song)
  variations: string[];              // Array of related projectIds (e.g., re-generations)
  
  // Lyrics (if type === 'lyrics' or 'song')
  lyrics: {
    verse1: string[] | null;
    chorus: string[] | null;
    verse2: string[] | null;
    bridge: string[] | null;
  } | null;
}
```

**Example Document (Song):**

```json
{
  "projectId": "proj_abc123",
  "userId": "abc123xyz",
  "type": "song",
  "title": "Distance Between Us",
  "prompt": "a melancholic pop song about missing a friend",
  "audioUrl": "https://storage.googleapis.com/octave-studios.appspot.com/users/abc123xyz/songs/proj_abc123.mp3?expires=...",
  "audioStoragePath": "users/abc123xyz/songs/proj_abc123.mp3",
  "duration": 180,
  "metadata": {
    "genre": "pop",
    "mood": "melancholic",
    "tags": ["friendship", "longing", "emotional"],
    "bpm": 90,
    "provider": "replicate"
  },
  "createdAt": "2025-01-20T17:45:00Z",
  "updatedAt": "2025-01-20T17:47:00Z",
  "status": "completed",
  "errorMessage": null,
  "parentProjectId": "proj_beat_456",
  "variations": ["proj_abc124", "proj_abc125"],
  "lyrics": {
    "verse1": ["Your empty seat at lunch feels wrong today", "I scroll through our old texts, they're all on read", "The playlist that we made is still on play", "But every song just echoes in my head"],
    "chorus": ["Miles can't break what we have built", "Through late-night calls and inside jokes", "Our friendship's stronger than the guilt", "Of missing you through all these miles"],
    "verse2": null,
    "bridge": null
  }
}
```

**Indexes Required:**

1. **Composite Index (userId ASC, createdAt DESC)**
   - Query: Recent projects by user
   - Usage: My Sets screen

2. **Composite Index (userId ASC, type ASC, createdAt DESC)**
   - Query: Filter by type (e.g., "Show me only songs")
   - Usage: My Sets with filters

3. **Single-field Index (parentProjectId)**
   - Query: Find variations of a project
   - Usage: "Show me all versions of this beat"

**Create Indexes (Firebase Console):**

```bash
# Automatically created via Firebase CLI
firebase firestore:indexes

# Or manually in Firebase Console:
# Firestore → Indexes → Create Index
```

---

### 3. Collection: `rateLimits`

**Purpose:** Track daily generation counts for rate limiting

**Firestore Path:** `/rateLimits/{limitId}`

**Document ID Format:** `{userId}_{YYYY-MM-DD}` (e.g., `abc123xyz_2025-01-20`)

**Schema:**

```typescript
interface RateLimit {
  // Identity
  documentId: string;                // Format: "{userId}_{YYYY-MM-DD}"
  userId: string;
  date: string;                      // ISO date (YYYY-MM-DD)
  
  // Counts (incremented atomically)
  counts: {
    songGeneration: number;          // Incremented on each generateSong()
    beatGeneration: number;
    coverGeneration: number;
    lyricGeneration: number;
  };
  
  // Cached tier info (for quick checks without fetching user doc)
  tier: 'free' | 'pro';
  
  // Limits (denormalized from tier)
  limits: {
    songGeneration: number;          // 10 for free, 50 for pro
    beatGeneration: number;
    coverGeneration: number;
    lyricGeneration: number;
  };
  
  // Timestamps
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

**Example Document:**

```json
{
  "documentId": "abc123xyz_2025-01-20",
  "userId": "abc123xyz",
  "date": "2025-01-20",
  "counts": {
    "songGeneration": 7,
    "beatGeneration": 3,
    "coverGeneration": 0,
    "lyricGeneration": 5
  },
  "tier": "free",
  "limits": {
    "songGeneration": 10,
    "beatGeneration": 10,
    "coverGeneration": 10,
    "lyricGeneration": 10
  },
  "createdAt": "2025-01-20T00:00:00Z",
  "updatedAt": "2025-01-20T17:45:00Z"
}
```

**TTL (Time-To-Live):** Delete documents older than 7 days (Cloud Scheduler)

**Usage Pattern:**

```typescript
// Check if user can generate
const limitDoc = await firestore()
  .collection('rateLimits')
  .doc(`${userId}_${today}`)
  .get();

if (limitDoc.data()?.counts.songGeneration >= 10) {
  throw new Error('Daily limit reached');
}

// Increment counter (atomic operation)
await limitDoc.ref.set({
  userId,
  date: today,
  counts: { songGeneration: admin.firestore.FieldValue.increment(1) }
}, { merge: true });
```

---

### 4. Collection: `subscriptions`

**Purpose:** Stripe subscription data (synced via webhook)

**Firestore Path:** `/subscriptions/{subscriptionId}`

**Schema:**

```typescript
interface Subscription {
  // Stripe IDs
  subscriptionId: string;            // Document ID (Stripe subscription ID)
  stripeCustomerId: string;
  userId: string;                    // OctaveStudio user ID
  
  // Status
  status: 'active' | 'canceled' | 'past_due' | 'trialing' | 'incomplete';
  tier: 'pro' | 'enterprise';
  
  // Billing Cycle
  currentPeriodStart: Timestamp;
  currentPeriodEnd: Timestamp;
  cancelAtPeriodEnd: boolean;        // True if user canceled but still has access
  
  // Pricing
  priceId: string;                   // Stripe price ID (e.g., price_abc123)
  amount: number;                    // In cents (e.g., 999 = $9.99)
  currency: string;                  // 'usd'
  
  // Timestamps
  createdAt: Timestamp;
  updatedAt: Timestamp;
}
```

**Example Document:**

```json
{
  "subscriptionId": "sub_abc123",
  "stripeCustomerId": "cus_xyz789",
  "userId": "abc123xyz",
  "status": "active",
  "tier": "pro",
  "currentPeriodStart": "2025-01-01T00:00:00Z",
  "currentPeriodEnd": "2025-02-01T00:00:00Z",
  "cancelAtPeriodEnd": false,
  "priceId": "price_1abc2def3ghi",
  "amount": 999,
  "currency": "usd",
  "createdAt": "2025-01-01T00:00:00Z",
  "updatedAt": "2025-01-20T12:00:00Z"
}
```

**Indexes:** None required (queries by userId only)

**Webhook Integration:**

```typescript
// Stripe webhook handler (Cloud Function)
export const stripeWebhook = functions.https.onRequest(async (req, res) => {
  const event = stripe.webhooks.constructEvent(
    req.rawBody,
    req.headers['stripe-signature'],
    webhookSecret
  );
  
  if (event.type === 'customer.subscription.created') {
    const subscription = event.data.object;
    
    await admin.firestore()
      .collection('subscriptions')
      .doc(subscription.id)
      .set({
        subscriptionId: subscription.id,
        stripeCustomerId: subscription.customer,
        userId: subscription.metadata.userId, // Set when creating checkout session
        status: subscription.status,
        tier: 'pro',
        currentPeriodStart: admin.firestore.Timestamp.fromDate(new Date(subscription.current_period_start * 1000)),
        currentPeriodEnd: admin.firestore.Timestamp.fromDate(new Date(subscription.current_period_end * 1000)),
        cancelAtPeriodEnd: subscription.cancel_at_period_end,
        priceId: subscription.items.data[0].price.id,
        amount: subscription.items.data[0].price.unit_amount,
        currency: subscription.items.data[0].price.currency,
        createdAt: admin.firestore.FieldValue.serverTimestamp(),
        updatedAt: admin.firestore.FieldValue.serverTimestamp()
      });
    
    // Update user tier in users collection
    await admin.firestore()
      .collection('users')
      .doc(subscription.metadata.userId)
      .update({ tier: 'pro' });
  }
  
  res.json({ received: true });
});
```

---

### 5. Collection: `flaggedPrompts`

**Purpose:** Log prompts flagged by content moderation (audit trail)

**Firestore Path:** `/flaggedPrompts/{flagId}`

**Schema:**

```typescript
interface FlaggedPrompt {
  // Identity
  flagId: string;                    // Document ID (auto-generated)
  userId: string;
  
  // Content
  prompt: string;                    // The flagged prompt
  type: 'song' | 'beat' | 'lyrics'; // Which feature
  
  // Moderation Details
  moderationScores: {
    toxicity: number;                // 0.0 - 1.0
    severeToxicity: number;
    identityAttack: number;
    insult: number;
    profanity: number;
    threat: number;
  };
  
  // Action Taken
  action: 'blocked' | 'warned' | 'allowed'; // 'allowed' = false positive
  
  // Timestamps
  timestamp: Timestamp;
}
```

**Example Document:**

```json
{
  "flagId": "flag_abc123",
  "userId": "abc123xyz",
  "prompt": "violent song about revenge",
  "type": "song",
  "moderationScores": {
    "toxicity": 0.85,
    "severeToxicity": 0.42,
    "identityAttack": 0.12,
    "insult": 0.33,
    "profanity": 0.21,
    "threat": 0.67
  },
  "action": "blocked",
  "timestamp": "2025-01-20T17:45:00Z"
}
```

**Retention:** 90 days (Cloud Scheduler cleanup)

---

## SQL Reference

**For developers more familiar with SQL, here's the equivalent schema:**

### Table: `users`

```sql
CREATE TABLE users (
  user_id VARCHAR(128) PRIMARY KEY,  -- Firebase Auth UID
  email VARCHAR(255),
  display_name VARCHAR(255),
  photo_url TEXT,
  tier VARCHAR(20) DEFAULT 'free' CHECK (tier IN ('free', 'pro', 'enterprise')),
  subscription_id VARCHAR(128),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  last_active_at TIMESTAMP,
  
  -- JSON columns (Firestore supports nested objects)
  preferences JSON,  -- {"favoriteGenres": ["lofi"], "theme": "dark", ...}
  stats JSON,        -- {"totalGenerations": 47, "totalExports": 12, ...}
  
  INDEX idx_tier (tier),
  INDEX idx_created_at (created_at)
);
```

---

### Table: `projects`

```sql
CREATE TABLE projects (
  project_id VARCHAR(128) PRIMARY KEY,
  user_id VARCHAR(128) NOT NULL,
  type VARCHAR(20) CHECK (type IN ('song', 'beat', 'cover', 'lyrics')),
  title VARCHAR(500),
  prompt TEXT,
  audio_url TEXT,
  audio_storage_path TEXT,
  duration INT,
  
  -- JSON columns
  metadata JSON,     -- {"genre": "pop", "mood": "uplifting", "tags": [...], ...}
  lyrics JSON,       -- {"verse1": [...], "chorus": [...], ...}
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  status VARCHAR(20) DEFAULT 'draft' CHECK (status IN ('draft', 'generating', 'completed', 'failed')),
  error_message TEXT,
  parent_project_id VARCHAR(128),
  
  -- Foreign keys
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  FOREIGN KEY (parent_project_id) REFERENCES projects(project_id) ON DELETE SET NULL,
  
  -- Indexes
  INDEX idx_user_created (user_id, created_at DESC),
  INDEX idx_user_type_created (user_id, type, created_at DESC),
  INDEX idx_parent (parent_project_id)
);
```

---

### Table: `rate_limits`

```sql
CREATE TABLE rate_limits (
  document_id VARCHAR(256) PRIMARY KEY,  -- Format: {userId}_{YYYY-MM-DD}
  user_id VARCHAR(128) NOT NULL,
  date DATE NOT NULL,
  
  -- Counts (use separate columns for atomic increments)
  song_generation_count INT DEFAULT 0,
  beat_generation_count INT DEFAULT 0,
  cover_generation_count INT DEFAULT 0,
  lyric_generation_count INT DEFAULT 0,
  
  tier VARCHAR(20),
  
  -- Limits (denormalized)
  song_generation_limit INT DEFAULT 10,
  beat_generation_limit INT DEFAULT 10,
  cover_generation_limit INT DEFAULT 10,
  lyric_generation_limit INT DEFAULT 10,
  
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  UNIQUE KEY unique_user_date (user_id, date),
  INDEX idx_date (date)  -- For cleanup queries (delete old records)
);
```

---

### Table: `subscriptions`

```sql
CREATE TABLE subscriptions (
  subscription_id VARCHAR(128) PRIMARY KEY,  -- Stripe subscription ID
  stripe_customer_id VARCHAR(128) NOT NULL,
  user_id VARCHAR(128) NOT NULL,
  status VARCHAR(20) CHECK (status IN ('active', 'canceled', 'past_due', 'trialing', 'incomplete')),
  tier VARCHAR(20) CHECK (tier IN ('pro', 'enterprise')),
  current_period_start TIMESTAMP,
  current_period_end TIMESTAMP,
  cancel_at_period_end BOOLEAN DEFAULT FALSE,
  price_id VARCHAR(128),
  amount INT,  -- In cents
  currency VARCHAR(3) DEFAULT 'usd',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  
  FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
  INDEX idx_user (user_id),
  INDEX idx_status (status)
);
```

---

### Table: `flagged_prompts`

```sql
CREATE TABLE flagged_prompts (
  flag_id VARCHAR(128) PRIMARY KEY,
  user_id VARCHAR(128) NOT NULL,
  prompt TEXT,
  type VARCHAR(20),
  
  -- Moderation scores (separate columns for easier querying)
  toxicity FLOAT,
  severe_toxicity FLOAT,
  identity_attack FLOAT,
  insult FLOAT,
  profanity FLOAT,
  threat FLOAT,
  
  action VARCHAR(20) CHECK (action IN ('blocked', 'warned', 'allowed')),
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  
  INDEX idx_user (user_id),
  INDEX idx_timestamp (timestamp),
  INDEX idx_action (action)
);
```

---

## Firestore Indexes

**Required Composite Indexes (Create in Firebase Console):**

### Index 1: Recent Projects

```
Collection: users/{userId}/projects
Fields:
  - userId (Ascending)
  - createdAt (Descending)
Query Scope: Collection
```

**Usage:**

```typescript
const recentProjects = await firestore()
  .collection('users')
  .doc(userId)
  .collection('projects')
  .orderBy('createdAt', 'desc')
  .limit(20)
  .get();
```

---

### Index 2: Projects by Type

```
Collection: users/{userId}/projects
Fields:
  - userId (Ascending)
  - type (Ascending)
  - createdAt (Descending)
Query Scope: Collection
```

**Usage:**

```typescript
const songs = await firestore()
  .collection('users')
  .doc(userId)
  .collection('projects')
  .where('type', '==', 'song')
  .orderBy('createdAt', 'desc')
  .get();
```

---

### Index 3: Project Variations

```
Collection: users/{userId}/projects
Fields:
  - parentProjectId (Ascending)
  - createdAt (Descending)
Query Scope: Collection Group (collectionGroup query)
```

**Usage:**

```typescript
const variations = await firestore()
  .collectionGroup('projects')
  .where('parentProjectId', '==', 'proj_abc123')
  .orderBy('createdAt', 'desc')
  .get();
```

---

## Security Rules

**File:** `firestore.rules`

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    
    // Helper functions
    function isAuthenticated() {
      return request.auth != null;
    }
    
    function isOwner(userId) {
      return request.auth.uid == userId;
    }
    
    // Users collection
    match /users/{userId} {
      allow read: if isOwner(userId);
      allow create: if isAuthenticated() && isOwner(userId);
      allow update: if isOwner(userId);
      allow delete: if false; // Prevent accidental deletion (use Cloud Function)
      
      // Projects subcollection
      match /projects/{projectId} {
        allow read: if isOwner(userId);
        allow create: if isOwner(userId) 
                      && request.resource.data.userId == userId
                      && request.resource.data.status == 'draft';
        allow update: if isOwner(userId);
        allow delete: if isOwner(userId);
      }
    }
    
    // Rate limits (read-only for clients, write via Cloud Functions only)
    match /rateLimits/{limitId} {
      allow read: if isAuthenticated() && limitId.split('_')[0] == request.auth.uid;
      allow write: if false; // Only Cloud Functions can write
    }
    
    // Subscriptions (read-only for clients)
    match /subscriptions/{subId} {
      allow read: if isAuthenticated() && resource.data.userId == request.auth.uid;
      allow write: if false; // Only Stripe webhook can write
    }
    
    // Flagged prompts (write-only for Cloud Functions, no client access)
    match /flaggedPrompts/{flagId} {
      allow read, write: if false;
    }
  }
}
```

**Deploy Rules:**

```bash
firebase deploy --only firestore:rules
```

---

## Migration Scripts

### Migration 1: Add `tier` Field to Existing Users

**Run when deploying subscription feature:**

```typescript
// functions/src/migrations/addTierToUsers.ts

import * as admin from 'firebase-admin';

export async function addTierToUsers() {
  const usersSnapshot = await admin.firestore().collection('users').get();
  
  const batch = admin.firestore().batch();
  
  usersSnapshot.docs.forEach(doc => {
    if (!doc.data().tier) {
      batch.update(doc.ref, { tier: 'free' });
    }
  });
  
  await batch.commit();
  console.log(`Updated ${usersSnapshot.size} users with default tier`);
}
```

**Run:**

```bash
firebase functions:shell
> addTierToUsers()
```

---

### Migration 2: Cleanup Old Rate Limit Docs

**Run daily via Cloud Scheduler:**

```typescript
// functions/src/cron/cleanupRateLimits.ts

export const cleanupOldRateLimits = functions.pubsub
  .schedule('0 0 * * *') // Daily at midnight UTC
  .onRun(async () => {
    const sevenDaysAgo = admin.firestore.Timestamp.fromDate(
      new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
    );
    
    const oldDocs = await admin.firestore()
      .collection('rateLimits')
      .where('createdAt', '<', sevenDaysAgo)
      .get();
    
    const batch = admin.firestore().batch();
    oldDocs.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();
    
    console.log(`Deleted ${oldDocs.size} old rate limit documents`);
  });
```

---

## Appendix: Firestore Best Practices

### 1. Denormalization

**Why:** Firestore charges per document read, so minimize reads by duplicating data

**Example:**

```typescript
// ❌ BAD: Requires 2 reads (user + project)
const user = await firestore().collection('users').doc(userId).get();
const project = await firestore().collection('users').doc(userId).collection('projects').doc(projectId).get();
console.log(`Project by ${user.data().displayName}`);

// ✅ GOOD: Store user info in project (1 read)
const project = await firestore().collection('users').doc(userId).collection('projects').doc(projectId).get();
console.log(`Project by ${project.data().creatorName}`); // Denormalized field
```

---

### 2. Atomic Operations

**Use `FieldValue.increment()` for counters:**

```typescript
// ❌ BAD: Race condition (two increments may result in +1 instead of +2)
const doc = await firestore().collection('users').doc(userId).get();
const currentCount = doc.data().stats.totalGenerations;
await doc.ref.update({ 'stats.totalGenerations': currentCount + 1 });

// ✅ GOOD: Atomic increment (no race condition)
await firestore().collection('users').doc(userId).update({
  'stats.totalGenerations': admin.firestore.FieldValue.increment(1)
});
```

---

### 3. Batch Writes

**Update multiple docs in one transaction:**

```typescript
const batch = firestore().batch();

batch.update(userRef, { tier: 'pro' });
batch.set(rateLimitRef, { tier: 'pro', limits: { songGeneration: 50 } }, { merge: true });

await batch.commit(); // Single atomic operation
```

**Limits:** Max 500 operations per batch

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-12-27 | Backend Team | Initial schema for MVP |

**Next Review:** After Sprint 2 (Jan 19, 2025)
