# AI Prompt Engineering Chain: OctaveStudio
## Context-Engineered Instructions for LLM Agents

**Version:** 1.0  
**Last Updated:** 2024-12-27  
**Purpose:** Production-ready prompt templates for AI-powered music creation workflows  

---

## Table of Contents

1. [Prompt Engineering Principles](#1-prompt-engineering-principles)
2. [LyricSmith Prompt Chain](#2-lyricsmith-prompt-chain)
3. [Song Forge Prompt Chain](#3-song-forge-prompt-chain)
4. [Content Moderation Prompts](#4-content-moderation-prompts)
5. [Multi-Agent Orchestration](#5-multi-agent-orchestration)
6. [Prompt Testing & Evaluation](#6-prompt-testing--evaluation)
7. [Cost Optimization](#7-cost-optimization)
8. [Edge Cases & Error Handling](#8-edge-cases--error-handling)

---

## 1. Prompt Engineering Principles

### 1.1 The Five Laws of Production Prompts

**Law 1: Specificity Over Creativity**
```
❌ BAD: "Write a song about love"
✅ GOOD: "Write a 16-line pop song about long-distance love, with ABAB rhyme scheme, uplifting tone, suitable for ages 13+"
```

**Law 2: Structure Before Content**
```
❌ BAD: "Generate lyrics"
✅ GOOD: "Generate lyrics in this structure: [Verse 1: 4 lines] [Chorus: 4 lines] [Verse 2: 4 lines] [Chorus: 4 lines]"
```

**Law 3: Constraints Improve Output**
```
❌ BAD: "Make it good"
✅ GOOD: "Max 500 characters, avoid profanity, target 8th-grade reading level, rhyme every other line"
```

**Law 4: Examples Are Instructions**
```
❌ BAD: "Write in pop style"
✅ GOOD: "Write in pop style like this example: [show 4-line chorus with internal rhymes]"
```

**Law 5: Validate, Don't Trust**
```
❌ BAD: Use LLM output directly
✅ GOOD: Parse output → validate schema → check profanity → render to user
```

---

### 1.2 Production Prompt Template (Standard Format)

**Every production prompt should follow this structure:**

```typescript
const PROMPT_TEMPLATE = `
You are a [ROLE] helping users [GOAL].

# TASK
[Specific instruction with numbered steps]

# CONSTRAINTS
- [Constraint 1: e.g., "Max 500 characters"]
- [Constraint 2: e.g., "Suitable for all ages"]
- [Constraint 3: e.g., "Output as valid JSON"]

# INPUT
User request: "{userInput}"
Genre: {genre}
Mood: {mood}

# OUTPUT FORMAT
Return ONLY valid JSON with this exact schema:
{
  "result": "...",
  "metadata": { "rhymeScheme": "...", "syllableCount": 123 }
}

# EXAMPLES
{examples}

Now generate the output for the user's request.
`;
```

**Why this works:**
1. **Role definition** → Sets tone and expertise level
2. **Task breakdown** → Clear steps prevent ambiguity
3. **Constraints** → Guide LLM toward desired output
4. **Input variables** → Dynamic personalization
5. **Output format** → Structured data for validation
6. **Examples** → Few-shot learning improves quality

---

## 2. LyricSmith Prompt Chain

### 2.1 Phase 1: Theme Extraction (GPT-4)

**Purpose:** Convert vague user ideas into concrete lyrical themes

**Prompt:**

```typescript
const THEME_EXTRACTION_PROMPT = `
You are a professional songwriter analyzing a user's creative idea.

# TASK
1. Extract the core emotional theme from the user's input
2. Identify 3-5 concrete imagery suggestions (visual, sensory details)
3. Determine appropriate song structure for this theme
4. Suggest rhyme scheme and tone

# CONSTRAINTS
- Theme must be single sentence (max 100 characters)
- Imagery must be specific, not abstract (e.g., "rain on windows" not "sadness")
- Age-appropriate (avoid mature themes unless user is verified 18+)
- Output as valid JSON

# INPUT
User idea: "{userInput}"
Genre: {genre}
Target mood: {mood}

# OUTPUT FORMAT
{
  "theme": "One-sentence emotional core",
  "imagery": ["concrete image 1", "concrete image 2", "concrete image 3"],
  "structure": "verse-chorus-verse-chorus-bridge-chorus",
  "rhymeScheme": "ABAB",
  "tone": "melancholic" | "uplifting" | "nostalgic" | "energetic"
}

# EXAMPLES

**Example 1:**
Input: "I miss my best friend who moved away"
Output:
{
  "theme": "The ache of distance between close friends",
  "imagery": ["empty seat at lunch table", "unanswered text messages", "shared playlist playing alone"],
  "structure": "verse-chorus-verse-chorus-bridge-chorus",
  "rhymeScheme": "ABAB",
  "tone": "melancholic"
}

**Example 2:**
Input: "Excited about starting college"
Output:
{
  "theme": "The thrill and uncertainty of new beginnings",
  "imagery": ["packed boxes labeled 'dorm'", "campus map with highlighted paths", "alarm set for 6am"],
  "structure": "verse-chorus-verse-chorus",
  "rhymeScheme": "AABB",
  "tone": "uplifting"
}

Now analyze the user's input and return ONLY the JSON output.
`;
```

**Token Estimate:** ~400 tokens (input) + ~150 tokens (output) = **~550 tokens total**

**Cost:** $0.0055 per request (GPT-4: $0.01/1K tokens)

---

### 2.2 Phase 2: Lyric Generation (GPT-4)

**Purpose:** Write structured lyrics based on extracted theme

**Prompt:**

```typescript
const LYRIC_GENERATION_PROMPT = `
You are a professional lyricist writing a {genre} song.

# TASK
Write song lyrics following this EXACT structure:

{structure}

# CONSTRAINTS
- Rhyme scheme: {rhymeScheme}
- Tone: {tone}
- Each verse: 4 lines
- Each chorus: 4 lines
- Bridge (if included): 4 lines
- Use concrete imagery from this list: {imagery}
- Avoid clichés (e.g., "follow your dreams", "stars align")
- Syllable count should be consistent within each section (e.g., verse lines: 8-10 syllables each)
- Age-appropriate for all audiences (no profanity, violence, sexual content)

# THEME
{theme}

# OUTPUT FORMAT
Return ONLY valid JSON:
{
  "lyrics": {
    "verse1": ["line 1", "line 2", "line 3", "line 4"],
    "chorus": ["line 1", "line 2", "line 3", "line 4"],
    "verse2": ["line 1", "line 2", "line 3", "line 4"],
    "bridge": ["line 1", "line 2", "line 3", "line 4"] // if applicable
  },
  "metadata": {
    "actualRhymeScheme": "ABAB",
    "averageSyllablesPerLine": 9,
    "unusedImagery": ["any imagery suggestions not incorporated"]
  }
}

# EXAMPLE (Pop song, ABAB rhyme, uplifting tone)

Theme: "The ache of distance between close friends"
Imagery: ["empty seat at lunch table", "unanswered text messages", "shared playlist"]

Output:
{
  "lyrics": {
    "verse1": [
      "Your empty seat at lunch feels wrong today",  // A (8 syllables)
      "I scroll through our old texts, they're all on read",  // B (10 syllables)
      "The playlist that we made is still on play",  // A (9 syllables)
      "But every song just echoes in my head"  // B (9 syllables)
    ],
    "chorus": [
      "Miles can't break what we have built",  // A
      "Through late-night calls and inside jokes",  // B
      "Our friendship's stronger than the guilt",  // A
      "Of missing you through all theseokes"  // B (note: intentional near-rhyme for authenticity)
    ]
  },
  "metadata": {
    "actualRhymeScheme": "ABAB",
    "averageSyllablesPerLine": 9,
    "unusedImagery": []
  }
}

Now write lyrics for the user's theme. Return ONLY the JSON output.
`;
```

**Token Estimate:** ~500 tokens (input) + ~400 tokens (output) = **~900 tokens total**

**Cost:** $0.009 per request

---

### 2.3 Phase 3: Educational Annotations (GPT-4)

**Purpose:** Explain *why* the lyrics work (educational feature)

**Prompt:**

```typescript
const ANNOTATION_PROMPT = `
You are a music theory teacher explaining songwriting techniques to a beginner.

# TASK
Analyze these lyrics and explain 3 techniques the songwriter used effectively.

# CONSTRAINTS
- Explanations should be 1-2 sentences each
- Use simple language (8th-grade reading level)
- Focus on practical techniques (rhyme, imagery, emotional arc, structure)
- Avoid jargon (e.g., say "matching sounds" instead of "consonance")

# INPUT
Lyrics:
{lyrics}

# OUTPUT FORMAT
{
  "techniques": [
    {
      "name": "Internal Rhyme",
      "explanation": "Notice 'late' and 'date' rhyme in the middle of line 2, making it catchier.",
      "example": "Line from lyrics showing this technique"
    },
    {
      "name": "Concrete Imagery",
      "explanation": "...",
      "example": "..."
    },
    {
      "name": "Emotional Arc",
      "explanation": "...",
      "example": "..."
    }
  ]
}

# EXAMPLE

Input lyrics:
"Your empty seat at lunch feels wrong today
I scroll through our old texts, they're all on read"

Output:
{
  "techniques": [
    {
      "name": "Concrete Imagery",
      "explanation": "Instead of saying 'I miss you,' the writer shows a specific empty seat. This helps the listener visualize the feeling.",
      "example": "Your empty seat at lunch feels wrong today"
    },
    {
      "name": "Modern References",
      "explanation": "Mentioning 'texts' and 'on read' makes the song relatable to today's audience who use phones to stay connected.",
      "example": "I scroll through our old texts, they're all on read"
    },
    {
      "name": "Sensory Language",
      "explanation": "Using 'feels wrong' adds a physical sensation to the emotion, making it more impactful.",
      "example": "Your empty seat at lunch feels wrong today"
    }
  ]
}

Now analyze the provided lyrics and return ONLY the JSON output.
`;
```

**Token Estimate:** ~400 tokens (input) + ~300 tokens (output) = **~700 tokens total**

**Cost:** $0.007 per request

---

### 2.4 Complete LyricSmith Chain (Orchestration)

**File:** `functions/src/services/lyricSmithService.ts`

```typescript
import OpenAI from 'openai';
import { z } from 'zod';

const openai = new OpenAI({ apiKey: await getSecret('OPENAI_API_KEY') });

// Schema validation for each phase
const ThemeSchema = z.object({
  theme: z.string().max(100),
  imagery: z.array(z.string()).min(3).max(5),
  structure: z.string(),
  rhymeScheme: z.string(),
  tone: z.enum(['melancholic', 'uplifting', 'nostalgic', 'energetic'])
});

const LyricsSchema = z.object({
  lyrics: z.object({
    verse1: z.array(z.string()).length(4),
    chorus: z.array(z.string()).length(4),
    verse2: z.array(z.string()).length(4).optional(),
    bridge: z.array(z.string()).length(4).optional()
  }),
  metadata: z.object({
    actualRhymeScheme: z.string(),
    averageSyllablesPerLine: z.number(),
    unusedImagery: z.array(z.string())
  })
});

export async function generateLyrics(params: {
  userInput: string;
  genre: string;
  mood: string;
}): Promise<GeneratedLyrics> {
  
  // PHASE 1: Extract theme
  const themeResponse = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      { role: 'system', content: THEME_EXTRACTION_PROMPT },
      { role: 'user', content: JSON.stringify(params) }
    ],
    temperature: 0.7,
    max_tokens: 200
  });
  
  const themeData = JSON.parse(themeResponse.choices[0].message.content);
  const validatedTheme = ThemeSchema.parse(themeData); // Throws if invalid
  
  // PHASE 2: Generate lyrics
  const lyricsResponse = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      { 
        role: 'system', 
        content: LYRIC_GENERATION_PROMPT
          .replace('{genre}', params.genre)
          .replace('{rhymeScheme}', validatedTheme.rhymeScheme)
          .replace('{tone}', validatedTheme.tone)
          .replace('{structure}', validatedTheme.structure)
          .replace('{imagery}', JSON.stringify(validatedTheme.imagery))
          .replace('{theme}', validatedTheme.theme)
      },
      { role: 'user', content: 'Generate the lyrics now.' }
    ],
    temperature: 0.8, // Higher temp for creativity
    max_tokens: 500
  });
  
  const lyricsData = JSON.parse(lyricsResponse.choices[0].message.content);
  const validatedLyrics = LyricsSchema.parse(lyricsData);
  
  // PHASE 3: Generate educational annotations (async, don't block)
  const annotationsPromise = openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      { role: 'system', content: ANNOTATION_PROMPT.replace('{lyrics}', JSON.stringify(validatedLyrics.lyrics)) },
      { role: 'user', content: 'Provide annotations now.' }
    ],
    temperature: 0.5,
    max_tokens: 400
  });
  
  // Return lyrics immediately, annotations arrive later
  return {
    lyrics: validatedLyrics.lyrics,
    metadata: validatedLyrics.metadata,
    theme: validatedTheme.theme,
    annotationsPromise // Resolve this in client when "Teach Me" is clicked
  };
}
```

**Total Cost Per Generation:**

- Phase 1 (Theme): $0.0055
- Phase 2 (Lyrics): $0.009
- Phase 3 (Annotations): $0.007

**Total: ~$0.022 per lyric generation** (vs. $0.10 for music generation → lyrics are 5x cheaper)

---

## 3. Song Forge Prompt Chain

### 3.1 Text-to-Music Prompt Engineering (Replicate MusicGen)

**Purpose:** Convert user text prompts into music generation API calls

**Challenge:** MusicGen doesn't use LLMs—it requires carefully formatted text prompts

**Solution:** Use GPT-4 to *translate* casual user input → optimized MusicGen prompt

---

**Prompt Translator (GPT-4):**

```typescript
const MUSICGEN_PROMPT_OPTIMIZER = `
You are an AI music expert optimizing text prompts for MusicGen (Meta's music generation model).

# TASK
Convert the user's casual music request into a MusicGen-optimized prompt.

# MUSICGEN REQUIREMENTS
- Prompt format: "[genre], [tempo descriptor], [instrumentation], [mood adjectives]"
- Max 200 characters
- Avoid narrative descriptions (e.g., "a song about heartbreak" → "melancholic piano ballad")
- Focus on sonic qualities: genre, instruments, tempo, energy, atmosphere
- Use comma-separated tags for best results

# CONSTRAINTS
- Output prompt must be <200 characters
- Avoid subjective language ("beautiful", "amazing")
- Use specific genres (not "good music")
- Include tempo hints: "fast", "slow", "mid-tempo", "upbeat", "downtempo"
- Specify key instruments when relevant

# INPUT
User request: "{userInput}"
Selected genre: {genre}
Selected mood: {mood}

# OUTPUT FORMAT
{
  "optimizedPrompt": "genre, tempo, instruments, mood",
  "reasoning": "Brief explanation of why this prompt will work well"
}

# EXAMPLES

**Example 1:**
Input: "A sad song about missing someone"
Genre: Pop
Mood: Melancholic

Output:
{
  "optimizedPrompt": "melancholic pop ballad, slow tempo, piano and strings, emotional vocals, minor key",
  "reasoning": "Replaced abstract 'sad' with musical descriptor 'melancholic'. Added instrumentation (piano/strings) and technical details (minor key) for better results."
}

**Example 2:**
Input: "Something to work out to"
Genre: EDM
Mood: Energetic

Output:
{
  "optimizedPrompt": "high-energy EDM, 128 BPM, synth bass, driving drums, aggressive build-ups",
  "reasoning": "Specified BPM (128 is standard for EDM). Added technical terms like 'synth bass' and 'build-ups' that MusicGen understands."
}

**Example 3:**
Input: "Chill beats for studying"
Genre: Lofi
Mood: Chill

Output:
{
  "optimizedPrompt": "lofi hip hop, 80 BPM, jazzy chords, vinyl crackle, mellow drums",
  "reasoning": "Added lofi-specific elements (vinyl crackle, jazzy chords) and slower BPM for study vibe."
}

Now optimize the user's prompt for MusicGen. Return ONLY the JSON output.
`;
```

**Token Estimate:** ~600 tokens (input) + ~150 tokens (output) = **~750 tokens**

**Cost:** $0.0075 per prompt optimization

---

**Full Song Forge Chain:**

```typescript
export async function generateSong(params: {
  userInput: string;
  genre: string;
  mood: string;
  duration: number;
}) {
  // Step 1: Optimize prompt for MusicGen
  const optimizerResponse = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      { role: 'system', content: MUSICGEN_PROMPT_OPTIMIZER
          .replace('{userInput}', params.userInput)
          .replace('{genre}', params.genre)
          .replace('{mood}', params.mood)
      },
      { role: 'user', content: 'Optimize this prompt now.' }
    ],
    temperature: 0.5, // Lower temp for consistency
    max_tokens: 200
  });
  
  const { optimizedPrompt } = JSON.parse(optimizerResponse.choices[0].message.content);
  
  // Step 2: Call MusicGen via Replicate
  const musicResponse = await replicate.run(
    "meta/musicgen:...",
    {
      input: {
        prompt: optimizedPrompt,
        duration: params.duration,
        model_version: "melody"
      }
    }
  );
  
  return {
    audioUrl: musicResponse,
    originalPrompt: params.userInput,
    optimizedPrompt,
    genre: params.genre,
    mood: params.mood
  };
}
```

---

### 3.2 Lyric-to-Music Prompt Chain

**When user provides lyrics, not just a prompt:**

```typescript
const LYRICS_TO_MUSICGEN_PROMPT = `
You are a music producer converting lyrics into a MusicGen prompt.

# TASK
Analyze the provided lyrics and generate a MusicGen prompt that matches the lyrical content.

# ANALYSIS STEPS
1. Identify emotional tone (melancholic, uplifting, angry, etc.)
2. Determine appropriate genre based on lyrical themes and structure
3. Suggest tempo (fast lyrics = upbeat, slow/reflective = slower tempo)
4. Recommend instrumentation that complements the lyrics

# INPUT
Lyrics:
{lyrics}

User-selected genre: {genre}

# OUTPUT FORMAT
{
  "optimizedPrompt": "genre, tempo, instruments, mood",
  "analysis": {
    "detectedTone": "melancholic",
    "suggestedGenre": "pop ballad",
    "reasoningForTempo": "Reflective lyrics suggest slower tempo",
    "instrumentationReasoning": "Piano emphasizes emotional vulnerability"
  }
}

# EXAMPLE

Input lyrics:
"Your empty seat at lunch feels wrong today
I scroll through our old texts, they're all on read
The playlist that we made is still on play
But every song just echoes in my head"

User-selected genre: Pop

Output:
{
  "optimizedPrompt": "melancholic pop, mid-tempo, acoustic guitar and piano, emotional vocals, introspective",
  "analysis": {
    "detectedTone": "melancholic",
    "suggestedGenre": "pop ballad",
    "reasoningForTempo": "Reflective lyrics about loss suggest mid-tempo (not too slow, maintains engagement)",
    "instrumentationReasoning": "Acoustic guitar and piano create intimate atmosphere matching vulnerability of lyrics"
  }
}

Now analyze the provided lyrics and return ONLY the JSON output.
`;
```

---

## 4. Content Moderation Prompts

### 4.1 Pre-Moderation (Before API Call)

**Why:** Block toxic prompts *before* spending money on generation

**Approach:** Lightweight regex + Perspective API (not LLM—faster + cheaper)

```typescript
// Regex patterns (client-side, instant)
const BLOCKED_PATTERNS = [
  /\b(kill|murder|suicide|self-harm)\b/i,
  /\b(n[i!]gg[ae]r|f[a@]ggot|ret[a@]rd)\b/i,
  /\b(viagra|cialis|porn|sex)\b/i
];

function quickModerationCheck(prompt: string): boolean {
  return BLOCKED_PATTERNS.some(pattern => pattern.test(prompt));
}

// Perspective API (server-side, 200ms latency)
async function moderatePrompt(prompt: string): Promise<boolean> {
  const response = await axios.post(
    'https://commentanalyzer.googleapis.com/v1alpha1/comments:analyze',
    {
      comment: { text: prompt },
      requestedAttributes: { TOXICITY: {} }
    },
    { params: { key: PERSPECTIVE_API_KEY } }
  );
  
  const toxicityScore = response.data.attributeScores.TOXICITY.summaryScore.value;
  
  if (toxicityScore > 0.7) {
    throw new Error('Prompt contains inappropriate content');
  }
  
  return true;
}
```

**Cost:** $0.001 per Perspective API call (100x cheaper than GPT-4)

---

### 4.2 Post-Moderation (After Generation)

**Why:** AI can generate inappropriate content even from innocent prompts

**Approach:** Check lyrics for profanity, hate speech after generation

```typescript
const POST_GENERATION_MODERATION = `
You are a content moderator reviewing AI-generated song lyrics.

# TASK
Flag any inappropriate content in the provided lyrics.

# CATEGORIES TO FLAG
1. Profanity (even mild, e.g., "damn", "hell")
2. Violence or self-harm references
3. Hate speech or slurs (race, gender, sexuality, religion)
4. Sexual content (explicit or suggestive)
5. Drug/alcohol glorification

# CONSTRAINTS
- Output ONLY "SAFE" or "UNSAFE: [reason]"
- If unsafe, provide specific line that triggered the flag
- Be strict (err on side of caution for all-ages app)

# INPUT
Lyrics:
{lyrics}

# OUTPUT FORMAT
{
  "status": "SAFE" | "UNSAFE",
  "flaggedContent": ["line that was problematic"] | [],
  "category": "profanity" | "violence" | "hate" | "sexual" | "drugs" | null
}

# EXAMPLES

Example 1 (SAFE):
Input:
"Miles can't break what we have built
Through late-night calls and inside jokes"

Output:
{
  "status": "SAFE",
  "flaggedContent": [],
  "category": null
}

Example 2 (UNSAFE - profanity):
Input:
"This damn world keeps bringing me down
I'm so f***ed up, can't turn around"

Output:
{
  "status": "UNSAFE",
  "flaggedContent": ["This damn world keeps bringing me down", "I'm so f***ed up, can't turn around"],
  "category": "profanity"
}

Now moderate the provided lyrics. Return ONLY the JSON output.
`;
```

**Cost:** $0.003 per moderation (only run on generated lyrics, not all requests)

---

## 5. Multi-Agent Orchestration

### 5.1 Session Wizard Orchestration (TikTok Hook Maker)

**Goal:** Chain multiple AI calls to create a complete TikTok-ready song

**Agents:**

1. **Theme Agent** (GPT-4): Extracts theme from user idea
2. **Lyric Agent** (GPT-4): Writes 15-second hook lyrics
3. **Music Agent** (MusicGen): Generates 15-second beat
4. **Mixing Agent** (FFmpeg): Combines vocals + beat

**Orchestration Logic:**

```typescript
export async function createTikTokHook(userIdea: string) {
  // Agent 1: Theme extraction (parallel with lyric generation for speed)
  const themePromise = extractTheme(userIdea);
  
  // Agent 2: Lyric generation (15-second hook)
  const lyricsPromise = generateHookLyrics(userIdea);
  
  // Wait for both
  const [theme, lyrics] = await Promise.all([themePromise, lyricsPromise]);
  
  // Agent 3: Music generation (uses theme + lyrics for context)
  const audioUrl = await generateMusic({
    prompt: `${theme.tone} ${theme.genre}, 15-second TikTok hook, catchy, viral`,
    duration: 15
  });
  
  // Agent 4: Mixing (if user wants vocals, use ElevenLabs TTS)
  const vocalUrl = await textToSpeech(lyrics.chorus.join(' '));
  const mixedUrl = await mixAudio(audioUrl, vocalUrl);
  
  return {
    audioUrl: mixedUrl,
    lyrics: lyrics.chorus,
    theme: theme.theme,
    estimatedViralScore: calculateViralScore(lyrics, theme) // ML model, future feature
  };
}

// Helper: Calculate viral score (pattern matching)
function calculateViralScore(lyrics: Lyrics, theme: Theme): number {
  let score = 50; // Base score
  
  // +10 if uses trending slang (updated quarterly)
  const trendingTerms = ['slay', 'vibe', 'lowkey', 'highkey', 'stan'];
  if (trendingTerms.some(term => lyrics.chorus.join(' ').includes(term))) {
    score += 10;
  }
  
  // +15 if simple rhyme scheme (easier to remember)
  if (theme.rhymeScheme === 'AABB') {
    score += 15;
  }
  
  // +20 if chorus repeats a single phrase (earworm factor)
  const words = lyrics.chorus.join(' ').split(' ');
  const uniqueWords = new Set(words);
  if (words.length / uniqueWords.size > 1.5) { // High repetition
    score += 20;
  }
  
  return Math.min(score, 100); // Cap at 100
}
```

**Total Cost Per TikTok Hook:**

- Theme extraction: $0.0055
- Lyric generation (15s hook): $0.005 (shorter = cheaper)
- Music generation (15s): $0.01 (Replicate pricing)
- TTS vocals: $0.02 (ElevenLabs)

**Total: ~$0.04 per TikTok hook**

---

## 6. Prompt Testing & Evaluation

### 6.1 Automated Prompt Testing

**Create test suite for prompt quality:**

```typescript
// tests/prompts/lyricSmith.test.ts

describe('LyricSmith Prompt Chain', () => {
  it('generates lyrics with correct rhyme scheme', async () => {
    const result = await generateLyrics({
      userInput: 'happy birthday song',
      genre: 'pop',
      mood: 'uplifting'
    });
    
    // Validate rhyme scheme
    const verse1 = result.lyrics.verse1;
    expect(rhymes(verse1[0], verse1[2])).toBe(true); // ABAB pattern
    expect(rhymes(verse1[1], verse1[3])).toBe(true);
  });
  
  it('rejects inappropriate prompts', async () => {
    await expect(
      generateLyrics({
        userInput: 'violent revenge song',
        genre: 'metal',
        mood: 'angry'
      })
    ).rejects.toThrow('inappropriate content');
  });
  
  it('stays within token budget', async () => {
    const tokensBefore = await getTokenCount();
    
    await generateLyrics({
      userInput: 'test prompt',
      genre: 'pop',
      mood: 'chill'
    });
    
    const tokensAfter = await getTokenCount();
    const tokensUsed = tokensAfter - tokensBefore;
    
    expect(tokensUsed).toBeLessThan(2000); // Budget: 2K tokens per generation
  });
});

// Helper: Check if two lines rhyme
function rhymes(line1: string, line2: string): boolean {
  const lastWord1 = line1.split(' ').slice(-1)[0].replace(/[.,!?]/g, '').toLowerCase();
  const lastWord2 = line2.split(' ').slice(-1)[0].replace(/[.,!?]/g, '').toLowerCase();
  
  // Simple phonetic matching (for MVP—use RhymeZone API in production)
  const suffix1 = lastWord1.slice(-3);
  const suffix2 = lastWord2.slice(-3);
  
  return suffix1 === suffix2;
}
```

---

### 6.2 Human Evaluation Rubric

**For testing new prompts before deployment:**

| Criteria | Weight | Scoring (1-5) |
|----------|--------|---------------|
| **Relevance** | 30% | Does output match user intent? |
| **Quality** | 25% | Are lyrics creative, not clichéd? |
| **Structure** | 20% | Correct rhyme scheme, syllable count? |
| **Safety** | 15% | Age-appropriate, no profanity? |
| **Cost** | 10% | Within token budget (<2K tokens)? |

**Test Process:**

1. Generate 20 lyrics with new prompt
2. 3 reviewers score each on rubric
3. Average score must be ≥4.0/5.0 to deploy
4. If <4.0, iterate on prompt wording, re-test

---

## 7. Cost Optimization

### 7.1 Token Reduction Strategies

**Strategy 1: Remove Verbose Instructions**

```typescript
// ❌ BAD (150 tokens)
const VERBOSE_PROMPT = `
Hello! You are a highly skilled and experienced professional songwriter with years of expertise in crafting beautiful, emotionally resonant lyrics that touch the hearts of listeners around the world. Your task today is to help a user create amazing song lyrics...
`;

// ✅ GOOD (30 tokens)
const CONCISE_PROMPT = `
You are a professional songwriter. Write song lyrics with this structure: {structure}
`;
```

**Savings:** 80% fewer tokens

---

**Strategy 2: Cache System Prompts**

```typescript
// OpenAI doesn't support prompt caching yet, but we can minimize repeated text
const SYSTEM_PROMPT_BASE = `You are a professional lyricist.`; // Reuse

// Instead of repeating constraints in every call, store them separately
const CONSTRAINTS = {
  maxLength: 500,
  rhymeScheme: 'ABAB',
  tone: 'uplifting'
};

// Dynamically inject only what changes
const fullPrompt = `${SYSTEM_PROMPT_BASE} Write lyrics with rhyme scheme ${CONSTRAINTS.rhymeScheme}.`;
```

---

**Strategy 3: Use GPT-3.5 for Simple Tasks**

```typescript
// Theme extraction: Use GPT-4 (complex reasoning)
const theme = await openai.chat.completions.create({
  model: 'gpt-4', // $0.01/1K tokens
  messages: [{ role: 'system', content: THEME_EXTRACTION_PROMPT }]
});

// Content moderation: Use GPT-3.5 (simple yes/no)
const isSafe = await openai.chat.completions.create({
  model: 'gpt-3.5-turbo', // $0.001/1K tokens (10x cheaper!)
  messages: [{ role: 'system', content: 'Is this text safe? Answer YES or NO.' }]
});
```

**Savings:** 90% on moderation costs

---

### 7.2 Cost Monitoring

```typescript
// Track token usage per user
export const trackTokenUsage = functions.https.onCall(async (data, context) => {
  const userId = context.auth.uid;
  
  await admin.firestore().collection('usage').doc(userId).set({
    tokensUsed: admin.firestore.FieldValue.increment(data.tokensUsed),
    cost: admin.firestore.FieldValue.increment(data.tokensUsed * 0.01 / 1000), // $0.01 per 1K tokens
    lastUpdated: admin.firestore.FieldValue.serverTimestamp()
  }, { merge: true });
  
  // Alert if user costs exceed $5/month (potential abuse)
  const usage = await admin.firestore().collection('usage').doc(userId).get();
  if (usage.data().cost > 5) {
    await sendSlackAlert(`User ${userId} has spent $${usage.data().cost} this month`);
  }
});
```

---

## 8. Edge Cases & Error Handling

### 8.1 LLM Failure Modes

**Problem 1: Non-JSON Output**

```typescript
// LLM sometimes returns text instead of JSON
const rawOutput = `Sure! Here's the JSON: {"theme": "..."}`; // Includes preamble

// Solution: Extract JSON with regex
function extractJSON(text: string): any {
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('No JSON found in LLM output');
  }
  return JSON.parse(jsonMatch[0]);
}
```

---

**Problem 2: Incomplete JSON**

```typescript
// LLM stops mid-response due to token limit
const truncatedOutput = `{"theme": "The ache of distance", "imagery": ["empty seat"`;

// Solution: Retry with higher max_tokens
async function retryWithMoreTokens(prompt: string, attempt: number = 1): Promise<any> {
  const maxTokens = 200 * attempt; // Increase by 200 each retry
  
  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'system', content: prompt }],
    max_tokens: maxTokens
  });
  
  try {
    return extractJSON(response.choices[0].message.content);
  } catch (err) {
    if (attempt < 3) {
      return retryWithMoreTokens(prompt, attempt + 1);
    }
    throw new Error('Max retries exceeded');
  }
}
```

---

**Problem 3: Off-Topic Responses**

```typescript
// User prompt: "Write a song about pizza"
// LLM output: Recipe for pizza instead of lyrics

// Solution: Add guardrails in prompt
const GUARDRAIL_PROMPT = `
CRITICAL: You must return ONLY song lyrics in the specified JSON format.
Do NOT return:
- Recipes
- Stories
- Explanations
- Anything other than the JSON schema provided
`;
```

---

### 8.2 Rate Limiting (OpenAI API)

**OpenAI Tier Limits:**

- Tier 1 (new accounts): 500 requests/min, 10K tokens/min
- Tier 2 ($50+ spent): 5K requests/min, 100K tokens/min

**Solution: Queue + Retry**

```typescript
import PQueue from 'p-queue';

const openaiQueue = new PQueue({
  concurrency: 10, // Max 10 parallel requests
  interval: 60 * 1000, // Per minute
  intervalCap: 450 // Leave 50 req/min buffer
});

export async function generateLyricsWithQueue(params: LyricParams) {
  return openaiQueue.add(async () => {
    try {
      return await generateLyrics(params);
    } catch (err) {
      if (err.status === 429) { // Rate limit hit
        // Wait 60s, then retry
        await new Promise(resolve => setTimeout(resolve, 60000));
        return generateLyrics(params);
      }
      throw err;
    }
  });
}
```

---

## Appendix A: Prompt Library

**Quick Reference:**

| Use Case | Model | Tokens | Cost | Latency |
|----------|-------|--------|------|---------|
| Theme extraction | GPT-4 | ~550 | $0.0055 | 2-3s |
| Lyric generation | GPT-4 | ~900 | $0.009 | 4-6s |
| Educational annotations | GPT-4 | ~700 | $0.007 | 3-4s |
| MusicGen prompt optimization | GPT-4 | ~750 | $0.0075 | 2-3s |
| Content moderation (post-gen) | GPT-3.5 | ~200 | $0.0002 | 1s |

**Total Average Cost Per User Session (Lyrics + Song):**

- Lyrics: $0.022
- Song prompt optimization: $0.0075
- Music generation (Replicate): $0.02

**Total: ~$0.05 per complete creation** (lyrics + song)

---

## Appendix B: Prompt Version Control

**Track prompt changes in Git:**

```
prompts/
├── v1.0/
│   ├── lyricsmith_theme_extraction.txt
│   ├── lyricsmith_lyric_generation.txt
│   └── musicgen_prompt_optimizer.txt
├── v1.1/ (improved rhyme consistency)
│   └── lyricsmith_lyric_generation.txt
└── CHANGELOG.md
```

**CHANGELOG.md:**

```markdown
# Prompt Changelog

## v1.1 (2025-01-15)
### Changed
- Lyric generation: Added explicit syllable count constraint
- Theme extraction: Reduced max imagery from 5 to 3 (fewer tokens)

### Results
- Rhyme scheme accuracy: 75% → 92%
- Token usage: -15% (avg 900 → 765 tokens)
- User satisfaction: +8% (NPS 45 → 53)

## v1.0 (2024-12-27)
- Initial production prompts
```

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2024-12-27 | AI Team | Initial prompt chain documentation |

**Next Review:** 2025-02-01 (monthly prompt performance audit)
