# Product Requirements Document: OctaveStudio
## Your Door to the Music World

**Version:** 1.0  
**Last Updated:** 2024-12-27  
**Author:** OctaveStudio Product Team  
**Status:** Ready for Development  

---

## Executive Summary

### Product Vision
OctaveStudio is a mobile-first AI music creation suite that democratizes music production for 100K+ creators. Unlike single-feature "song generator" apps, we provide a **guided ecosystem** of interconnected tools that teach music structure while enabling creation.

### Business Objectives
- **North Star Metric:** Monthly Active Creators (creators who publish ≥1 song/month)
- **Revenue Model:** Freemium (10 free generations/month, $9.99/month Pro)
- **Market Positioning:** "Suite, not toy" — positioned between casual AI toys (Suno) and professional DAWs (Ableton)
- **Target Launch:** Q2 2025 (6 months from now)

### Success Metrics (Year 1)
| Metric | Q2 2025 | Q4 2025 | Target |
|--------|---------|---------|--------|
| MAU | 5,000 | 15,000 | 15,000 |
| Paid Conversion | 5% | 12% | 10% |
| MRR | $2,500 | $18,000 | $15,000 |
| NPS | 40 | 55 | 50+ |
| Retention (D30) | 15% | 25% | 20% |

---

## Product Overview

### 1. Core Value Proposition

**For creators who:** Want to turn musical ideas into finished tracks but lack traditional music production skills  
**OctaveStudio provides:** A guided suite of AI-powered creation tools  
**Unlike:** Suno (single-feature song button) or Ableton (complex professional DAW)  
**We offer:** Education-first experience with modular workflows and transparent rights management

### 2. Product Modules (The Six Pillars)

#### 2.1 Song Forge
**Purpose:** Transform text prompts or lyrics into full songs  
**User Flow:**
1. User enters prompt ("uplifting pop about overcoming challenges") OR pastes lyrics
2. User selects genre, mood, vocal style (male/female), length (30s/60s/full)
3. AI generates song (via Replicate MusicGen API or Mubert fallback)
4. User previews with waveform visualization + lyric alignment
5. Save to My Sets or export with usage rights label

**Key Differentiators:**
- **Educational tooltips:** "This is the chorus—notice how it's catchier than the verse"
- **Structure visualization:** Show intro/verse/chorus/bridge sections in timeline
- **Hybrid mode:** User provides lyric skeleton, AI fills verses

**Technical Requirements:**
- Max prompt length: 500 characters
- Input validation: Block profanity, spam patterns
- Generation timeout: 120 seconds max
- Fallback: If primary API fails, queue for retry or offer Mubert alternative

**Success Metrics:**
- Completion rate: >75% (users who start generation finish it)
- Re-generation rate: <30% (users satisfied on first try)
- Save rate: >60% (users save generated song to library)

---

#### 2.2 CoverLab
**Purpose:** Transform user vocals into stylized covers with AI backing tracks  
**User Flow:**
1. User records vocals OR uploads audio file (max 60s, 20MB)
2. User selects backing style (lo-fi, pop, rock, EDM, acoustic)
3. Optional: Enable pitch correction, add reverb/echo effects
4. AI generates backing track + mixes with vocals
5. Preview with A/B toggle (original vs. covered)
6. Export with "Personal Use Only" watermark (removable in Pro tier)

**Key Differentiators:**
- **Vocal separation:** Extract vocals from existing songs for remixing (legal gray area—educate users)
- **Safety guardrails:** UI warns "Only upload vocals you own or have permission to use"
- **Rights awareness:** "This cover is for personal practice. To share publicly, verify licensing."

**Technical Requirements:**
- Audio format support: MP3, WAV, M4A
- Max file size: 20MB (enforced client-side before upload)
- Processing: FFmpeg for audio normalization, Spleeter for vocal separation
- Storage: Cloud Storage with signed URLs (1-hour expiry)

**Success Metrics:**
- Upload success rate: >90% (avoid format/size errors)
- Processing completion: >95% (low failure rate)
- Share rate: >40% (users download/share their covers)

---

#### 2.3 BeatStacks
**Purpose:** Fast generation of loops, beats, instrumentals for content creation  
**User Flow:**
1. User browses tag-based grid: Genre (hip-hop, EDM, lo-fi), Tempo (80-160 BPM), Energy (chill, hype), Use-case (TikTok, podcast, game)
2. User selects tags, clicks "Generate Beat"
3. AI generates 30s or 60s loop (Mubert API preferred for instrumentals)
4. User previews with tempo/BPM overlay
5. Save to My Sets or export with loop markers for DAWs

**Key Differentiators:**
- **Use-case optimization:** "TikTok Hook" generates 15s loops, "Podcast Intro" generates 5s stingers
- **DAW export:** Include MIDI or stems for users who want to edit in Ableton/FL Studio
- **Infinite variations:** "Generate Similar" button creates variations without re-prompting

**Technical Requirements:**
- Tag system: Pre-defined taxonomy (not free-text to avoid poor results)
- Generation queue: Batch requests if user generates 5+ beats (background processing)
- Export formats: MP3 (default), WAV (Pro tier), MIDI (future)

**Success Metrics:**
- Tags-to-beat time: <15 seconds (fast iteration)
- Variation usage: >50% (users generate 2+ beats per session)
- Export rate: >70% (beats are actually used, not just previewed)

---

#### 2.4 LyricSmith
**Purpose:** Lyric writing assistant with rhyme suggestions and structure templates  
**User Flow:**
1. User enters theme ("heartbreak after a breakup")
2. System suggests structure templates: "Verse-Chorus-Verse-Chorus-Bridge-Chorus"
3. User selects template, AI generates starter lyrics for each section
4. User edits inline, requests alternatives: "Make this line more hopeful"
5. "Teach Me" mode: Hover over suggestions, see "Why this works" explanations (rhyme scheme, syllable count, emotional arc)
6. Export lyrics to Song Forge or save as standalone project

**Key Differentiators:**
- **Educational focus:** Not just generation, teach users about AABB rhyme schemes, internal rhymes, metaphors
- **Collaborative editing:** AI suggests, user refines (not passive generation)
- **Genre-aware:** Pop lyrics are simpler, hip-hop has more internal rhymes

**Technical Requirements:**
- LLM: GPT-4 or Claude for lyric generation (avoid Gemini—worse at creative writing)
- Token limits: ~500 tokens per generation (keep costs low)
- Rhyme dictionary: Integrate RhymeZone API or build custom
- Profanity filter: Perspective API to block hate speech, excessive vulgarity

**Success Metrics:**
- Edit rate: >80% (users actively modify AI suggestions—shows engagement)
- Song Forge handoff: >40% (lyrics flow into full song creation)
- "Teach Me" clicks: >30% (users engage with educational content)

---

#### 2.5 My Sets
**Purpose:** Library/project management for all generated content  
**User Flow:**
1. User views grid of all songs, beats, covers, lyrics organized by date
2. User creates "Sets" (playlists): "TikTok Hooks," "Lo-Fi Study Beats," "Song Ideas"
3. User tags items with custom labels: #needsVocals, #finished, #shareWithBand
4. Search by prompt text, tags, date range
5. Project trees: Link related items (e.g., Beat #123 → Lyrics #456 → Final Song #789)

**Key Differentiators:**
- **Project continuity:** Visual graph showing how beat became full song (educational for users learning workflow)
- **Version control:** "Variations" view shows all re-generations of same prompt
- **Collaboration-ready:** "Share Set" generates link (Pro tier for private shares, free tier public-only)

**Technical Requirements:**
- Firestore schema: Users/{userId}/Projects/{projectId}/Items (songs, beats, lyrics as sub-collections)
- Offline support: Cache last 50 items in AsyncStorage for offline browsing
- Export: Bulk download as .zip (all MP3s + metadata JSON)

**Success Metrics:**
- Organization rate: >60% (users create ≥1 custom Set)
- Search usage: >40% (users re-discover old content)
- Project tree usage: >25% (users link related items)

---

#### 2.6 Sessions
**Purpose:** Guided wizards that orchestrate multiple modules for specific outcomes  
**Pre-Built Sessions:**

**Session 1: TikTok Hook Maker**
1. LyricSmith: Generate 15s hook lyrics
2. BeatStacks: Generate upbeat 15s loop
3. Song Forge: Combine into 15s song with vocals
4. Export: Vertical video-optimized (9:16 aspect ratio placeholder for future video feature)

**Session 2: Podcast Intro Builder**
1. User inputs podcast name, vibe
2. BeatStacks: Generate 5s stinger
3. Text-to-speech (ElevenLabs API): "Welcome to [Podcast Name]" voiceover
4. Mix: Combine stinger + voiceover
5. Export: MP3 with fade-in/out

**Session 3: Lo-Fi Study Mix**
1. BeatStacks: Generate 5 lo-fi beats (60s each)
2. Auto-arrange: Crossfade into 5-minute mix
3. Export: Single MP3 file

**Key Differentiators:**
- **One-click workflows:** Users don't need to understand how modules interconnect
- **Customizable:** "Advanced Mode" lets users tweak each step
- **Templates:** User-created Sessions can be saved and shared (future community feature)

**Technical Requirements:**
- State machine: Orchestrate async API calls (Song Forge → wait → BeatStacks → wait → merge)
- Progress UI: Show each step completing (Figma-style progress bar)
- Error handling: If BeatStacks fails, offer manual upload or skip step

**Success Metrics:**
- Session completion: >70% (wizards are intuitive, not abandoned)
- Export rate: >85% (high intent—users came for specific outcome)
- Re-use rate: >50% (users run same Session multiple times)

---

## 3. User Personas

### Primary Persona: "Aspiring Creator Alex"
- **Age:** 19-28
- **Background:** College student or early-career professional, no formal music training
- **Goal:** Create original songs for TikTok, YouTube, or just self-expression
- **Pain Points:** 
  - Can't afford Ableton ($449)
  - Intimidated by traditional DAWs
  - Wants to learn but doesn't have time for courses
- **OctaveStudio Use Case:** 
  - Generates 5-10 songs per month
  - Shares on TikTok, gets feedback, iterates
  - Uses "Teach Me" mode to understand song structure
- **Upgrade Trigger:** Hits 10 free generations limit, wants unlimited

### Secondary Persona: "Content Creator Casey"
- **Age:** 25-35
- **Background:** YouTuber, podcaster, streamer with 10K+ followers
- **Goal:** Royalty-free background music for content (avoids DMCA strikes)
- **Pain Points:**
  - Stock music sites are expensive ($200/year) or have limited selection
  - Doesn't need full songs, just loops and stingers
- **OctaveStudio Use Case:**
  - BeatStacks is primary feature (generates 20+ beats/month)
  - Rarely uses Song Forge (doesn't need vocals)
  - Pro tier user ($9.99/month < $200/year stock music)
- **Upgrade Trigger:** Needs high-quality WAV exports, commercial license

### Tertiary Persona: "Learning Musician Mia"
- **Age:** 14-22
- **Background:** High school or college, taking music classes, plays guitar/piano
- **Goal:** Understand song composition, get ideas for original songs
- **Pain Points:**
  - Writer's block when composing
  - Wants to hear ideas in her head before learning to produce
- **OctaveStudio Use Case:**
  - LyricSmith + Song Forge to prototype song ideas
  - Exports MIDI (future) to import into Logic Pro for final production
  - Uses educational features heavily ("Why does this chord progression work?")
- **Upgrade Trigger:** Wants to export stems for editing in DAW

---

## 4. Competitive Analysis

| Competitor | Strengths | Weaknesses | OctaveStudio Advantage |
|------------|-----------|------------|------------------------|
| **Suno** | High-quality AI vocals, fast generation | Single-feature (just song button), no education, expensive ($20/month) | Suite of tools, educational, cheaper ($9.99) |
| **Udio** | Excellent vocal quality, genre variety | No API (can't integrate), closed beta | Modular approach, transparent tech stack |
| **Mubert** | Royalty-free, public API, affordable | No vocals (instrumentals only), less creative | Hybrid: Mubert for beats, MusicGen for vocals |
| **BandLab** | Full mobile DAW, free | Steep learning curve, no AI features | AI-assisted but simpler than full DAW |
| **Soundraw** | Customizable stems, royalty-free | Subscription required, limited creativity | Freemium model, more AI-driven |

**Positioning:**
- **vs. Suno/Udio:** "Not just a song button—learn music while you create"
- **vs. Mubert:** "Full songs with vocals, not just instrumentals"
- **vs. BandLab:** "AI shortcuts for beginners, graduate to BandLab when ready"

---

## 5. Technical Requirements (High-Level)

### 5.1 Platforms
- **Mobile:** iOS 15+, Android 10+ (React Native via Expo SDK 51)
- **Web:** React Native Web (desktop companion for larger screens)
- **Offline:** Core features work offline (browse My Sets, edit lyrics); generation requires connection

### 5.2 Performance Targets
| Metric | Target | Measurement |
|--------|--------|-------------|
| App launch time | <2s | Cold start on mid-range Android (Pixel 6) |
| Song generation | <60s | P95 latency from tap to playable audio |
| Audio playback start | <500ms | Time from tap to first sound |
| Offline mode | 100% | My Sets browsable without network |

### 5.3 Scalability Targets
| Phase | Users | Concurrent Sessions | Infrastructure |
|-------|-------|---------------------|----------------|
| MVP (Q2 2025) | 5,000 | 50 | Firebase Free/Spark tier + Replicate API |
| Growth (Q4 2025) | 15,000 | 200 | Firebase Blaze tier + Cloud Run MusicGen |
| Scale (2026) | 100,000 | 2,000 | Multi-region, dedicated GPU cluster |

### 5.4 Security Requirements
- **Authentication:** Firebase Auth (magic link, Google/Apple OAuth)
- **Data Encryption:** TLS 1.3 for transport, AES-256 for storage (Cloud Storage)
- **Rate Limiting:** 10 generations/day free, 50/day Pro; enforced server-side (Cloud Functions)
- **Content Moderation:** Perspective API for prompts, reject hate speech/spam
- **Secrets Management:** Cloud Secret Manager for API keys (Replicate, Mubert)

### 5.5 Compliance (Future)
- **GDPR:** User data export/deletion (Firestore listeners)
- **COPPA:** Age gate (require 13+ or parental consent)
- **DMCA:** Watermark free-tier exports, respond to takedown requests

---

## 6. Go-to-Market Strategy

### 6.1 Launch Plan
**Pre-Launch (Months 1-2):**
- Beta program: 100 invite-only users (friends/family, music subreddits)
- Feedback loops: Weekly surveys, bug bounty ($50 Amazon gift cards)

**Soft Launch (Month 3):**
- Invite-only Android beta on Google Play (5,000 slots)
- ProductHunt launch: "AI Music Suite for Creators"
- Influencer outreach: 10 micro-influencers (10K-50K followers) get Pro tier free

**Public Launch (Month 4):**
- iOS App Store + Android general availability
- Press: TechCrunch, The Verge, Music Tech outlets
- Social media: TikTok campaign (#OctaveChallenge—create song, share process)

### 6.2 Pricing Strategy
| Tier | Price | Limits | Target User |
|------|-------|--------|-------------|
| **Free** | $0 | 10 generations/month, watermarked exports, public shares only | Casual tinkerers, students |
| **Pro** | $9.99/month | 50 generations/month, no watermark, private shares, WAV export | Content creators, aspiring musicians |
| **Enterprise** | Custom | Unlimited, API access, white-label | Music schools, content agencies |

**Conversion Funnel:**
1. **Awareness:** 10,000 app installs (TikTok ads, ProductHunt)
2. **Activation:** 5,000 create ≥1 song (50% activation)
3. **Engagement:** 2,000 return Day 7 (40% retention)
4. **Monetization:** 200 upgrade to Pro (10% conversion)
5. **Retention:** 150 still subscribed Month 2 (75% MRR retention)

### 6.3 Growth Channels
1. **Organic Social:** User-generated content on TikTok/Instagram (viral potential)
2. **SEO:** Blog content ("How to write better lyrics," "Royalty-free music for YouTube")
3. **Referral Program:** Free month of Pro for every 3 referrals
4. **Partnerships:** Music schools (free Pro tier for students), content creator platforms

---

## 7. Risks & Mitigation

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| **AI API shutdown** (Suno/Udio unavailable) | Medium | High | Multi-provider fallback (Replicate → Mubert → MusicGen self-hosted) |
| **Copyright claims** (users upload copyrighted vocals) | High | Medium | Watermark free tier, educate users, DMCA process |
| **Low retention** (users churn after free trial) | Medium | High | Engagement loops (daily prompt challenges, leaderboards) |
| **High infrastructure costs** (Firebase/Replicate bills spike) | Low | High | Budget alerts ($500/month cap), rate limiting, usage quotas |
| **Competitor launches similar product** | Medium | Medium | Speed to market (ship MVP in 6 months), differentiate on education |

---

## 8. Success Criteria (Launch +6 Months)

### Must-Have (Dealbreakers if not met)
- ✅ 15,000 MAU
- ✅ 10% paid conversion
- ✅ App Store rating: 4.0+ stars (iOS), 4.2+ (Android)
- ✅ <5% crash rate (Firebase Crashlytics)

### Should-Have (Strong signals of PMF)
- ✅ 20% D30 retention (users return after 30 days)
- ✅ NPS: 50+ (users recommend to friends)
- ✅ 40% of Pro users generate >20 songs/month (power users)

### Nice-to-Have (Future growth indicators)
- ✅ 5% of users create Sessions templates (community engagement)
- ✅ 100+ App Store reviews mentioning "education" or "learning"
- ✅ Organic viral growth: 30% of installs from social shares (not paid ads)

---

## 9. Roadmap (Post-Launch)

### Version 1.1 (Month 7-9)
- **Collaboration:** Share projects with other users, co-edit lyrics
- **MIDI Export:** Download melodies as MIDI for DAW import
- **Custom Sessions:** Users create and share Session templates

### Version 2.0 (Month 10-12)
- **Video Integration:** Auto-generate lyric videos (partnership with Sora or similar)
- **Live Jamming:** Real-time collaborative music creation (Firestore real-time listeners)
- **Marketplace:** Users sell beats/songs to other creators (revenue share model)

### Version 3.0 (Year 2)
- **Desktop App:** Electron-based app with advanced editing (stems, EQ, mastering)
- **AI Voice Cloning:** Upload voice sample, generate songs in your voice (ethical guardrails)
- **Label Partnerships:** Direct upload to Spotify/Apple Music (distribution deals)

---

## 10. Open Questions (To Be Resolved Before Dev Starts)

### Product Questions
1. **Session customization:** Should free tier get 3 pre-built Sessions or all 6?
2. **Watermark design:** Subtle audio watermark or visible "Made with OctaveStudio" tag?
3. **Profanity policy:** Block all profanity or allow in Pro tier with content warning?

### Technical Questions
1. **Audio format priority:** MP3 for all tiers, or WAV for Pro? (Storage cost implications)
2. **Offline generation:** Queue requests offline, process when connected? Or hard requirement for network?
3. **Export limits:** Free tier gets 5 exports/month or unlimited (but watermarked)?

### Business Questions
1. **Payment processor:** Stripe (2.9% + $0.30) or RevenueCat (3% + Stripe fees)?
2. **Refund policy:** 7-day no-questions-asked or "no refunds" (standard for digital goods)?
3. **Enterprise pricing:** Flat $499/month or per-seat ($99/user)?

---

## Appendix A: User Stories (Epics)

### Epic 1: Onboarding
- **US-001:** As a new user, I want a 3-slide intro explaining modules so I understand what the app does
- **US-002:** As a new user, I want to choose my music taste (pop, hip-hop, EDM) so the app personalizes examples
- **US-003:** As a new user, I want to generate my first song in <1 minute so I feel instant success

### Epic 2: Song Creation
- **US-010:** As a creator, I want to enter a text prompt and get a song so I can turn ideas into audio
- **US-011:** As a lyricist, I want to paste my lyrics and get a melody so I can hear my words sung
- **US-012:** As a user, I want to adjust genre/mood after generation so I can iterate without re-prompting

### Epic 3: Audio Management
- **US-020:** As a user, I want to replay any song I've generated so I can review my work
- **US-021:** As a user, I want to download songs to my phone so I can share outside the app
- **US-022:** As a user, I want to delete songs I don't like so my library stays clean

### Epic 4: Monetization
- **US-030:** As a free user, I want to see my generation count so I know when I'll hit the limit
- **US-031:** As a free user, I want to upgrade to Pro in-app so I can continue creating
- **US-032:** As a Pro user, I want to manage my subscription so I can cancel if needed

### Epic 5: Education
- **US-040:** As a learner, I want tooltips explaining song structure so I understand music theory
- **US-041:** As a learner, I want "Why this works" explanations for lyrics so I improve my writing
- **US-042:** As a learner, I want to compare my prompt to the output so I learn what prompts work

---

## Appendix B: Non-Functional Requirements

### Accessibility
- **WCAG 2.1 AA Compliance:** High-contrast mode, screen reader support (TalkBack/VoiceOver)
- **Font Scaling:** Support iOS Dynamic Type and Android font size settings (up to 200%)
- **Touch Targets:** Minimum 44x44pt tap areas (iOS HIG, Material Design)

### Localization (Future)
- **Phase 1:** English only
- **Phase 2:** Spanish, Portuguese (Latin America market)
- **Phase 3:** Japanese, Korean (Asian markets)

### Analytics
- **Tools:** Firebase Analytics (free tier), Mixpanel (for funnel analysis)
- **Events to Track:**
  - `song_generated` (properties: genre, mood, duration, provider)
  - `export_completed` (properties: format, tier, watermarked)
  - `upgrade_to_pro` (properties: trigger_point, promo_code)
  - `session_completed` (properties: session_type, steps_completed)

### A/B Testing
- **Framework:** Firebase Remote Config + A/B Testing
- **Tests to Run:**
  1. Onboarding: 3 slides vs. 5 slides (hypothesis: shorter = higher completion)
  2. Pricing: $9.99/month vs. $7.99/month (hypothesis: lower = more conversions)
  3. CTA: "Upgrade Now" vs. "Go Pro" (hypothesis: "Go Pro" = higher CTR)

---

## Document History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 0.1 | 2024-12-20 | Product Team | Initial draft |
| 0.5 | 2024-12-23 | Product + Eng | Added technical requirements, API decisions |
| 1.0 | 2024-12-27 | Product Lead | Final PRD for development handoff |

**Approval Signatures:**
- [ ] Product Lead: _________________
- [ ] Engineering Lead: _________________
- [ ] Design Lead: _________________
- [ ] CEO/Founder: _________________

---

**Next Steps:**
1. Engineering reviews technical feasibility (3 days)
2. Design creates wireframes for all 6 modules (2 weeks)
3. Legal reviews content moderation policy (1 week)
4. Begin sprint planning for MVP (Week of Jan 6, 2025)
